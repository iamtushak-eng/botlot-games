// Entry point: loads assets, runs the menu-background flyover, and starts games from the UI.
import * as THREE from 'three';
import './ui/ui.js';
import { createRenderer } from './render/looks.js';
import { loadModels, buildScene } from './game/scene.js';
import { generateLevel } from './game/levelgen.js';
import { buildWorld } from './game/sim.js';
import { startGame } from './game/main.js';
import { GameAudio } from './game/audio.js';
import { utcDateString } from './game/rng.js';
import { getYesterday } from './social/store.js';

const ui = window.DeadlineUI, canvas = document.getElementById('game');
const loadingEl = document.getElementById('loading');
const R = createRenderer(canvas), audio = new GameAudio();
let models = null, game = null, attract = null, settings = ui.settings();

// slow drift over today's course behind the menus
function startAttract() {
  stopAttract();
  const level = generateLevel(utcDateString(), 'precision'), world = buildWorld(level), S = buildScene(level, models);
  const cam = new THREE.PerspectiveCamera(62, canvas.clientWidth / Math.max(1, canvas.clientHeight), 0.1, 700);
  R.setDayPalette({ mood: level.mood }); R.applyLook(settings.look);
  let t = 0, raf = 0, last = performance.now();
  const loop = (now) => {
    raf = requestAnimationFrame(loop); const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
    world.step(dt); world.events.length = 0; S.sync(world, dt, 1);
    const z = 8 + ((t * 5) % (level.length - 40)), sway = Math.sin(t * 0.21);
    cam.position.set(sway * 5 - 3, 7.5 + Math.sin(t * 0.33) * 0.8, z); cam.lookAt(sway * 2, 3 + (z / level.length) * 2, z + 22);
    R.render(S.scene, cam);
  };
  raf = requestAnimationFrame(loop);
  attract = () => { cancelAnimationFrame(raf); S.scene.traverse((o) => o.geometry?.dispose()); };
}
function stopAttract() { if (attract) { attract(); attract = null; } }

function begin(opts) {
  stopAttract(); if (game) game.stop();
  game = startGame({ canvas, R, models, audio, settings, ui, ...opts, onLeave: () => { game = null; ui.hideHud(); ui.show('title'); startAttract(); }, onEnd: () => { game = null; startAttract(); } });
}

(async () => {
  try { models = await loadModels('assets/models/'); }
  catch (e) { loadingEl && (loadingEl.textContent = 'Could not load models: ' + e.message); console.error(e); return; }
  loadingEl && loadingEl.remove();
  startAttract();
  window.addEventListener('resize', () => R.resize());
  ui.on('start', ({ mode }) => begin({ mode, practice: false }));
  ui.on('practice', async ({ mode }) => {
    const social = (() => { try { return localStorage.getItem('deadline.social') || 'markers'; } catch { return 'markers'; } })();
    const yesterday = await getYesterday({ mode }).catch(() => null);
    begin({ mode, practice: true, social, yesterday });
  });
  document.addEventListener('deadline:settings', (e) => { settings = e.detail; game?.applySettings(settings); if (!game) R.applyLook(settings.look); });
  window.__deadline = { get game() { return game; }, R, models };
})();
