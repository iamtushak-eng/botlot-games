// Deadline physics: custom deterministic engine. No Math.random, no libraries.
import { SURFACES, resolveSphere } from './collide.js';
import { makeNodes, stepChain } from './rope.js';
import { createRagdoll, stepRagdoll, getPose } from './ragdoll.js';
export { getPose };

export const DT = 1 / 120;
const R = 0.35, H = 1.8, MAX_STEP = 0.1;
const CFG = {
  precision: { run: 6.5, jump: 9.0, grav: 26, fall: 1.9, cut: 2.6, coyote: 0.1, buffer: 0.12 },
  momentum: { run: 7, maxRun: 16, jump: 8.5, grav: 24, fall: 1.4, cut: 1.0, coyote: 0.06, buffer: 0.1, mom: true, park: true },
  // wheeled modes: speed comes from pushing (hold forward), steering rotates a heading instead of snapping velocity,
  // sideways grip is limited so carving drifts. acc m/s^2 along heading, coast/brake decel, turn rad/s, grip 1/s.
  board:  { run: 5.5, maxRun: 16, jump: 9.0, grav: 25, fall: 1.35, cut: 1.1, coyote: 0.07, buffer: 0.12, mom: true, veh: { acc: 4.2, coast: 0.3, brake: 7, turn: 4.8, grip: 6.5, boost: 2.3 } },
  bike:   { run: 6, maxRun: 20, jump: 7.6, grav: 24, fall: 1.3, cut: 0.9, coyote: 0.08, buffer: 0.12, mom: true, veh: { acc: 3.8, coast: 0.22, brake: 11, turn: 3.0, grip: 9, boost: 2.6 } },
};
export const WHEELED = ['board', 'bike'];
const approach = (v, t, d) => (v < t ? Math.min(t, v + d) : Math.max(t, v - d));

export class World {
  constructor() {
    this.boxes = []; this.ramps = []; this.ropes = []; this.bridges = []; this.chars = []; this.hazards = [];
    this.events = []; this.gravity = 24; this.time = 0; this.acc = 0; this._id = 0; this.tick = 0;
  }
  // move: {axis:0|1|2, amp, speed(hz), phase} makes a kinematic platform that carries what stands on it
  addBox({ min, max, surface = 'normal', move = null, tag = null }) {
    const b = { kind: 'box', min: [...min], max: [...max], surface, touched: -1, dead: false, move, tag, off: 0, delta: 0 };
    this.boxes.push(b); return b;
  }
  // heights: [h(minx,minz), h(maxx,minz), h(minx,maxz), h(maxx,maxz)]
  addRamp({ min, max, heights, surface = 'normal' }) {
    const r = { kind: 'ramp', min: [...min], max: [...max], h: [...heights], surface, base: Math.min(...heights) - 1.5 };
    this.ramps.push(r); return r;
  }
  addRope({ anchor, length = 5, segments = 10, stiffness = 1 }) {
    const nodes = makeNodes(anchor, [anchor[0], anchor[1] - length, anchor[2]], segments + 1);
    nodes[0].pin = true;
    const rope = { anchor: [...anchor], length, rest: length / segments, stiffness, nodes };
    this.ropes.push(rope); return rope;
  }
  addBridge({ a, b, planks = 12, sag = 0.5, width = 2 }) {
    const nodes = makeNodes(a, b, planks + 1);
    nodes.forEach((n, i) => { const t = i / planks; n.p[1] -= Math.sin(t * Math.PI) * sag; n.o = n.p.slice(); });
    nodes[0].pin = nodes[planks].pin = true;
    const len = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const br = { a: [...a], b: [...b], nodes, width, rest: (len / planks) * 1.03, weight: 0.004 };
    this.bridges.push(br); return br;
  }
  addCloth(opts = {}) { // minimal: a hanging verlet chain (single strand)
    return this.addRope({ anchor: opts.anchor || [0, 5, 0], length: opts.length || 2, segments: opts.segments || 6, stiffness: 0.9 });
  }
  // saw/orb hazard: a kill sphere, optionally oscillating along an axis
  addHazard({ pos, radius = 1.2, move = null, kind = 'saw', tag = null }) {
    const h = { kind, base: [...pos], pos: [...pos], radius, move, tag, off: 0 };
    this.hazards.push(h); return h;
  }
  // ray vs boxes (slab test); used by the camera spring arm. dir must be normalised.
  raycast(o, d, maxDist) {
    let best = null;
    for (const b of this.boxes) {
      if (b.dead) continue;
      let t0 = 0, t1 = maxDist, ok = true;
      for (let k = 0; k < 3 && ok; k++) {
        if (Math.abs(d[k]) < 1e-9) { if (o[k] < b.min[k] || o[k] > b.max[k]) ok = false; continue; }
        let a = (b.min[k] - o[k]) / d[k], c = (b.max[k] - o[k]) / d[k]; if (a > c) [a, c] = [c, a];
        t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) ok = false;
      }
      if (ok && (!best || t0 < best.distance)) best = { distance: t0, solid: b };
    }
    return best;
  }
  createCharacter({ mode = 'precision', pos = [0, 1, 0] } = {}) {
    const c = {
      id: this._id++, mode, pos: [...pos], vel: [0, 0, 0], onGround: false, state: 'idle', speed: 0, dead: false,
      input: { moveX: 0, moveZ: 0, jump: false, jumpHeld: false, slide: false, grab: false, yaw: 0 },
      setInput(i) { Object.assign(this.input, i); },
      coyote: 0, buffer: 0, boost: 0, sliding: false, wallRun: 0, rope: null, ropeIdx: 0, groundSurface: 'normal', _jumpPrev: false, _grabPrev: false, spawn: [...pos],
    };
    if (mode === 'ragdoll') c.ragdoll = createRagdoll(pos);
    this.chars.push(c); return c;
  }
  step(dt) {
    this.acc += dt;
    let n = 0;
    while (this.acc >= DT - 1e-12 && n++ < 240) { this.acc -= DT; this._sub(DT); }
  }
  _sub(dt) {
    this.tick++; this.time += dt;
    for (const b of this.boxes) {
      if (!b.move || b.dead) continue;
      const m = b.move, off = m.amp * Math.sin(Math.PI * 2 * m.speed * this.time + (m.phase || 0)), dl = off - b.off; b.off = off; b.delta = dl;
      b.min[m.axis] += dl; b.max[m.axis] += dl;
      for (const c of this.chars) {
        if (c.dead || (c.groundSolid !== b && !(c.ragdoll && c.ragdoll.groundSolid === b))) continue;
        c.pos[m.axis] += dl;
        if (c.ragdoll) for (const q of c.ragdoll.pts) { q.p[m.axis] += dl; q.o[m.axis] += dl; }
      }
    }
    for (const h of this.hazards) {
      if (!h.move) continue;
      const m = h.move; h.off = m.amp * Math.sin(Math.PI * 2 * m.speed * this.time + (m.phase || 0)); h.pos[m.axis] = h.base[m.axis] + h.off;
    }
    for (const c of this.chars) {
      if (c.dead || c.limp) continue;
      const pts = c.ragdoll ? c.ragdoll.pts.map(q => q.p) : [[c.pos[0], c.pos[1] + R, c.pos[2]], [c.pos[0], c.pos[1] + H * 0.5, c.pos[2]], [c.pos[0], c.pos[1] + H - R, c.pos[2]]];
      for (const h of this.hazards) {
        const rr = (h.radius + (c.ragdoll ? 0.12 : R)) ** 2;
        if (pts.some(q => (q[0] - h.pos[0]) ** 2 + (q[1] - h.pos[1]) ** 2 + (q[2] - h.pos[2]) ** 2 < rr)) { c.dead = true; c.state = 'dead'; this.events.push({ type: 'death', id: c.id, cause: h.kind }); break; }
      }
    }
    for (const r of this.ropes) stepChain(r.nodes, r.rest, r.stiffness, dt, this.gravity, 0.992);
    for (const b of this.bridges) stepChain(b.nodes, b.rest, 0.9, dt, this.gravity * 0.6, 0.97, 10);
    for (const b of this.boxes) if (b.touched >= 0 && !b.dead && this.time - b.touched > 0.6) { b.dead = true; this.events.push({ type: 'crumble', box: b }); }
    for (const c of this.chars) {
      if (c.dead) continue;
      if (c.mode === 'ragdoll') stepRagdoll(this, c, dt); else this._stepChar(c, dt);
    }
  }
  _stepChar(c, dt) {
    const cfg = CFG[c.mode], inp = c.input, p = c.pos, v = c.vel;
    const cy = Math.cos(inp.yaw), sy = Math.sin(inp.yaw);
    let mx = inp.moveX * cy + inp.moveZ * sy, mz = -inp.moveX * sy + inp.moveZ * cy;
    const ml = Math.hypot(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
    const jumpPressed = inp.jump && !c._jumpPrev; c._jumpPrev = inp.jump;
    const grabPressed = inp.grab && !c._grabPrev; c._grabPrev = inp.grab;
    if (jumpPressed) c.buffer = cfg.buffer; else c.buffer = Math.max(0, c.buffer - dt);
    c.coyote = c.onGround ? cfg.coyote : Math.max(0, c.coyote - dt);
    const surf = SURFACES[c.groundSurface] || SURFACES.normal;

    // rope hanging
    if (c.rope) {
      const node = c.rope.nodes[c.ropeIdx];
      node.p[0] += mx * 20 * dt * dt; node.p[2] += mz * 20 * dt * dt; // pump
      p[0] = node.p[0]; p[1] = node.p[1] - 1.6; p[2] = node.p[2];
      v[0] = (node.p[0] - node.o[0]) / dt; v[1] = (node.p[1] - node.o[1]) / dt; v[2] = (node.p[2] - node.o[2]) / dt;
      c.state = 'rope'; c.onGround = false; c.speed = Math.hypot(v[0], v[2]);
      if (!inp.grab || jumpPressed) {
        c.rope = null; c._ropeCool = 0.3;
        if (jumpPressed) { v[1] += 4; v[0] += mx * 3; v[2] += mz * 3; this.events.push({ type: 'jump', id: c.id, from: 'rope' }); }
      }
      return;
    }
    c._ropeCool = Math.max(0, (c._ropeCool || 0) - dt);
    if (grabPressed && !c._ropeCool) {
      let best = null, bd = 0.9 * 0.9;
      for (const r of this.ropes) r.nodes.forEach((n, i) => {
        if (i === 0) return;
        const d = (n.p[0] - p[0]) ** 2 + (n.p[1] - (p[1] + 1.6)) ** 2 + (n.p[2] - p[2]) ** 2;
        if (d < bd) { bd = d; best = [r, i]; }
      });
      if (best) { c.rope = best[0]; c.ropeIdx = best[1]; this.events.push({ type: 'grab', id: c.id, rope: this.ropes.indexOf(best[0]) }); return; }
    }

    // horizontal control
    let sliding = false;
    if (cfg.mom) {
      const moving = ml > 0.1;
      c.boost = moving ? Math.min(cfg.maxRun - cfg.run, c.boost + (cfg.veh ? cfg.veh.boost : 2.2) * dt) : Math.max(0, c.boost - (cfg.veh ? 1.2 : 6) * dt);
      sliding = c.onGround && inp.slide && c.speed > 3;
      if (sliding && !c.sliding) this.events.push({ type: 'slide', id: c.id });
    }
    const target = (cfg.run + (cfg.mom ? c.boost : 0)) * (c.onGround ? surf.speedMul : 1);
    const hs = Math.hypot(v[0], v[2]);
    if (cfg.veh) this._ride(c, cfg.veh, dt, mx, mz, ml, target, sliding, hs);
    else if (sliding) {
      const f = Math.max(0, hs - 2.5 * dt), k = hs > 1e-6 ? f / hs : 0; v[0] *= k; v[2] *= k;
    } else if (ml > 0.01) {
      const a = (c.onGround ? surf.acc : surf.air) * dt;
      let tx = mx * target, tz = mz * target;
      if (cfg.mom && hs > target) { tx = mx * hs; tz = mz * hs; } // keep speed, only steer
      if (cfg.mom && !c.onGround) { v[0] = approach(v[0], tx, a * 0.6); v[2] = approach(v[2], tz, a * 0.6); }
      else { v[0] = approach(v[0], tx, a); v[2] = approach(v[2], tz, a); }
    } else if (c.onGround) {
      const f = surf.fr * (cfg.mom ? 0.5 : 1) * dt, k = hs > 1e-6 ? Math.max(0, hs - f) / hs : 0; v[0] *= k; v[2] *= k;
    }
    c.sliding = sliding;

    // jumping
    if (c.buffer > 0 && (c.coyote > 0 || (c.wallRun > 0))) {
      const jm = c.coyote > 0 ? surf.jumpMul : 1;
      v[1] = cfg.jump * jm; c.buffer = 0; c.coyote = 0; c.onGround = false;
      if (c.wallRun > 0 && c._wallN) { v[0] += c._wallN[0] * 6; v[2] += c._wallN[2] * 6; c.wallRun = 0; }
      this.events.push({ type: 'jump', id: c.id });
    }
    // gravity
    let g = cfg.grav;
    if (v[1] < 0) g *= cfg.fall; else if (!inp.jumpHeld) g *= cfg.cut + 1;
    if (cfg.park && c.wallRun > 0 && v[1] < 2) g *= 0.15;
    v[1] -= g * dt;
    v[1] = Math.max(v[1], -45);
    c.wallRun = Math.max(0, c.wallRun - dt);

    // swept move, sub-stepped so no step exceeds MAX_STEP (no tunneling at 40 m/s+)
    const dist = Math.hypot(v[0], v[1], v[2]) * dt;
    const n = Math.max(1, Math.ceil(dist / MAX_STEP));
    let ground = false, gs = 'normal', hitWall = null, landVy = 0, gsolid = null;
    const preVy = v[1];
    for (let s = 0; s < n; s++) {
      p[0] += v[0] * dt / n; p[1] += v[1] * dt / n; p[2] += v[2] * dt / n;
      for (let it = 0; it < 3; it++) {
        for (const h of [R, H * 0.5, H - R]) {
          const q = [p[0], p[1] + h, p[2]];
          const cs = resolveSphere(this, q, R);
          if (!cs.length) continue;
          p[0] = q[0]; p[1] = q[1] - h; p[2] = q[2];
          for (const ct of cs) {
            const nn = ct.n, vn = v[0] * nn[0] + v[1] * nn[1] + v[2] * nn[2];
            if (vn < 0) {
              if (ct.surface === 'bounce' && nn[1] > 0.5 && vn < -3) { v[0] -= nn[0] * vn * 1.0; v[1] -= nn[1] * vn * 1.9; v[2] -= nn[2] * vn * 1.0; }
              else { v[0] -= nn[0] * vn; v[1] -= nn[1] * vn; v[2] -= nn[2] * vn; }
            }
            if (nn[1] > 0.64) { ground = true; gs = ct.surface; gsolid = ct.solid; if (ct.solid.kind === 'box' && ct.solid.touched < 0 && ct.surface === 'crumble') ct.solid.touched = this.time; }
            else if (Math.abs(nn[1]) < 0.3) {
              hitWall = nn;
              // vault: low ledge
              const top = ct.solid.kind === 'box' ? ct.solid.max[1] : -Infinity;
              if (cfg.park && h === R && top > p[1] + 0.25 && top < p[1] + 1.0 && hs > 4 && ml > 0.1) { p[1] = top + 0.02; v[1] = Math.max(v[1], 1.5); c.state = 'vault'; }
            }
            if (ct.surface === 'kill' && !c.dead) { c.dead = true; c.state = 'dead'; this.events.push({ type: 'death', id: c.id, cause: 'kill' }); return; }
          }
        }
      }
    }
    if (hitWall && !ground && cfg.park && inp.jumpHeld && hs > 5) { c.wallRun = 0.45; c._wallN = hitWall; }
    if (ground && !c.onGround) { this.events.push({ type: 'land', id: c.id, speed: -preVy, surface: gs }); }
    c.onGround = ground; c.groundSurface = gs; c.groundSolid = ground ? gsolid : null;
    if (p[1] < -50) { c.dead = true; c.state = 'dead'; this.events.push({ type: 'death', id: c.id, cause: 'void' }); return; }
    c.speed = Math.hypot(v[0], v[2]);
    if (c.state !== 'vault' || ground) c.state = c.wallRun > 0 ? 'wallrun' : sliding ? 'slide' : ground ? (c.speed > 0.5 ? 'run' : 'idle') : v[1] > 0 ? 'jump' : 'fall';
  }
  // wheeled movement: heading-based steering, push acceleration, limited sideways grip
  _ride(c, V, dt, mx, mz, ml, target, braking, hs) {
    const v = c.vel;
    if (!c.face) c.face = [Math.sin(c.input.yaw), Math.cos(c.input.yaw)];
    if (!c.onGround) { // airborne: keep momentum, tiny steering
      if (ml > 0.1 && hs > 1) { const fx = v[0] / hs, fz = v[2] / hs, side = mx * fz - mz * fx; v[0] += fz * side * 9 * dt; v[2] -= fx * side * 9 * dt; } // sideways nudge only: no free speed in the air
      if (hs > 1) c.face = [v[0] / hs, v[2] / hs];
      return;
    }
    let ha = Math.atan2(c.face[0], c.face[1]);
    if (ml > 0.1) {
      const da = Math.atan2(mx, mz); let d = da - ha; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
      const rate = (V.turn / (1 + hs * 0.035)) * (hs < 2.5 ? 2.6 : 1);
      ha += Math.max(-rate * dt, Math.min(rate * dt, d));
      c.face = [Math.sin(ha), Math.cos(ha)];
    }
    const fx = c.face[0], fz = c.face[1];
    let fwd = v[0] * fx + v[2] * fz;
    const lx = v[0] - fx * fwd, lz = v[2] - fz * fwd;
    if (ml > 0.1) fwd = fwd < target ? Math.min(target, fwd + V.acc * (1 + 5 * Math.max(0, 1 - fwd / 4)) * dt) : Math.max(target, fwd - 3.2 * dt);
    else fwd = Math.max(0, fwd - V.coast * dt);
    if (braking) fwd = Math.max(0, fwd - V.brake * dt);
    const gk = Math.exp(-V.grip * (braking ? 0.35 : 1) * dt);
    v[0] = fx * fwd + lx * gk; v[2] = fz * fwd + lz * gk;
  }
  // FNV-1a hash of full simulation state, for determinism checks.
  hash() {
    const buf = new DataView(new ArrayBuffer(8)); let h = 2166136261 >>> 0;
    const f = x => { buf.setFloat64(0, x); for (let i = 0; i < 8; i++) { h ^= buf.getUint8(i); h = Math.imul(h, 16777619) >>> 0; } };
    for (const c of this.chars) { c.pos.forEach(f); c.vel.forEach(f); if (c.ragdoll) c.ragdoll.pts.forEach(q => q.p.forEach(f)); }
    for (const r of this.ropes) r.nodes.forEach(n => n.p.forEach(f));
    for (const b of this.bridges) b.nodes.forEach(n => n.p.forEach(f));
    return h.toString(16);
  }
}
