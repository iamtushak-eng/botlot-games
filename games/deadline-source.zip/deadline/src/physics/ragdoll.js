import { resolveSphere } from './collide.js';
// 12-point skeleton. Index map:
export const JOINTS = ['head', 'neck', 'chest', 'pelvis', 'lElbow', 'rElbow', 'lHand', 'rHand', 'lKnee', 'rKnee', 'lFoot', 'rFoot'];
const OFF = [[0, 1.7, 0], [0, 1.5, 0], [0, 1.25, 0], [0, 0.95, 0], [-0.4, 1.4, 0], [0.4, 1.4, 0], [-0.7, 1.4, 0], [0.7, 1.4, 0], [-0.12, 0.5, 0], [0.12, 0.5, 0], [-0.12, 0.05, 0], [0.12, 0.05, 0]];
// [a, b, min ratio, max ratio] -- rest length taken from initial pose; ratio<1 gives angle (bend) limits for 2-bone chains
const LINKS = [[0, 1, 1, 1], [1, 2, 1, 1], [2, 3, 1, 1], [1, 4, 1, 1], [1, 5, 1, 1], [4, 6, 1, 1], [5, 7, 1, 1], [3, 8, 1, 1], [3, 9, 1, 1], [8, 10, 1, 1], [9, 11, 1, 1],
  [1, 6, 0.55, 1], [1, 7, 0.55, 1], [3, 10, 0.5, 1], [3, 11, 0.5, 1], [0, 2, 0.8, 1], [2, 8, 0.6, 1.05], [2, 9, 0.6, 1.05], [4, 5, 0.9, 1.2], [8, 9, 0.5, 2.5]];
const R = 0.12;
const STEER = 11; // m/s^2 at full stick
// head neck chest pelvis lElbow rElbow lHand rHand lKnee rKnee lFoot rFoot
const STEER_W = [0.8, 0.9, 1, 1, 0.5, 0.5, 0.3, 0.3, 0.7, 0.7, 0.5, 0.5];
export function createRagdoll(pos) {
  const pts = OFF.map(o => { const p = [pos[0] + o[0], pos[1] + o[1], pos[2] + o[2]]; return { p, o: p.slice() }; });
  const links = LINKS.map(([a, b, mn, mx]) => {
    const d = Math.hypot(...[0, 1, 2].map(k => OFF[a][k] - OFF[b][k]));
    return { a, b, mn: d * mn, mx: d * mx };
  });
  return { pts, links, grounded: false };
}
export function stepRagdoll(world, char, dt) {
  const rd = char.ragdoll, g = world.gravity;
  const inp = char.input, c = Math.cos(inp.yaw), s = Math.sin(inp.yaw);
  const mx = inp.moveX * c + inp.moveZ * s, mz = -inp.moveX * s + inp.moveZ * c;
  const P = rd.pts;
  // integrate
  for (const q of P) for (let k = 0; k < 3; k++) {
    const v = (q.p[k] - q.o[k]) * 0.995; q.o[k] = q.p[k]; q.p[k] += v + (k === 1 ? -g * dt * dt : 0);
  }
  // muscles: a weighted steering push on the whole body (core strongest, hands/feet weakest, so limbs trail and flop)
  const act = rd.grounded ? 1 : 0.3, W = STEER_W;
  if (!char.limp) for (let i = 0; i < P.length; i++) { const k = STEER * W[i] * act * dt * dt; P[i].p[0] += mx * k; P[i].p[2] += mz * k; }
  if (rd.grounded && !char.limp) {
    // upright "spine" spring: pull chest/neck/head toward a column above the pelvis (position-based, so no net lift force)
    const k = Math.min(1, 14 * dt);
    const pv = P[3].p;
    for (const [i, h, w] of [[2, 0.30, 1], [1, 0.55, 0.9], [0, 0.75, 0.7]]) {
      const q = P[i].p, ty = pv[1] + h;
      const ex = (pv[0] - q[0]) * k * w, ey = (ty - q[1]) * k * w, ez = (pv[2] - q[2]) * k * w;
      q[0] += ex; q[1] += ey; q[2] += ez;
      pv[0] -= ex * 0.15; pv[1] -= ey * 0.15; pv[2] -= ez * 0.15;
    }
    // leg stiffness: hold pelvis at standing height over the planted feet
    const fy = Math.min(P[10].p[1], P[11].p[1]);
    const err = (fy + 0.92) - pv[1];
    pv[1] += err * Math.min(1, 10 * dt);
    // arms hang loosely from the shoulders
    for (const [e, hd, sx] of [[4, 6, -1], [5, 7, 1]]) {
      P[e].p[0] += (P[1].p[0] + sx * 0.4 - P[e].p[0]) * 3 * dt; P[e].p[1] += (P[1].p[1] - 0.15 - P[e].p[1]) * 3 * dt;
    }
    if (inp.moveX || inp.moveZ) for (const [f, off] of [[10, -0.12], [11, 0.12]]) { P[f].p[0] += (pv[0] + off - P[f].p[0]) * 2 * dt; P[f].p[2] += (pv[2] - P[f].p[2]) * 2 * dt; }
    if (inp.jump && !char._rjumped) { for (const q of P) q.o[1] -= 7.5 * dt; char._rjumped = true; world.events.push({ type: 'jump', id: char.id }); }
  }
  if (!inp.jump) char._rjumped = false;
  let ground = false, gsolid = null;
  for (let it = 0; it < 6; it++) {
    for (const l of rd.links) {
      const A = P[l.a].p, B = P[l.b].p;
      const dx = B[0] - A[0], dy = B[1] - A[1], dz = B[2] - A[2], d = Math.hypot(dx, dy, dz) || 1e-9;
      const t = d < l.mn ? l.mn : d > l.mx ? l.mx : d;
      const k = ((d - t) / d) * 0.5;
      A[0] += dx * k; A[1] += dy * k; A[2] += dz * k; B[0] -= dx * k; B[1] -= dy * k; B[2] -= dz * k;
    }
    for (const q of P) {
      const cs = resolveSphere(world, q.p, R);
      for (const ct of cs) {
        // inelastic contact: drop the velocity component along the contact normal, so push-out never becomes a kick
        { const n = ct.n, vx = q.p[0] - q.o[0], vy = q.p[1] - q.o[1], vz = q.p[2] - q.o[2], vn = vx * n[0] + vy * n[1] + vz * n[2]; q.o[0] += n[0] * vn; q.o[1] += n[1] * vn; q.o[2] += n[2] * vn; }
        if (ct.n[1] > 0.5) { ground = true; gsolid = ct.solid; const fr = char.limp ? 0.16 : (inp.moveX || inp.moveZ) ? 0.06 : 0.22; q.o[0] += (q.p[0] - q.o[0]) * fr; q.o[2] += (q.p[2] - q.o[2]) * fr; }
        if (ct.surface === 'kill' && !char.dead && !char.limp) kill(world, char);
      }
    }
  }
  rd.grounded = ground; rd.groundSolid = ground ? gsolid : null;
  const pl = P[3];
  char.pos[0] = pl.p[0]; char.pos[1] = pl.p[1]; char.pos[2] = pl.p[2];
  char.vel[0] = (pl.p[0] - pl.o[0]) / dt; char.vel[1] = (pl.p[1] - pl.o[1]) / dt; char.vel[2] = (pl.p[2] - pl.o[2]) / dt;
  char.onGround = ground;
  char.speed = Math.hypot(char.vel[0], char.vel[2]);
  char.state = ground ? (char.speed > 0.5 ? 'ragdoll-run' : 'ragdoll-idle') : 'ragdoll-air';
}
function kill(world, char) { char.dead = true; char.state = 'dead'; world.events.push({ type: 'death', id: char.id, cause: 'kill' }); }
export function getPose(char) {
  if (!char.ragdoll) return null;
  const out = {};
  JOINTS.forEach((n, i) => { out[n] = char.ragdoll.pts[i].p.slice(); });
  return out;
}
