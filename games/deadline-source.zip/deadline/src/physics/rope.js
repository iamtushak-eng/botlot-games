// Verlet rope + bridge.
export function makeNodes(a, b, count) {
  const nodes = [];
  for (let i = 0; i < count; i++) {
    const t = count === 1 ? 0 : i / (count - 1);
    const p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
    nodes.push({ p, o: p.slice(), pin: false });
  }
  return nodes;
}
export function stepChain(nodes, rest, stiffness, dt, gravity, damping, iters = 14) {
  for (const n of nodes) {
    if (n.pin) continue;
    for (let k = 0; k < 3; k++) {
      const v = (n.p[k] - n.o[k]) * damping;
      n.o[k] = n.p[k];
      n.p[k] += v + (k === 1 ? -gravity * dt * dt : 0);
    }
  }
  for (let it = 0; it < iters; it++) {
    for (let i = 0; i < nodes.length - 1; i++) {
      const A = nodes[i], B = nodes[i + 1];
      const dx = B.p[0] - A.p[0], dy = B.p[1] - A.p[1], dz = B.p[2] - A.p[2];
      const d = Math.hypot(dx, dy, dz) || 1e-9;
      const diff = ((d - rest) / d) * stiffness;
      const wa = A.pin ? 0 : 1, wb = B.pin ? 0 : 1, ws = wa + wb;
      if (!ws) continue;
      A.p[0] += dx * diff * wa / ws; A.p[1] += dy * diff * wa / ws; A.p[2] += dz * diff * wa / ws;
      B.p[0] -= dx * diff * wb / ws; B.p[1] -= dy * diff * wb / ws; B.p[2] -= dz * diff * wb / ws;
    }
  }
}
