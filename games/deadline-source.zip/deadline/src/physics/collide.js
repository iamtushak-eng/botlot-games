// Sphere-vs-world contact resolution (boxes, ramps). Pure functions, deterministic.
export const SURFACES = {
  normal: { fr: 14, acc: 70, air: 28, speedMul: 1, jumpMul: 1 },
  ice: { fr: 0.5, acc: 6, air: 24, speedMul: 1, jumpMul: 1 },
  sticky: { fr: 40, acc: 40, air: 28, speedMul: 0.5, jumpMul: 0.55 },
  bounce: { fr: 14, acc: 70, air: 28, speedMul: 1, jumpMul: 1 },
  crumble: { fr: 14, acc: 70, air: 28, speedMul: 1, jumpMul: 1 },
  kill: { fr: 14, acc: 70, air: 28, speedMul: 1, jumpMul: 1 },
};

export function rampHeight(r, x, z) {
  const [x0, , z0] = r.min, [x1, , z1] = r.max;
  const u = Math.min(1, Math.max(0, (x - x0) / (x1 - x0)));
  const v = Math.min(1, Math.max(0, (z - z0) / (z1 - z0)));
  const h = r.h;
  return h[0] * (1 - u) * (1 - v) + h[1] * u * (1 - v) + h[2] * (1 - u) * v + h[3] * u * v;
}
export function rampNormal(r, x, z) {
  const e = 0.01;
  const dx = (rampHeight(r, x + e, z) - rampHeight(r, x - e, z)) / (2 * e);
  const dz = (rampHeight(r, x, z + e) - rampHeight(r, x, z - e)) / (2 * e);
  const l = Math.hypot(dx, 1, dz);
  return [-dx / l, 1 / l, -dz / l];
}

// Push sphere (center p, radius rad) out of all solids. Mutates p. Returns contacts [{n, surface, solid}].
export function resolveSphere(world, p, rad) {
  const out = [];
  for (const b of world.boxes) {
    if (b.dead) continue;
    const [x0, y0, z0] = b.min, [x1, y1, z1] = b.max;
    const cx = Math.min(x1, Math.max(x0, p[0])), cy = Math.min(y1, Math.max(y0, p[1])), cz = Math.min(z1, Math.max(z0, p[2]));
    let dx = p[0] - cx, dy = p[1] - cy, dz = p[2] - cz;
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 >= rad * rad) continue;
    let n, pen;
    if (d2 > 1e-12) { const d = Math.sqrt(d2); n = [dx / d, dy / d, dz / d]; pen = rad - d; }
    else { // inside: exit via nearest face
      const c = [[p[0] - x0, [-1, 0, 0]], [x1 - p[0], [1, 0, 0]], [p[1] - y0, [0, -1, 0]], [y1 - p[1], [0, 1, 0]], [p[2] - z0, [0, 0, -1]], [z1 - p[2], [0, 0, 1]]];
      let best = c[0]; for (const k of c) if (k[0] < best[0]) best = k;
      n = best[1]; pen = best[0] + rad;
    }
    p[0] += n[0] * pen; p[1] += n[1] * pen; p[2] += n[2] * pen;
    out.push({ n, surface: b.surface, solid: b });
  }
  for (const r of world.ramps) {
    if (p[0] < r.min[0] - rad || p[0] > r.max[0] + rad || p[2] < r.min[2] - rad || p[2] > r.max[2] + rad) continue;
    const sy = rampHeight(r, p[0], p[2]);
    const n = rampNormal(r, p[0], p[2]);
    const d = (p[1] - sy) * n[1];
    if (d < rad && p[1] > r.base) {
      if (d < -0.6) continue;
      const pen = rad - d;
      p[0] += n[0] * pen; p[1] += n[1] * pen; p[2] += n[2] * pen;
      out.push({ n, surface: r.surface, solid: r });
    }
  }
  // bridges: planks as soft one-sided surface
  for (const br of world.bridges) {
    const ax = br.b[0] - br.a[0], az = br.b[2] - br.a[2], L2 = ax * ax + az * az;
    let t = ((p[0] - br.a[0]) * ax + (p[2] - br.a[2]) * az) / L2;
    if (t < 0 || t > 1) continue;
    const lat = Math.abs((p[0] - br.a[0]) * -az + (p[2] - br.a[2]) * ax) / Math.sqrt(L2);
    if (lat > br.width * 0.5) continue;
    const f = t * (br.nodes.length - 1), i = Math.min(br.nodes.length - 2, Math.floor(f)), w = f - i;
    const n0 = br.nodes[i], n1 = br.nodes[i + 1];
    const sy = n0.p[1] * (1 - w) + n1.p[1] * w + 0.05;
    const d = p[1] - sy;
    if (d < rad && d > -0.5) {
      p[1] += rad - d;
      const push = 0.5 * br.weight;
      n0.p[1] -= push * (1 - w); n1.p[1] -= push * w;
      out.push({ n: [0, 1, 0], surface: 'normal', solid: br });
    }
  }
  return out;
}
