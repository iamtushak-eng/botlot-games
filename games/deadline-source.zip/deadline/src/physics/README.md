# Deadline physics (custom, deterministic, no libraries)
`import { World, getPose, DT } from './index.js'`. Fixed step DT=1/120 with accumulator; no Math.random.

- `new World()`; `world.events` (caller drains: `world.events.length = 0`). Events: land{speed,surface}, jump, slide, death{cause}, crumble, grab{rope}.
- `addBox({min,max,surface})` surface: normal|ice|sticky|bounce|crumble|kill.
- `addRamp({min,max,heights:[h(minx,minz),h(maxx,minz),h(minx,maxz),h(maxx,maxz)],surface})` bilinear slanted top.
- `addRope({anchor,length,segments,stiffness})` -> rope.nodes[].p. `addBridge({a,b,planks,sag,width})`. `addCloth()` is only a single hanging strand (stub).
- `createCharacter({mode:'precision'|'momentum'|'ragdoll',pos})` -> fields pos, vel, onGround, state, speed, dead. `setInput({moveX,moveZ,jump,jumpHeld,slide,grab,yaw})`.
- `world.step(dt)`, `world.hash()` (state hash). `getPose(char)` -> 12 named joints (ragdoll only).
- Precision: coyote 0.1s, buffer 0.12s, variable jump height. Momentum: speed boost up to 16 m/s, slide, ledge vault, wall-run (jumpHeld near wall), wall-jump. Rope: press grab near a node; jump releases.
- Collision: 3 spheres (r=0.35, h=1.8) vs boxes/ramps/bridge, move split into <=0.1 m sub-steps.

Known issues: ragdoll mode is not tuned (drifts sideways on ground, test fails); cloth is a stub.
