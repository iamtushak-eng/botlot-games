// Deadline social store. localStorage demo backend (deterministic fake crowd) or HTTP backend when window.DEADLINE_API is set.
const LS = typeof localStorage !== 'undefined' ? localStorage : null;
const MODES = ['precision', 'momentum', 'ragdoll', 'board', 'bike'];

function hash32(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export function utcDate(offsetDays = 0) {
  const d = new Date(Date.now() + offsetDays * 864e5);
  return d.toISOString().slice(0, 10);
}

// Deterministic crowd for a date+mode. Same inputs always give the same output.
function seedCrowd(date, mode) {
  // demo baseline so percentiles mean something without a server: most people die early, a few go far
  const r = rng(hash32(date + '|' + mode)), runs = [];
  for (let i = 0; i < 120; i++) runs.push({ progress: round(Math.min(100, Math.pow(r(), 1.8) * 100)) });
  return runs;
}
function round(n) { return Math.round(n * 100) / 100; }

function lsGet(k, d) { try { return JSON.parse(LS.getItem(k)) ?? d; } catch { return d; } }
function lsSet(k, v) { try { LS.setItem(k, JSON.stringify(v)); } catch {} }

const localBackend = {
  async submitRun(run) {
    const key = 'deadline.runs.' + run.date + '.' + run.mode;
    const mine = lsGet(key, []);
    if (mine.length) return { ok: false, error: 'already_played', percentile: percentileOf(run.date, run.mode, mine[0].progress) };
    mine.push({ progress: run.progress, died: !!run.died, pos: run.pos || null, inputs: run.inputs || null });
    lsSet(key, mine);
    return { ok: true, percentile: percentileOf(run.date, run.mode, run.progress) };
  },
  async getYesterday({ mode }) {
    const date = utcDate(-1);
    const real = lsGet('deadline.runs.' + date + '.' + mode, []); // only real runs; the game adds its simulated field on top
    return {
      date, mode, total: real.length,
      deaths: real.filter(r => r.died && r.pos).map(r => ({ pos: r.pos, progress: r.progress })),
      ghosts: real.filter(r => r.inputs).sort((a, b) => b.progress - a.progress).slice(0, 5).map(r => ({ progress: r.progress, inputs: r.inputs })),
    };
  },
};
function percentileOf(date, mode, progress) {
  const crowd = seedCrowd(date, mode).concat(lsGet('deadline.runs.' + date + '.' + mode, []));
  const below = crowd.filter(r => r.progress < progress).length;
  return Math.round((below / crowd.length) * 100);
}

const httpBackend = {
  async submitRun(run) {
    const res = await fetch(window.DEADLINE_API + '/run', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(run) });
    return res.json().catch(() => ({ ok: false, error: 'bad_response' }));
  },
  async getYesterday({ mode }) {
    const date = utcDate(-1);
    const res = await fetch(`${window.DEADLINE_API}/day/${date}/${mode}`);
    if (!res.ok) return { date, mode, total: 0, deaths: [], ghosts: [] };
    return res.json();
  },
};

const backend = () => (typeof window !== 'undefined' && window.DEADLINE_API) ? httpBackend : localBackend;

export function submitRun({ date, mode, progress, died, pos, inputs }) {
  if (!MODES.includes(mode)) return Promise.resolve({ ok: false, error: 'bad_mode' });
  return backend().submitRun({ date, mode, progress, died, pos, inputs });
}
export function getYesterday({ mode }) { return backend().getYesterday({ mode }); }
// an attempt counts as spent when it STARTS, so closing the tab mid-run is not a free retry
export function markStarted(date, mode) { lsSet('deadline.started.' + date + '.' + mode, 1); }
export function modesUsedToday() {
  const d = utcDate();
  return MODES.filter(m => (lsGet('deadline.runs.' + d + '.' + m, [])).length || lsGet('deadline.started.' + d + '.' + m, 0));
}
