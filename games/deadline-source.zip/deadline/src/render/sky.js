import * as THREE from 'three';

export function createSky(scene) {
  const group = new THREE.Group();
  const uniforms = { top: { value: new THREE.Color() }, mid: { value: new THREE.Color() }, bot: { value: new THREE.Color() } };
  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(450, 24, 16),
    new THREE.ShaderMaterial({
      uniforms, side: THREE.BackSide, depthWrite: false, fog: false,
      vertexShader: 'varying float vH; void main(){ vH = normalize(position).y; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform vec3 top,mid,bot; varying float vH; void main(){ float h=clamp(vH,-0.1,1.0); vec3 c = h<0.25 ? mix(bot,mid,smoothstep(-0.1,0.25,h)) : mix(mid,top,smoothstep(0.25,0.85,h)); gl_FragColor=vec4(c,1.0); }',
    }));
  dome.renderOrder = -10; dome.frustumCulled = false;
  group.add(dome);

  // low-poly clouds: clumps of flattened icosahedrons
  const cloudMat = new THREE.MeshBasicMaterial({ color: 0xffffff, flatShading: true, fog: false, transparent: true, opacity: 0.85 });
  const clouds = [];
  let s = 12345; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 9; i++) {
    const cl = new THREE.Group();
    const n = 3 + Math.floor(rnd() * 3);
    for (let j = 0; j < n; j++) {
      const m = new THREE.Mesh(new THREE.IcosahedronGeometry(8 + rnd() * 8, 0), cloudMat);
      m.position.set((j - n / 2) * 11, rnd() * 4, rnd() * 6);
      m.scale.y = 0.45;
      cl.add(m);
    }
    const a = rnd() * Math.PI * 2, r = 120 + rnd() * 220;
    cl.position.set(Math.cos(a) * r, 90 + rnd() * 50, Math.sin(a) * r);
    cl.userData.speed = 1.5 + rnd() * 2.5;
    clouds.push(cl); group.add(cl);
  }
  scene.add(group);

  return {
    group, dome,
    setMood(m) {
      uniforms.top.value.setHex(m.top); uniforms.mid.value.setHex(m.mid); uniforms.bot.value.setHex(m.bot);
      cloudMat.color.setHex(m.bot).lerp(new THREE.Color(0xffffff), 0.35);
      cloudMat.opacity = /storm|smog|overcast|toxic/.test(m.name) ? 0.95 : 0.8;
    },
    update(dt, camera) {
      if (camera) group.position.copy(camera.position);
      for (const c of clouds) { c.position.x += c.userData.speed * dt; if (c.position.x > 350) c.position.x = -350; }
    },
  };
}
