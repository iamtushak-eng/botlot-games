import * as THREE from 'three';

// 10 hand-tuned day moods. Colors are hex; sun/fill are warm/cool split.
export const MOODS = [
  { name: 'dawn',      top: 0x5b6fa8, mid: 0xe8a07a, bot: 0xffd6a5, fog: 0xf0b894, sun: 0xffb27a, sunI: 2.6, hemiSky: 0x9fb4e8, hemiGnd: 0x6a4a4a, fill: 0x7a9ad8, fogD: 0.012, dir: [-0.8, 0.35, 0.5] },
  { name: 'clear',     top: 0x3a7bd5, mid: 0x8fc3f0, bot: 0xdff1ff, fog: 0xbcd8ee, sun: 0xfff2d6, sunI: 3.2, hemiSky: 0xbfdfff, hemiGnd: 0x5a5646, fill: 0x6f9ee0, fogD: 0.008, dir: [0.6, 1.0, 0.4] },
  { name: 'smog',      top: 0x5f6e80, mid: 0x9c9a90, bot: 0xc2b9a4, fog: 0x948f84, sun: 0xf3dcb4, sunI: 1.9, hemiSky: 0xa4b0bd, hemiGnd: 0x3a3a34, fill: 0x6a7e96, fogD: 0.028, dir: [0.4, 0.8, 0.3] },
  { name: 'overcast',  top: 0x7f8a96, mid: 0x9ea9b3, bot: 0xc3cbd2, fog: 0xa0abb4, sun: 0xdde4ea, sunI: 1.3, hemiSky: 0xc0cad4, hemiGnd: 0x4e5258, fill: 0x8ea0b4, fogD: 0.02, dir: [0.3, 1.0, 0.2] },
  { name: 'dusk',      top: 0x2b2a5e, mid: 0xc4506a, bot: 0xffa070, fog: 0x9a5a6a, sun: 0xff8a50, sunI: 2.4, hemiSky: 0x6a5a9a, hemiGnd: 0x3a2a3a, fill: 0x4a5ab8, fogD: 0.016, dir: [-0.9, 0.3, -0.4] },
  { name: 'storm',     top: 0x1f2630, mid: 0x3a4654, bot: 0x5a6a78, fog: 0x3c4856, sun: 0xa8c0d8, sunI: 0.9, hemiSky: 0x586878, hemiGnd: 0x20262c, fill: 0x405a80, fogD: 0.03, dir: [0.2, 0.9, 0.6] },
  { name: 'neon night',top: 0x080818, mid: 0x2a0a4a, bot: 0xff2a9a, fog: 0x1a0a30, sun: 0x6a8aff, sunI: 1.1, hemiSky: 0x3a2a8a, hemiGnd: 0x2a0a2a, fill: 0xff3aa0, fogD: 0.022, dir: [-0.5, 0.8, 0.7] },
  { name: 'golden',    top: 0x4f6f9c, mid: 0xc9aa80, bot: 0xe2d4ba, fog: 0xbfae94, sun: 0xffcf96, sunI: 3.0, hemiSky: 0x9fb0c8, hemiGnd: 0x4a4034, fill: 0x5f7aa8, fogD: 0.012, dir: [0.9, 0.45, 0.2] },
  { name: 'toxic',     top: 0x3a4a22, mid: 0x7a9a30, bot: 0xc8d870, fog: 0x7a8a3a, sun: 0xd8ff80, sunI: 1.8, hemiSky: 0x8aa850, hemiGnd: 0x2a3216, fill: 0x4a8a6a, fogD: 0.026, dir: [0.3, 0.7, -0.5] },
  { name: 'midnight',  top: 0x04061a, mid: 0x0c1a3a, bot: 0x1e3058, fog: 0x0e1a30, sun: 0x90b0ff, sunI: 0.8, hemiSky: 0x24386a, hemiGnd: 0x0a1020, fill: 0x2a4a9a, fogD: 0.018, dir: [-0.4, 0.9, -0.3] },
];

function mulberry(seed) {
  let a = (seed | 0) + 0x6d2b79f5;
  return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
export function pickMood(seed) {
  if (typeof seed === 'string') { let h = 0; for (const c of seed) h = (h * 31 + c.charCodeAt(0)) | 0; seed = h; }
  return MOODS[Math.floor(mulberry(seed)() * MOODS.length)];
}

export function createLights(scene) {
  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.42);
  const key = new THREE.DirectionalLight(0xffffff, 3);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.radius = 4;
  key.shadow.bias = -0.0004;
  key.shadow.normalBias = 0.03;
  const c = key.shadow.camera; c.left = -40; c.right = 40; c.top = 40; c.bottom = -40; c.near = 1; c.far = 200;
  const fill = new THREE.DirectionalLight(0x6688cc, 0.6); // cool fill opposite key
  scene.add(hemi, key, key.target, fill);
  const lights = { hemi, key, fill, focus: new THREE.Vector3() };
  lights.follow = (pos) => { // keep shadow frustum centered on player
    lights.focus.copy(pos);
    key.target.position.copy(pos);
    key.position.copy(pos).addScaledVector(lights.dir || new THREE.Vector3(0.5, 1, 0.4), 80);
    fill.position.copy(pos).addScaledVector(lights.dir || new THREE.Vector3(0.5, 1, 0.4), -60).setY(pos.y + 30);
  };
  lights.applyMood = (m, intensityScale = 1) => {
    lights.dir = new THREE.Vector3(...m.dir).normalize();
    key.color.setHex(m.sun); key.intensity = m.sunI * 1.25 * intensityScale;
    hemi.color.setHex(m.hemiSky); hemi.groundColor.setHex(m.hemiGnd).lerp(new THREE.Color(m.hemiSky), 0.38);
    fill.color.setHex(m.fill);
    lights.follow(lights.focus);
  };
  return lights;
}
