import * as THREE from 'three';
import { createLights, MOODS, pickMood } from './lights.js';
import { createSky } from './sky.js';

const POST_VS = 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.0,1.0); }';
const POST_FS = `
uniform sampler2D tex; uniform vec2 res; uniform float time, retro, grain, vig, exposure, levels;
varying vec2 vUv;
vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.0,1.0); }
float bayer4(vec2 p){ int x=int(mod(p.x,4.0)), y=int(mod(p.y,4.0)); int i=x+y*4;
  float m[16]; m[0]=0.;m[1]=8.;m[2]=2.;m[3]=10.;m[4]=12.;m[5]=4.;m[6]=14.;m[7]=6.;m[8]=3.;m[9]=11.;m[10]=1.;m[11]=9.;m[12]=15.;m[13]=7.;m[14]=13.;m[15]=5.;
  for(int k=0;k<16;k++){ if(k==i) return m[k]/16.0; } return 0.0; }
float hash(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }
void main(){
  vec3 c = texture2D(tex, vUv).rgb * exposure;
  c = aces(c);
  c = pow(c, vec3(1.0/2.2)); // display gamma (ACES done in linear)
  { float l = dot(c, vec3(0.2126,0.7152,0.0722));
    c = mix(vec3(l), c, 0.86);                                              // pull saturation back
    c *= mix(vec3(0.90,0.97,1.08), vec3(1.07,1.0,0.90), smoothstep(0.12,0.78,l)); // cool shadows, warm lights
    c = mix(c, c*c*(3.0-2.0*c), 0.32); }                                    // contrast curve
  c = c * 0.93 + vec3(0.045, 0.047, 0.055); // lifted blacks: shadows stay readable
  if(retro > 0.5){
    float d = bayer4(vUv*res) - 0.5;
    c = floor(c*levels + d + 0.5)/levels;      // dither + limited color banding
  } else {
    c += (hash(vUv*res + fract(time)*100.0) - 0.5) * grain; // film grain
  }
  vec2 q = vUv - 0.5; c *= 1.0 - vig * smoothstep(0.25, 0.85, dot(q,q)*2.0);
  gl_FragColor = vec4(c, 1.0);
}`;

let current = null;
const RETRO_W = 320, RETRO_H = 240;

export function createRenderer(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.NoToneMapping; // ACES applied in post pass (render targets skip tone mapping)
  renderer.outputColorSpace = THREE.LinearSRGBColorSpace; // post pass does gamma itself

  const target = new THREE.WebGLRenderTarget(4, 4, { type: THREE.HalfFloatType, depthBuffer: true, samples: 4 });
  const postMat = new THREE.ShaderMaterial({
    vertexShader: POST_VS, fragmentShader: POST_FS, depthTest: false, depthWrite: false,
    uniforms: { tex: { value: target.texture }, res: { value: new THREE.Vector2(1, 1) }, time: { value: 0 }, retro: { value: 0 },
      grain: { value: 0.035 }, vig: { value: 0.4 }, exposure: { value: 0.9 }, levels: { value: 31 } },
  });
  const postScene = new THREE.Scene();
  const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  postScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), postMat));

  const state = { look: 'lowpoly', mood: MOODS[1], scene: null, lights: null, sky: null, clock: new THREE.Clock(), retroUniforms: { uSnapRes: { value: new THREE.Vector2(RETRO_W, RETRO_H) } }, seen: new WeakMap(), fogMul: 1 };

  function sizeTarget() {
    const w = canvas.clientWidth || canvas.width || 1, h = canvas.clientHeight || canvas.height || 1;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(w, h, false);
    const retro = state.look === 'retro';
    const tw = retro ? RETRO_W : renderer.domElement.width, th = retro ? RETRO_H : renderer.domElement.height;
    target.setSize(tw, th);
    target.texture.minFilter = target.texture.magFilter = retro ? THREE.NearestFilter : THREE.LinearFilter;
    target.texture.needsUpdate = true;
    postMat.uniforms.res.value.set(tw, th);
    renderer.getDrawingBufferSize(new THREE.Vector2());
  }

  function retroPatch(shader) {
    shader.uniforms.uSnapRes = state.retroUniforms.uSnapRes;
    shader.vertexShader = shader.vertexShader
      .replace('void main() {', 'uniform vec2 uSnapRes;\nvoid main() {')
      .replace('#include <project_vertex>', `#include <project_vertex>
        { vec4 p = gl_Position; vec2 ndc = p.xy / p.w; vec2 sn = floor(ndc * uSnapRes * 0.5 + 0.5) / (uSnapRes * 0.5);
          #ifdef USE_MAP
          vMapUv += (sn - ndc) * 0.5 * (1.0 + 0.5 * sin(p.w * 3.0));  // affine-ish wobble
          #endif
          gl_Position.xy = sn * p.w; }`);
  }
  function configureMaterial(m, look) {
    if (!m || !(m.isMeshStandardMaterial || m.isMeshBasicMaterial || m.isMeshLambertMaterial)) return;
    if (state.seen.get(m) === look) return;
    state.seen.set(m, look);
    if (look === 'retro') {
      m.onBeforeCompile = (sh, r) => { retroPatch(sh, r); m.userData.surfPatch?.(sh, r); }; m.customProgramCacheKey = () => 'retro' + (m.userData.surfPatch ? '+s' : '');
      if (m.map) { m.map.minFilter = m.map.magFilter = THREE.NearestFilter; m.map.generateMipmaps = false; m.map.needsUpdate = true; }
      if ('flatShading' in m) m.flatShading = false;
    } else {
      m.onBeforeCompile = (sh, r) => { m.userData.surfPatch?.(sh, r); }; m.customProgramCacheKey = () => 'lowpoly' + (m.userData.surfPatch ? '+s' : '');
      if ('flatShading' in m) m.flatShading = true;
    }
    m.needsUpdate = true;
  }
  function syncMaterials(scene) {
    scene.traverse((o) => {
      if (o.isMesh) {
        if (Array.isArray(o.material)) o.material.forEach((m) => configureMaterial(m, state.look)); else configureMaterial(o.material, state.look);
        o.castShadow = o.castShadow || state.look === 'lowpoly' ? o.castShadow : false;
      }
    });
  }

  function applyMoodToScene() {
    const m = state.mood, retro = state.look === 'retro';
    if (state.lights) state.lights.applyMood(m, retro ? 0.9 : 1);
    if (state.sky) state.sky.setMood(m);
    if (state.scene) {
      const dens = m.fogD * (retro ? 1.6 : 0.5);
      if (!state.scene.fog || !state.scene.fog.isFogExp2) state.scene.fog = new THREE.FogExp2(m.fog, dens);
      state.scene.fog.color.setHex(m.fog); state.scene.fog.density = dens;
      state.scene.background = new THREE.Color(m.fog);
    }
  }

  function applyLook(name) {
    if (name !== 'lowpoly' && name !== 'retro') throw new Error('unknown look: ' + name);
    state.look = name;
    const retro = name === 'retro';
    renderer.shadowMap.enabled = !retro ? true : true;
    if (state.lights) { state.lights.key.shadow.mapSize.set(retro ? 512 : 2048, retro ? 512 : 2048); state.lights.key.shadow.map?.dispose(); state.lights.key.shadow.map = null; state.lights.key.shadow.radius = retro ? 1 : 4; }
    postMat.uniforms.retro.value = retro ? 1 : 0;
    postMat.uniforms.grain.value = retro ? 0 : 0.035;
    postMat.uniforms.vig.value = retro ? 0.15 : 0.3;
    sizeTarget(); applyMoodToScene();
    if (state.scene) syncMaterials(state.scene);
  }

  function setDayPalette(seed) { state.mood = (seed && typeof seed === 'object') ? MOODS[seed.mood % MOODS.length] : pickMood(seed); applyMoodToScene(); return state.mood; }

  function ensureScene(scene) {
    if (state.scene === scene) return;
    state.scene = scene;
    state.lights = createLights(scene);
    state.sky = createSky(scene);
    applyLook(state.look);
  }

  function render(scene, camera) {
    ensureScene(scene);
    const dt = Math.min(state.clock.getDelta(), 0.1);
    state.lights.follow(camera.position.clone().setY(0).add(new THREE.Vector3(0, 0, 0)));
    state.sky.update(dt, camera);
    syncMaterials(scene);
    postMat.uniforms.time.value = state.clock.elapsedTime;
    renderer.setRenderTarget(target); renderer.clear(); renderer.render(scene, camera);
    renderer.setRenderTarget(null); renderer.render(postScene, postCam);
  }
  function resize() { sizeTarget(); }

  sizeTarget();
  const api = { renderer, render, resize, applyLook, setDayPalette, get look() { return state.look; }, get mood() { return state.mood; }, moods: MOODS, state };
  current = api;
  return api;
}

// Module-level convenience: applyLook on the most recently created renderer.
export function applyLook(name) { if (!current) throw new Error('createRenderer first'); current.applyLook(name); }
export function setDayPalette(seed) { if (!current) throw new Error('createRenderer first'); return current.setDayPalette(seed); }
