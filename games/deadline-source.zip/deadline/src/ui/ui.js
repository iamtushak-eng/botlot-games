// Deadline UI controller. Exposes window.DeadlineUI for the game core to call.
import { getYesterday, submitRun, modesUsedToday, utcDate } from '../social/store.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const EPOCH = Date.UTC(2026, 0, 1); // Day 1 = 2026-01-01
export const dayNumber = () => Math.floor((Date.now() - EPOCH) / 864e5) + 1;

const DEFAULT_KEYS = { forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD', jump: 'Space', camera: 'KeyV' };
const DEFAULTS = { look: 'lowpoly', camera: 'third', volume: 70, keys: DEFAULT_KEYS, deadzone: 15, invertY: false };
const load = () => { try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem('deadline.settings')), }; } catch { return { ...DEFAULTS }; } };
let settings = load();
const save = () => { try { localStorage.setItem('deadline.settings', JSON.stringify(settings)); } catch {} document.dispatchEvent(new CustomEvent('deadline:settings', { detail: settings })); };

const listeners = {};
const emit = (n, d) => (listeners[n] || []).forEach(f => f(d));
let current = { mode: null, progress: 0, died: false, pos: null, inputs: null };

export function show(name) {
  $$('.screen').forEach(s => s.classList.toggle('active', s.dataset.screen === name));
  $('#screens').style.pointerEvents = name ? 'auto' : 'none';
  if (name === 'title') { $('#title-day').textContent = `No. ${dayNumber()}`; refreshRides(); tickClock(); }
  if (name === 'modes') refreshModes();
  if (name === 'settings') syncSettings();
  if (name === 'social') { $('#social-note').textContent = ''; $('#practice').hidden = true; }
  if (name === 'results') fillResults();
}
const MODE_NAMES = { momentum: 'On foot', board: 'Skateboard', bike: 'Bike', precision: 'Precision', ragdoll: 'Ragdoll' };
export const modeName = (m) => MODE_NAMES[m] || m;
function refreshRides() {
  const used = modesUsedToday();
  $$('.ride').forEach(b => { const u = used.includes(b.dataset.mode); b.classList.toggle('used', u); b.disabled = u; b.querySelector('.r-state').textContent = u ? 'spent' : 'ready'; });
}
let clockTimer = null;
function tickClock() {
  clearInterval(clockTimer);
  const f = () => { const n = new Date(), m = Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate() + 1) - n.getTime(), h = Math.floor(m / 3.6e6), mi = Math.floor(m % 3.6e6 / 6e4), se = Math.floor(m % 6e4 / 1e3), el = $('#reset-in'); if (el) el.textContent = [h, mi, se].map(x => String(x).padStart(2, '0')).join(':'); };
  f(); clockTimer = setInterval(f, 1000);
}
function refreshModes() {
  const used = modesUsedToday();
  $$('.mode').forEach(b => { const u = used.includes(b.dataset.mode); b.classList.toggle('used', u); b.disabled = u; b.setAttribute('aria-disabled', u); });
}

function applyLook() { document.body.dataset.look = settings.look; }
function syncSettings() {
  const f = $('#settings-form');
  f.look.value = settings.look; f.camera.value = settings.camera;
  f.volume.value = settings.volume; $('#vol-out').textContent = settings.volume;
  f.deadzone.value = settings.deadzone; $('#dz-out').textContent = settings.deadzone;
  f.invertY.checked = settings.invertY;
  renderBindings();
}
function renderBindings() {
  const box = $('#bindings'); box.innerHTML = '';
  for (const [action, code] of Object.entries(settings.keys)) {
    const l = document.createElement('span'); l.textContent = action;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'bind-key'; b.textContent = code.replace(/^Key/, '');
    b.onclick = () => {
      b.classList.add('listening'); b.textContent = 'press key';
      const h = e => { e.preventDefault(); document.removeEventListener('keydown', h, true);
        if (e.code !== 'Escape') { settings.keys = { ...settings.keys, [action]: e.code }; save(); }
        renderBindings(); };
      document.addEventListener('keydown', h, true);
    };
    box.append(l, b);
  }
}
$('#settings-form').addEventListener('input', e => {
  const f = e.target.form, n = e.target.name;
  if (n === 'look' || n === 'camera') settings[n] = e.target.value;
  if (n === 'volume') { settings.volume = +e.target.value; $('#vol-out').textContent = e.target.value; }
  if (n === 'deadzone') { settings.deadzone = +e.target.value; $('#dz-out').textContent = e.target.value; }
  if (n === 'invertY') settings.invertY = e.target.checked;
  applyLook(); save();
});
$('#settings-form').addEventListener('submit', e => e.preventDefault());
$('#reset-keys').onclick = () => { settings.keys = { ...DEFAULT_KEYS }; save(); renderBindings(); };
window.addEventListener('gamepadconnected', e => { $('#pad-status').textContent = 'Connected: ' + e.gamepad.id; });
window.addEventListener('gamepaddisconnected', () => { $('#pad-status').textContent = 'No pad detected. Press any button on it.'; });

// HUD
const fmt = s => `${Math.floor(s / 60)}:${String(Math.max(0, Math.ceil(s % 60))).padStart(2, '0')}`;
export function hud({ progress, speed, timeLeft, mode }) {
  $('#hud').hidden = false;
  if (mode) $('#hud-mode').textContent = modeName(mode);
  const p = Math.max(0, Math.min(100, progress ?? 0));
  $('#hud-fill').style.width = p + '%'; $('#hud-pct').textContent = Math.floor(p) + '%';
  $('.hud-bar').setAttribute('aria-valuenow', Math.floor(p));
  if (speed != null) $('#hud-speed').textContent = Math.round(speed);
  if (timeLeft != null) { const t = $('#hud-timer'); t.textContent = fmt(timeLeft); t.classList.toggle('low', timeLeft <= 10); }
}
export const hideHud = () => { $('#hud').hidden = true; };

// Results
export function shareText({ day = dayNumber(), progress, died, percentile }) {
  const p = Math.floor(progress);
  const head = died ? `Day ${day}: died at ${p}%` : `Day ${day}: finished`;
  return percentile != null ? `${head}, further than ${percentile}% of players` : head;
}
function fillResults() {
  const r = current;
  $('#card-day').textContent = `Day ${dayNumber()}`;
  $('#card-line').textContent = shareText({ ...r }).replace(/^Day \d+: /, '');
  $('#card-meta').textContent = `${modeName(r.mode || '')}, ${utcDate()}`;
}
$('#copy-share').onclick = async () => {
  const text = shareText({ ...current });
  try { await navigator.clipboard.writeText(text); $('#copy-status').textContent = 'Copied.'; }
  catch {
    const ta = document.createElement('textarea'); ta.value = text; document.body.append(ta); ta.select();
    try { document.execCommand('copy'); $('#copy-status').textContent = 'Copied.'; } catch { $('#copy-status').textContent = 'Copy failed: ' + text; }
    ta.remove();
  }
};

// Death + end of run
export async function die({ mode, progress, pos, inputs, cause }) {
  hideHud();
  const res = await submitRun({ date: utcDate(), mode, progress, died: true, pos, inputs });
  current = { mode, progress, died: true, pos, inputs, percentile: res.percentile ?? null };
  $('#death-pct').textContent = Math.floor(progress);
  if (cause) $('#death-cause').textContent = cause;
  show('death');
  return res;
}
export async function finish({ mode, progress = 100, inputs }) {
  hideHud();
  const res = await submitRun({ date: utcDate(), mode, progress, died: false, pos: null, inputs });
  current = { mode, progress, died: false, pos: null, inputs, percentile: res.percentile ?? null };
  show('results');
  return res;
}

// Navigation
document.addEventListener('click', async e => {
  const go = e.target.closest('[data-go]'); if (go) return show(go.dataset.go);
  const pr = e.target.closest('[data-practice]'); if (pr) { current = { ...current, mode: pr.dataset.practice }; show(null); emit('practice', { mode: pr.dataset.practice, settings }); return; }
  const m = e.target.closest('.ride, .mode, [data-start]'); if (m && !m.disabled) { m.dataset.mode = m.dataset.mode || m.dataset.start; current = { ...current, mode: m.dataset.mode }; show(null); emit('start', { mode: m.dataset.mode, settings }); return; }
  const s = e.target.closest('[data-social]');
  if (s) {
    const choice = s.dataset.social;
    $$('.choice-card').forEach(c => c.classList.toggle('picked', c === s));
    const mode = current.mode || 'precision';
    const data = await getYesterday({ mode });
    const n = choice === 'ghosts' ? data.ghosts.length : data.deaths.length;
    $('#social-note').textContent = `${n} ${choice === 'ghosts' ? 'ghosts' : 'death markers'} loaded for ${data.date}.`;
    try { localStorage.setItem('deadline.social', choice); } catch {}
    $('#practice').hidden = false;
    emit('social', { choice, data });
  }
});

window.DeadlineUI = { show, hud, hideHud, die, finish, shareText, settings: () => settings, on: (n, f) => (listeners[n] ||= []).push(f) };
applyLook(); show('title');
