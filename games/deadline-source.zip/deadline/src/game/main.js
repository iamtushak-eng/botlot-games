// The game itself: one call to startGame() plays one attempt at one mode on one day's course.
import * as THREE from 'three';
import { generateLevel, surfaceAtZ } from './levelgen.js';
import { buildWorld, TICK, decodeRec, quant } from './sim.js';
import { Bot } from './bot.js';
import { Input } from './input.js';
import { CameraRig } from './camera.js';
import { Run } from './run.js';
import { buildScene } from './scene.js';
import { makeRunner } from './runner.js';
import { crowdMarkers, ghostSpecs } from './crowd.js';
import { getPose } from '../physics/index.js';
import { utcDateString, yesterdayString } from './rng.js';

const lerp = (a, b, t) => a + (b - a) * t;
const IDLE = { moveX: 0, moveZ: 0, jump: false, jumpHeld: false, slide: false, grab: false, yaw: 0 };
const CAUSES = { void: 'You fell. The drop is a long one.', saw: 'The saw does not negotiate.', kill: 'Spikes. They were right there.', spikes: 'Spikes. They were right there.', timeout: 'The clock ran out.' };

export function startGame({ canvas, R, models, audio, mode, practice = false, settings, ui, social = 'markers', yesterday = null, onLeave = () => {}, onEnd = () => {} }) {
  const date = practice ? yesterdayString() : utcDateString();
  const level = generateLevel(date, mode);
  const world = buildWorld(level);
  let ch = world.createCharacter({ mode, pos: level.start });
  const run = new Run({ mode, practice, goalZ: level.goal.z });
  const isRag = mode === 'ragdoll';

  // ---- scene -------------------------------------------------------------------------------------
  R.setDayPalette({ mood: level.mood }); R.applyLook(settings.look || 'lowpoly');
  const S = buildScene(level, models), scene = S.scene;
  const camera = new THREE.PerspectiveCamera(70, canvas.clientWidth / Math.max(1, canvas.clientHeight), 0.1, 700);
  const rig = new CameraRig(camera, world); rig.third = settings.camera !== 'first';
  const input = new Input(canvas); input.configure(settings); input.onToggleView = () => { rig.toggle(); };
  try { canvas.requestPointerLock?.(); } catch {}
  audio.start(); audio.setVolume?.((settings.volume ?? 70) / 100);

  const VEH = { board: 'board', bike: 'bike' }[mode] || null;
  const runner = makeRunner(models.runner, { ragdoll: isRag, veh: VEH ? { kind: VEH, models } : null }); scene.add(runner.root);
  if (!isRag) runner.setHeading(0);

  // soft contact shadow so landings are readable; sits on whatever is below the player
  const blobTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 2, 32, 32, 31); g.addColorStop(0, 'rgba(0,0,0,.6)'); g.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
  const blob = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 1.3), new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
  blob.rotation.x = -Math.PI / 2; blob.renderOrder = 2; scene.add(blob);

  // ---- dust / impact puffs ---------------------------------------------------------------------
  const puffs = []; const puffGeo = new THREE.IcosahedronGeometry(0.07, 0), puffMat = new THREE.MeshBasicMaterial({ color: '#d8d0bc', transparent: true, opacity: 0.8, depthWrite: false });
  const puff = (p, n, speed, up = 1.2) => { for (let i = 0; i < n; i++) { const m = new THREE.Mesh(puffGeo, puffMat.clone()); m.position.set(p[0], p[1] + 0.05, p[2]); const a = Math.random() * 6.28; m.userData = { v: [Math.cos(a) * speed * (0.3 + Math.random()), up * Math.random() * 1.5, Math.sin(a) * speed * (0.3 + Math.random())], life: 0.5 + Math.random() * 0.3, t: 0 }; scene.add(m); puffs.push(m); } };

  // ---- yesterday's field (practice only): markers or ghosts, the player's choice -------------------
  const ghosts = [];
  if (practice) {
    if (social !== 'ghosts') {
      const pts = [...crowdMarkers(level, mode, date), ...((yesterday && yesterday.deaths) || [])].map((d) => ({ pos: d.pos }));
      const cells = new Map();
      for (const p of pts) { const k = Math.round(p.pos[0] / 2) + ',' + Math.round(p.pos[2] / 2); const c = cells.get(k); if (c) { c.n++; } else cells.set(k, { pos: p.pos, n: 1 }); }
      const red = new THREE.MeshBasicMaterial({ color: '#c8321f' }), glow = new THREE.MeshBasicMaterial({ color: '#c8321f', transparent: true, opacity: 0.2, depthWrite: false });
      for (const c of cells.values()) {
        const s = Math.min(2.6, 0.8 + c.n * 0.28), g = new THREE.Group();
        for (const rot of [Math.PI / 4, -Math.PI / 4]) { const bar = new THREE.Mesh(new THREE.BoxGeometry(0.9 * s, 0.05, 0.14 * s), red); bar.rotation.y = rot; g.add(bar); }
        const stain = new THREE.Mesh(new THREE.CircleGeometry(0.9 * s, 14), glow); stain.rotation.x = -Math.PI / 2; stain.position.y = 0.01; g.add(stain);
        const beam = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.4 * s, 0.06), glow); beam.position.y = 1.2 * s; g.add(beam);
        g.position.set(c.pos[0], c.pos[1] + 0.04, c.pos[2]); scene.add(g);
      }
    } else {
      const mk = (src) => {
        const w = buildWorld(level), c = w.createCharacter({ mode, pos: level.start });
        const rn = makeRunner(models.runner, { ghost: true, ragdoll: isRag, tint: src.tint, veh: VEH ? { kind: VEH, models } : null }); scene.add(rn.root);
        return { w, c, rn, bot: src.bot ? new Bot(w, level, c, src.bot) : null, rec: src.rec || null, tick: 0, dead: false, fade: 0, prev: [...c.pos], prevPts: null };
      };
      for (const sp of ghostSpecs(level, date, mode, 4)) ghosts.push(mk({ tint: sp.tint, bot: { failZ: sp.failZ, laneBias: sp.laneBias, lookBias: sp.lookBias } }));
      for (const g of ((yesterday && yesterday.ghosts) || []).slice(0, 2)) { try { ghosts.push(mk({ tint: '#ffffff', rec: decodeRec(g.inputs) })); } catch {} }
    }
  }

  // ---- per-run state ------------------------------------------------------------------------------
  // ---- death scene: the body goes limp (physics ragdoll), time slows, colour drains --------------
  const fx = document.createElement('div'); fx.id = 'deathfx'; document.body.appendChild(fx);
  let body = null, bodyRig = null, bodyPrev = null, tScale = 1, driftYaw = 0;
  const bodyPts = () => body.ragdoll.pts.map((q) => q.p.slice());
  function spawnBody(cause) {
    body = world.createCharacter({ mode: 'ragdoll', pos: [ch.pos[0], ch.pos[1] + 0.05, ch.pos[2]] }); body.limp = true;
    const v = [ch.vel[0], Math.max(ch.vel[1], 0) + (cause === 'saw' ? 4 : 1.5), ch.vel[2] * (cause === 'saw' ? -0.25 : 1)];
    for (const q of body.ragdoll.pts) for (let k = 0; k < 3; k++) q.o[k] = q.p[k] - v[k] / 120 + (Math.random() - 0.5) * 0.012;
    bodyRig = makeRunner(models.runner, { ragdoll: true }); scene.add(bodyRig.root); bodyPrev = bodyPts();
    tScale = 0.22; canvas.style.transition = 'filter 1.2s ease'; canvas.style.filter = 'saturate(.35) contrast(1.08) brightness(.92)'; fx.classList.add('on');
  }
  let raf = 0, last = performance.now(), acc = 0, frameN = 0, finalised = false, landed = 0, fallVis = 0, respawnAt = null;
  let lastCp = level.start.slice(), cpIdx = 0, prevPos = [...ch.pos], prevPts = null;
  const snapPts = () => (isRag ? ch.ragdoll.pts.map((q) => q.p.slice()) : null);
  prevPts = snapPts();
  const cdEl = document.getElementById('countdown');
  const showCd = (txt, sub = '') => { if (!cdEl) return; cdEl.hidden = !txt; cdEl.innerHTML = txt ? `<b>${txt}</b><span>${sub}</span>` : ''; };
  const label = (practice ? 'Practice · ' : '') + mode[0].toUpperCase() + mode.slice(1);

  function handleEvents() {
    for (const e of world.events) {
      if (e.id !== ch.id) continue;
      if (e.type === 'land') { landed = Math.min(14, e.speed); audio.handleEvent({ type: 'land', impact: e.speed }); if (e.speed > 9) puff(ch.pos, Math.min(10, Math.round(e.speed / 2)), 2.4 + e.speed * 0.1); if (e.speed > 12) rig.kick(Math.min(1, e.speed / 28)); }
      else if (e.type === 'jump') { audio.handleEvent({ type: 'jump' }); puff(ch.pos, 3, 1.4); }
      else if (e.type === 'slide') { audio.handleEvent({ type: 'footstep' }); }
      else if (e.type === 'crumble') audio.handleEvent({ type: 'crumble' });
      else if (e.type === 'grab') audio.handleEvent({ type: 'grab' });
      else if (e.type === 'death') { run.end('dead', CAUSES[e.cause] || CAUSES.void); audio.handleEvent({ type: 'death' }); rig.kick(1); if (e.cause !== 'void') spawnBody(e.cause); if (e.cause === 'saw') puff([ch.pos[0], ch.pos[1] + 1, ch.pos[2]], 14, 4, 3); }
      else if (e.type === 'crumble') audio.handleEvent({ type: 'crumble' });
    }
    world.events.length = 0;
  }

  function stepTick() {
    prevPos = ch.pos.slice(); prevPts = snapPts();
    for (const g of ghosts) { g.prev = g.c.pos.slice(); g.prevPts = isRag ? g.c.ragdoll.pts.map((q) => q.p.slice()) : null; }
    if (run.state === 'running') {
      const inp = quant(input.poll()); ch.setInput(inp);
      run.record({ moveX: inp.moveX, moveZ: inp.moveZ, jump: inp.jump, jumpHeld: inp.jump, slide: inp.slide, grab: inp.grab, yaw: inp.yaw }, ch.pos[2]);
      world.step(TICK); handleEvents();
      if (run.state === 'running') {
        if (ch.pos[1] < level.deathY) { run.end('dead', CAUSES.void); audio.handleEvent({ type: 'death' }); }
        else if (ch.pos[2] >= level.goal.z) { run.end('finished', 'finished'); audio.handleEvent({ type: 'goal' }); }
        while (cpIdx < level.checkpoints.length && ch.pos[2] > level.checkpoints[cpIdx].z) { lastCp = [level.checkpoints[cpIdx].pos[0], level.checkpoints[cpIdx].pos[1] + 0.05, level.checkpoints[cpIdx].pos[2]]; audio.handleEvent({ type: 'checkpoint' }); cpIdx++; }
      }
    } else { world.step(TICK); world.events.length = 0; }
    for (const g of ghosts) {
      if (g.dead) { g.fade += TICK; continue; }
      if (run.state === 'countdown') continue;
      const inp = g.bot ? quant(g.bot.think()) : (g.rec[g.tick] || IDLE); g.tick++;
      g.c.setInput(inp); g.w.step(TICK);
      if (g.c.dead || g.c.pos[1] < level.deathY || g.c.pos[2] >= level.goal.z) g.dead = true;
      g.w.events.length = 0;
    }
  }

  function finalise() {
    if (finalised) return; finalised = true;
    const pct = run.state === 'finished' ? 100 : Math.floor(run.progress * 100);
    const pos = [ch.pos[0], ch.pos[1], ch.pos[2]].map((v) => Math.round(v * 100) / 100);
    showCd('');
    if (run.state === 'finished') ui.finish({ mode, progress: 100, inputs: run.encoded });
    else ui.die({ mode, progress: pct, pos, inputs: run.encoded, cause: run.cause });
  }

  function respawn() {
    world.chars.splice(world.chars.indexOf(ch), 1);
    ch = world.createCharacter({ mode, pos: lastCp });
    for (const d of S.dyn.boxes) { const b = world.boxes[d.box]; b.dead = false; b.touched = -1; d.fall = 0; d.mesh.visible = true; d.mesh.rotation.set(0, 0, 0); d.mesh.position.copy(d.base); }
    if (body) { world.chars.splice(world.chars.indexOf(body), 1); scene.remove(bodyRig.root); body = null; bodyRig = null; driftYaw = 0; }
    canvas.style.filter = ''; fx.classList.remove('on'); tScale = 1;
    prevPos = ch.pos.slice(); prevPts = snapPts(); run.state = 'running'; fallVis = 0; respawnAt = null; run.cause = null;
  }

  function onKey(e) { if (e.code === 'KeyP' && practice) { stop(); onLeave(); } }
  addEventListener('keydown', onKey);
  const onResize = () => { camera.aspect = canvas.clientWidth / Math.max(1, canvas.clientHeight); camera.updateProjectionMatrix(); R.resize(); };
  addEventListener('resize', onResize);

  function frame(now) {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000); last = now; frameN++;
    if (run.state === 'countdown') {
      const was = Math.ceil(run.count);
      if (run.tickCountdown(dt)) { showCd('GO', ''); setTimeout(() => showCd(''), 450); audio.handleEvent({ type: 'checkpoint' }); }
      else { const n = Math.ceil(run.count); showCd(String(n), practice ? "Practice on yesterday's course. P to leave." : level.theme + ' · one life'); if (n !== was) audio.handleEvent({ type: 'grab' }); }
      input.poll(); // keep mouse-look live while counting down
    } else { tScale += (1 - tScale) * Math.min(1, dt * 0.9); if (run.state === 'dead' && body) tScale = Math.min(tScale, 0.2 + Math.min(0.8, (performance.now() - run.endedAt) / 2600)); acc += dt * tScale; while (acc >= TICK) { acc -= TICK; if (body) bodyPrev = bodyPts(); stepTick(); } }
    const alpha = run.state === 'countdown' ? 1 : acc / TICK;

    // end-of-run handling
    if (run.state === 'dead' || run.state === 'finished') {
      const since = (performance.now() - run.endedAt) / 1000;
      if (run.state === 'dead' && (run.cause === CAUSES.void)) { fallVis += dt; }
      if (practice) {
        if (run.state === 'dead' && since > 1.3 && !respawnAt) { respawnAt = true; respawn(); }
        if (run.state === 'finished' && since > 1.2 && !finalised) { finalised = true; showCd('Course cleared', 'Practice run. P to leave.'); setTimeout(() => { stop(); onLeave(); }, 1800); }
      } else if (since > (run.state === 'dead' ? (body ? 2.6 : 1.5) : 1.1)) { stop(); finalise(); onEnd(); return; }
    }

    // sync visuals ------------------------------------------------------------------------------
    S.sync(world, dt, alpha);
    const px = lerp(prevPos[0], ch.pos[0], alpha), py = lerp(prevPos[1], ch.pos[1], alpha) - fallVis * fallVis * 9, pz = lerp(prevPos[2], ch.pos[2], alpha);
    let focus = [px, py, pz], hs = Math.hypot(ch.vel[0], ch.vel[2]);
    if (isRag) {
      const P = ch.ragdoll.pts.map((q, i) => [lerp(prevPts[i][0], q.p[0], alpha), lerp(prevPts[i][1], q.p[1], alpha) - fallVis * fallVis * 9, lerp(prevPts[i][2], q.p[2], alpha)]);
      runner.poseRagdoll(P); focus = [P[3][0], P[3][1] - 0.78, P[3][2]];
    } else {
      runner.root.position.set(px, py, pz);
      runner.update(run.state === 'dead' ? 'dead' : ch.state, hs, ch.vel, dt, landed); landed = 0;
    }
    runner.root.visible = rig.third && !body;
    if (body) { const P = body.ragdoll.pts.map((q, i) => [lerp(bodyPrev[i][0], q.p[0], alpha), lerp(bodyPrev[i][1], q.p[1], alpha), lerp(bodyPrev[i][2], q.p[2], alpha)]); bodyRig.poseRagdoll(P); focus = [P[3][0], P[3][1] - 0.4, P[3][2]]; driftYaw += dt * 0.35; }
    { const h = world.raycast([px, py + 0.3, pz], [0, -1, 0], 40); blob.visible = !!h && run.state !== 'dead'; if (h) { const gy = py + 0.3 - h.distance; blob.position.set(px, gy + 0.03, pz); const k = Math.max(0.35, 1 - (py - gy) / 9); blob.scale.setScalar(k * 1.1); blob.material.opacity = Math.max(0.15, k); } }
    for (const g of ghosts) {
      g.rn.root.visible = !(g.dead && g.fade > 1.2);
      if (isRag) { const P = g.c.ragdoll.pts.map((q, i) => [lerp(g.prevPts?.[i]?.[0] ?? q.p[0], q.p[0], alpha), lerp(g.prevPts?.[i]?.[1] ?? q.p[1], q.p[1], alpha), lerp(g.prevPts?.[i]?.[2] ?? q.p[2], q.p[2], alpha)]); g.rn.poseRagdoll(P); }
      else { g.rn.root.position.set(lerp(g.prev[0], g.c.pos[0], alpha), lerp(g.prev[1], g.c.pos[1], alpha), lerp(g.prev[2], g.c.pos[2], alpha)); g.rn.update(g.dead ? 'dead' : g.c.state, Math.hypot(g.c.vel[0], g.c.vel[2]), g.c.vel, dt); }
    }
    for (let i = puffs.length - 1; i >= 0; i--) { const m = puffs[i], u = m.userData; u.t += dt; if (u.t > u.life) { scene.remove(m); m.material.dispose(); puffs.splice(i, 1); continue; } m.position.x += u.v[0] * dt; m.position.y += u.v[1] * dt; m.position.z += u.v[2] * dt; u.v[1] -= 4 * dt; m.material.opacity = 0.8 * (1 - u.t / u.life); m.scale.setScalar(1 + u.t * 1.2); }

    const yaw = input.yaw + driftYaw, pitch = body ? Math.max(input.pitch, 0.35) : input.pitch;
    rig.update(focus, yaw, pitch, dt, hs, ch.onGround);
    audio.update(Math.min(1, hs / 14), Math.max(0, Math.min(1, (-ch.vel[1] - 9) / 14)) * (run.state === 'running' ? 1 : 0), Math.max(0, (run.progress - 0.8) * 5));
    R.render(scene, camera);
    if (frameN % 3 === 0 && run.state !== 'countdown') ui.hud({ progress: run.progress * 100, speed: hs, timeLeft: run.timeLeft, mode: label });
  }
  ui.hud({ progress: 0, speed: 0, timeLeft: 90, mode: label });
  raf = requestAnimationFrame(frame);

  function stop() {
    cancelAnimationFrame(raf); input.dispose(); removeEventListener('keydown', onKey); removeEventListener('resize', onResize);
    scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    canvas.style.filter = ''; canvas.style.transition = ''; fx.remove();
    audio.stopMusic?.(); showCd("");
  }
  return {
    level, world, run, stop, scene, R, audio,
    applySettings(s) { input.configure(s); rig.third = s.camera !== 'first'; audio.setVolume?.((s.volume ?? 70) / 100); if (s.look) R.applyLook(s.look); },
  };
}
