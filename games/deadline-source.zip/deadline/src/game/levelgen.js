// Daily level generator. Pure function of (date, mode): same inputs, same course, on every machine.
// Output is physics-ready (arrays, not objects) plus render hints (props, themes, mood).
import { makeRng } from './rng.js';

// weights are per-segment probabilities that get normalised; "mood" indexes render/lights.js MOODS.
export const THEMES = [
  { id: 'rooftops',   name: 'Rooftops',        mood: 4, w: { hop: 5, steps: 1.5, ramp: 1.5, hall: 1.2, mover: 0.8, bridge: 0.6, rope: 0.8 }, ice: 0.03, crumble: 0.14 },
  { id: 'factory',    name: 'Foundry Floor',   mood: 2, w: { hop: 4, steps: 1.0, ramp: 1.2, hall: 2.4, mover: 1.4, bridge: 0.3, rope: 0.4 }, ice: 0.02, crumble: 0.08 },
  { id: 'void',       name: 'The Void',        mood: 9, w: { hop: 4, steps: 2.4, ramp: 0.8, hall: 0.6, mover: 1.8, bridge: 0.4, rope: 0.6 }, ice: 0.04, crumble: 0.26 },
  { id: 'subway',     name: 'Flooded Subway',  mood: 8, w: { hop: 4.5, steps: 1.2, ramp: 1.4, hall: 1.6, mover: 0.7, bridge: 1.2, rope: 0.3 }, ice: 0.02, crumble: 0.1 },
  { id: 'canyon',     name: 'Red Canyon',      mood: 7, w: { hop: 4, steps: 1.0, ramp: 2.2, hall: 0.8, mover: 0.5, bridge: 1.8, rope: 1.4 }, ice: 0.0, crumble: 0.12 },
  { id: 'ice',        name: 'Ice Cavern',      mood: 3, w: { hop: 4.5, steps: 1.2, ramp: 1.6, hall: 0.8, mover: 0.6, bridge: 0.8, rope: 0.6 }, ice: 0.42, crumble: 0.04 },
  { id: 'site',       name: 'Construction',    mood: 1, w: { hop: 4, steps: 1.6, ramp: 1.4, hall: 1.8, mover: 1.0, bridge: 0.8, rope: 0.8 }, ice: 0.02, crumble: 0.1 },
  { id: 'clocktower', name: 'Clocktower',      mood: 0, w: { hop: 3.6, steps: 1.4, ramp: 1.2, hall: 2.2, mover: 1.6, bridge: 0.3, rope: 0.5 }, ice: 0.02, crumble: 0.1 },
  { id: 'neon',       name: 'Night Market',    mood: 6, w: { hop: 4.2, steps: 1.6, ramp: 1.0, hall: 1.6, mover: 1.2, bridge: 0.8, rope: 0.7 }, ice: 0.06, crumble: 0.12 },
  { id: 'docks',      name: 'Sky Docks',       mood: 5, w: { hop: 4, steps: 1.0, ramp: 1.0, hall: 1.0, mover: 0.8, bridge: 2.0, rope: 1.6 }, ice: 0.02, crumble: 0.1 },
];

// Per-mode tuning. gapMax() is the longest edge-to-edge jump that mode can be asked for, already
// derated from what the physics allows (see tools/measure_reach.mjs, which checks these numbers).
export const PROFILE = {
  precision: { length: 300, width: [3.0, 4.4], len: [3.2, 6.5], gapMin: 1.0, upMax: 1.0,
    gapMax: (z, dy) => 3.0 - 0.45 * Math.max(0, dy) + 0.25 * Math.min(2, Math.max(0, -dy)),
    stone: 2.0, saw: 0.9, noRope: false, noCrumble: false },
  momentum:  { length: 640, width: [5.0, 8.0], len: [9, 16], gapMin: 2.5, upMax: 1.1,
    gapMax: (z, dy) => Math.max(3.0, 0.75 * speedAt(z) * 0.62 - 2.5 * Math.max(0, dy)),
    stone: 2.4, saw: 1.0, noRope: false, noCrumble: false },
  ragdoll:   { length: 190, width: [7.0, 9.0], len: [5, 9], gapMin: 0.05, upMax: 0,
    gapMax: () => 0.45, // a floppy body can shuffle over cracks, not leap
    stone: 2.6, saw: 1.0, noRope: true, noCrumble: true },
};

// expected momentum-mode running speed after covering z metres from a standing start (boost ramps 2.2 m/s per second)
export function speedAt(z) { const t = (-7 + Math.sqrt(49 + 4.4 * Math.max(0, z))) / 2.2; return Math.min(16, 7 + 2.2 * t); }

const lerp = (a, b, t) => a + (b - a) * t;

const WHEELED_MODES = ['board', 'bike'];
export function generateLevel(date, mode = 'precision') {
  const wheeled = WHEELED_MODES.includes(mode), mom = mode === 'momentum' || wheeled;
  const theme = THEMES[Math.floor(makeRng(date, 'theme')() * THEMES.length)];
  const r = makeRng(date, mode + '|' + theme.id);
  const P = PROFILE[mom ? 'momentum' : mode] || PROFILE.precision;
  const L = {
    date, mode, theme: theme.name, themeId: theme.id, mood: theme.mood,
    boxes: [], ramps: [], ropes: [], bridges: [], hazards: [], checkpoints: [], props: [], surfaces: [],
    goal: null, start: [0, 0.05, 0], length: P.length, deathY: 0,
  };
  const box = (x, y, z, w, d, surface = 'normal', extra = {}) => {
    const b = { min: [x - w / 2, y - 1, z - d / 2], max: [x + w / 2, y, z + d / 2], surface, role: 'platform', ...extra };
    L.boxes.push(b); return b;
  };
  const cur = { x: 0, y: 0, z: 5, w: 10 }; // z = far edge of the last solid piece
  box(0, 0, 0, 10, 10, 'normal', { role: 'start' });
  L.surfaces.push({ z0: -5, z1: 5, x: 0, y: 0, w: 10 });

  const pickWeights = (t) => {
    const w = { ...theme.w };
    if (mode !== 'precision') w.steps *= 0.5;
    if (mom) { w.steps = 0; w.mover = 0; } // no air braking at speed: small landings would be unfair
    if (mode === 'ragdoll') { w.steps = 0; w.mover = 0; w.rope = 0; w.hall *= 0.7; w.bridge *= 1.4; w.ramp *= 1.4; }
    if (P.noRope) w.rope = 0;
    if (t < 0.12) { w.mover = 0; w.hall *= 0.3; w.rope *= 0.3; } // gentle opening
    return w;
  };
  const pick = (w) => { const keys = Object.keys(w); let tot = 0; for (const k of keys) tot += w[k]; let x = r() * tot; for (const k of keys) { x -= w[k]; if (x <= 0) return k; } return keys[0]; };
  const dxPick = (gap) => r.range(-1, 1) * Math.min(mode === 'ragdoll' ? 0.4 : 2.0, 0.5 + gap * 0.4);
  const surfacePick = (t, minLen) => {
    const k = r();
    if (!P.noCrumble && minLen >= 3 && k < theme.crumble * (0.3 + t)) return 'crumble';
    if (minLen >= 5.5 && r() < theme.ice * (0.4 + t)) return 'ice';
    return 'normal';
  };
  const gapFor = (t, dy) => {
    const mx = P.gapMax(cur.z, dy) * 0.94, mn = P.gapMin;
    const lo = lerp(mn, Math.max(mn, mx * 0.5), t), hi = lerp(Math.max(mn + 0.3, mx * 0.55), mx, t);
    return r.range(lo, Math.max(lo + 0.1, hi));
  };
  const dyFor = (t) => {
    const up = r.range(0, P.upMax), down = r.range(0, 2.2);
    const v = mode === 'ragdoll' ? (r() < 0.5 ? 0 : -Math.min(down, 1.2)) : r() < 0.55 ? up : -down * (t > 0.2 ? 1 : 0.4);
    return Math.max(-5 - cur.y, Math.min(9 - cur.y, v));
  };
  const lenW = () => [r.range(...P.len), r.range(...P.width)];
  const land = (w, len, y, gap, surface, extra = {}) => {
    const x = Math.max(-3, Math.min(3, cur.x + dxPick(gap)));
    const cz = cur.z + gap + len / 2;
    box(x, y, cz, w, len, surface, extra);
    L.surfaces.push({ z0: cz - len / 2, z1: cz + len / 2, x, y, w });
    Object.assign(cur, { x, y, z: cz + len / 2, w });
    return { x, cz };
  };

  while (cur.z < P.length - 14) {
    const t = cur.z / P.length;
    const kind = pick(pickWeights(t));

    if (kind === 'hop') {
      const dy = dyFor(t), gap = gapFor(t, dy), [len, w] = lenW();
      const surf = surfacePick(t, len), y = cur.y + dy;
      const L2 = surf === 'ice' ? Math.max(len, 6) : surf === 'crumble' && !mom ? Math.min(Math.max(len, 3.2), 4.5) : len;
      land(w, L2, y, surf === 'ice' ? Math.min(gap, 2.4) : gap, surf);
    } else if (kind === 'steps') {
      const n = r.int(3, 5), size = P.stone;
      let lastX = cur.x;
      for (let i = 0; i < n; i++) {
        const dy = i === 0 ? 0 : r.range(-0.4, 0.6), gap = i === 0 ? gapFor(t, dy) * 0.8 : Math.min(gapFor(t, dy), P.gapMax(cur.z, dy) * 0.75);
        const nx = Math.max(-4, Math.min(4, lastX + r.range(-1.6, 1.6)));
        const cz = cur.z + gap + size / 2, y = cur.y + dy;
        box(nx, y, cz, size, size, r() < theme.crumble * 0.7 && !P.noCrumble ? 'crumble' : 'normal', { role: 'step' });
        L.surfaces.push({ z0: cz - size / 2, z1: cz + size / 2, x: nx, y, w: size });
        Object.assign(cur, { x: nx, y, z: cz + size / 2, w: size }); lastX = nx;
      }
      // always finish a stepping sequence on a proper landing so the next segment starts fair
      const [len, w] = lenW(); land(w, Math.max(len, 4), cur.y, Math.min(gapFor(t, 0), 2.2), 'normal');
    } else if (kind === 'ramp') {
      const up = r() < 0.6, rise = r.range(1.2, 2.6) * (up ? 1 : -1), rl = r.range(6, 9), w = r.range(...P.width);
      const y0 = cur.y, y1 = Math.max(-5, Math.min(10, y0 + rise)), x = Math.max(-3, Math.min(3, cur.x + dxPick(1)));
      const z0 = cur.z + r.range(0.2, 0.8);
      const lowH = Math.min(y0, y1);
      L.ramps.push({ min: [x - w / 2, lowH, z0], max: [x + w / 2, Math.max(y0, y1), z0 + rl], heights: [y0, y0, y1, y1], surface: 'normal' });
      L.surfaces.push({ z0, z1: z0 + rl, x, y: (y0 + y1) / 2, w, slope: true });
      Object.assign(cur, { x, y: y1, z: z0 + rl, w });
      const [len, ww] = lenW(); land(ww, Math.max(len, 4), y1, r.range(0, 0.5), 'normal');
    } else if (kind === 'hall') {
      const w = r.range(6, 7.5) + (mode === 'ragdoll' ? 1.5 : 0), len = r.range(8, 13), gap = Math.min(gapFor(t, 0), 2.6), y = cur.y;
      const { x, cz } = land(w, len, y, gap, 'normal', { role: 'hall' });
      const z0 = cz - len / 2;
      const flavour = r();
      if (flavour < 0.5 * P.saw && !wheeled) { // sweeping saw: always leaves >= 4 m free, readable timing
        const amp = w / 2 - 1.4;
        L.hazards.push({ kind: 'saw', pos: [x, y + 0.95, cz], radius: 1.0, move: { axis: 0, amp, speed: r.range(0.3, 0.5) * (mode === 'ragdoll' ? 0.4 : wheeled ? 0.5 : 1), phase: r.range(0, 6.28) } });
      } else if (flavour < 0.8 || wheeled) { // spike gates: bands on both flanks, a clear lane down the middle (no forced weaving)
        const nb = r.int(2, 3), laneW = mode === 'ragdoll' || wheeled ? 3.6 : 2.8, laneX = x + r.range(-0.4, 0.4);
        for (let i = 0; i < nb; i++) {
          const bz = z0 + (i + 1) * len / (nb + 1);
          const lw = Math.max(0.6, laneX - laneW / 2 - (x - w / 2)), rw = Math.max(0.6, x + w / 2 - (laneX + laneW / 2));
          L.boxes.push({ min: [x - w / 2, y, bz - 0.7], max: [x - w / 2 + lw, y + 0.28, bz + 0.7], surface: 'kill', role: 'spikes' });
          L.boxes.push({ min: [x + w / 2 - rw, y, bz - 0.7], max: [x + w / 2, y + 0.28, bz + 0.7], surface: 'kill', role: 'spikes' });
        }
      } else if (mode !== 'ragdoll' && !wheeled) { // grinders on rails hugging both edges; the centre lane stays >= 2.5 m wide
        L.hazards.push({ kind: 'saw', pos: [x - (w / 2 - 0.5), y + 0.95, z0 + len * 0.35], radius: 0.9, move: { axis: 2, amp: 1.2, speed: 0.45, phase: 0 } });
        L.hazards.push({ kind: 'saw', pos: [x + (w / 2 - 0.5), y + 0.95, z0 + len * 0.65], radius: 0.9, move: { axis: 2, amp: 1.2, speed: 0.45, phase: 3.14 } });
      }
    } else if (kind === 'mover') {
      // a platform ferrying across a gap; both neighbours are wide enough to meet it anywhere on its travel
      const amp = 2.6, mw = 3.4, ml = 3.0, hop = Math.min(gapFor(t, 0) * 0.8, P.gapMax(cur.z, 0) * 0.62);
      const gap = hop * 2 + ml;
      // widen the departure edge by dropping a wide pad if the current one is narrow
      if (cur.w < 2 * amp + mw) { const padL = 4; land(2 * amp + mw, padL, cur.y, Math.min(gapFor(t, 0), 2.2), 'normal', { role: 'pad' }); }
      const mz = cur.z + hop + ml / 2;
      box(cur.x, cur.y, mz, mw, ml, 'normal', { role: 'mover', move: { axis: 0, amp, speed: r.range(0.16, 0.26), phase: r.range(0, 6.28) } });
      const z1 = cur.z + gap;
      const w = 2 * amp + mw, len = r.range(5, 8);
      box(cur.x, cur.y, z1 + len / 2, w, len, 'normal', { role: 'pad' });
      L.surfaces.push({ z0: cur.z, z1: z1 + len, x: cur.x, y: cur.y, w });
      Object.assign(cur, { z: z1 + len, w });
    } else if (kind === 'bridge') {
      const blen = r.range(7, 12) * (mode === 'ragdoll' ? 0.8 : 1), w = Math.min(r.range(3.2, 4.2), 4.2) * (mode === 'ragdoll' ? 1.4 : 1);
      L.bridges.push({ a: [cur.x, cur.y, cur.z], b: [cur.x, cur.y, cur.z + blen], planks: Math.round(blen * 1.2), sag: r.range(0.4, 0.9), width: w });
      L.surfaces.push({ z0: cur.z, z1: cur.z + blen, x: cur.x, y: cur.y, w });
      cur.z += blen; cur.w = w;
      const [len, ww] = lenW(); land(ww, Math.max(len, 4.5), cur.y, 0.05, 'normal', { role: 'pad' });
    } else if (kind === 'rope') {
      // jumpable gap with a swing rope above it: optional speed route, never required
      const dy = 0, gap = Math.min(gapFor(t, dy), P.gapMax(cur.z, 0) * 0.9), [len, w] = lenW();
      const rz = cur.z + gap / 2, ry = cur.y + 6.6;
      L.ropes.push({ anchor: [cur.x, ry, rz], length: 5.0, segments: 10, stiffness: 1 });
      land(w, len, cur.y, gap, 'normal');
    }

    // occasional low wall beside the path in momentum mode (wall-run lane), never blocking
    if (mode === 'momentum' && r() < 0.18) {
      const s = L.surfaces[L.surfaces.length - 1];
      if (s && !s.slope && s.z1 - s.z0 >= 8) L.boxes.push({ min: [s.x + s.w / 2 + 0.3, s.y, s.z0 + 1], max: [s.x + s.w / 2 + 1.1, s.y + 6, s.z1 - 1], surface: 'normal', role: 'wall' });
    }
    // checkpoint flags every ~20% of the way
    if (L.checkpoints.length < Math.floor(cur.z / (P.length * 0.2)) && L.checkpoints.length < 4) {
      const s = L.surfaces[L.surfaces.length - 1];
      L.checkpoints.push({ pos: [s.x, s.y + (s.slope ? 0 : 0), s.z0 + (s.z1 - s.z0) * 0.5], z: s.z0 + (s.z1 - s.z0) * 0.5, index: L.checkpoints.length });
    }
  }

  // goal platform
  const gz = cur.z + 1.5;
  box(cur.x, cur.y, gz + 7, 12, 14, 'normal', { role: 'goal' });
  L.surfaces.push({ z0: gz, z1: gz + 14, x: cur.x, y: cur.y, w: 12 });
  const goalZ = gz + 9;
  L.goal = { pos: [cur.x, cur.y, goalZ], z: goalZ, size: [5, 4.5, 0.6] };
  L.length = goalZ;
  L.deathY = Math.min(...L.boxes.map(b => b.min[1]), ...L.ramps.map(rp => rp.min[1])) - 14;

  // ---- visual-only dressing (no collision) -----------------------------------------------------
  const pr = makeRng(date, 'props|' + theme.id + '|' + mode);
  for (const b of L.boxes) {
    if (b.role === 'wall' || b.role === 'spikes') continue;
    const w = b.max[0] - b.min[0], d = b.max[2] - b.min[2], cx = (b.min[0] + b.max[0]) / 2, cz = (b.min[2] + b.max[2]) / 2;
    if (d > 4 && pr() < 0.55) L.props.push({ type: 'pillar', pos: [cx + pr.range(-w / 4, w / 4), b.min[1] - 0.2, cz], w: pr.range(1.4, 2.6), h: pr.range(14, 40), d: pr.range(1.4, 2.6) });
    if (pr() < 0.35) L.props.push({ type: 'pipe', pos: [cx, b.min[1] - 0.6, cz], len: Math.max(d, 4), side: pr() < 0.5 ? -1 : 1, w });
  }
  const skylineN = Math.floor(L.length / 14);
  for (let i = 0; i < skylineN; i++) {
    const side = i % 2 ? 1 : -1;
    L.props.push({ type: 'tower', pos: [side * pr.range(22, 60), L.deathY + 4, pr.range(-20, L.length + 40)], w: pr.range(8, 18), h: pr.range(30, 90), d: pr.range(8, 18) });
  }
  for (let i = 0; i < Math.floor(L.length / 70); i++) L.props.push({ type: 'billboard', pos: [(i % 2 ? 1 : -1) * pr.range(12, 18), pr.range(4, 16), pr.range(0, L.length)], rot: pr.range(-0.5, 0.5) });
  for (let i = 0; i < Math.floor(L.length / 90); i++) L.props.push({ type: 'antenna', pos: [(i % 2 ? -1 : 1) * pr.range(10, 16), L.deathY + 6, pr.range(0, L.length)], h: pr.range(10, 24) });
  return L;
}

// the platform surface nearest a given z along the course; used to place death markers on the real level
export function surfaceAtZ(L, z) {
  let best = null, bd = 1e9;
  for (const s of L.surfaces) { const d = z < s.z0 ? s.z0 - z : z > s.z1 ? z - s.z1 : 0; if (d < bd) { bd = d; best = s; } }
  return best;
}
