// First- and third-person rigs. Yaw 0 faces +z. Third person uses a spring arm that shortens against geometry.
import * as THREE from 'three';
const damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));

export class CameraRig {
  constructor(camera, world) {
    this.camera = camera; this.world = world; this.third = true;
    this.arm = 4.6; this.cur = 4.6; this.fov = 72; this.shake = 0; this.bob = 0; this.look = new THREE.Vector3(); this._t = 0;
  }
  toggle() { this.third = !this.third; }
  kick(amount) { this.shake = Math.max(this.shake, amount); }
  // pos: interpolated eye-level focus point [x,y,z]; speed in m/s
  update(pos, yaw, pitch, dt, speed = 0, grounded = true) {
    const c = this.camera; this._t += dt;
    const targetFov = (this.third ? 70 : 78) + Math.min(16, Math.max(0, speed - 6) * 1.3);
    this.fov = damp(this.fov, targetFov, 4, dt); if (Math.abs(c.fov - this.fov) > 0.01) { c.fov = this.fov; c.updateProjectionMatrix(); }
    const cy = Math.cos(pitch), dir = new THREE.Vector3(Math.sin(yaw) * cy, -Math.sin(pitch), Math.cos(yaw) * cy);
    const eye = new THREE.Vector3(pos[0], pos[1] + 1.55, pos[2]);
    this.shake = Math.max(0, this.shake - dt * 3.2);
    const sh = this.shake * this.shake;
    if (!this.third) {
      if (grounded && speed > 1) this.bob += dt * (6 + speed * 0.9); const bob = grounded ? Math.sin(this.bob) * Math.min(0.045, speed * 0.004) : 0;
      c.position.set(eye.x, eye.y + bob + 0.1, eye.z);
      c.lookAt(c.position.x + dir.x, c.position.y + dir.y + (Math.random() - 0.5) * sh * 0.05, c.position.z + dir.z);
      c.rotation.z += Math.sin(this._t * 40) * sh * 0.01;
      return;
    }
    const pivot = eye.clone().add(new THREE.Vector3(0, 0.25, 0));
    let want = this.arm;
    if (this.world && this.world.raycast) {
      const back = dir.clone().multiplyScalar(-1), h = this.world.raycast([pivot.x, pivot.y, pivot.z], [back.x, back.y, back.z], this.arm + 0.4);
      if (h && h.distance < this.arm + 0.4) want = Math.max(0.9, h.distance - 0.4);
    }
    this.cur = want < this.cur ? want : damp(this.cur, want, 6, dt);
    c.position.copy(pivot).addScaledVector(dir, -this.cur);
    c.position.y = Math.max(c.position.y, pos[1] + 0.35);
    c.position.x += (Math.random() - 0.5) * sh * 0.08; c.position.y += (Math.random() - 0.5) * sh * 0.08;
    this.look.copy(pivot).addScaledVector(dir, 3.0); c.lookAt(this.look);
  }
}
