export class GameAudio{
 constructor(){this.ctx=null;}
 start(){if(this.ctx)return;const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const c=this.ctx=new C();
  this.master=c.createGain();this.master.gain.value=.55*(this.vol??.7);this.master.connect(c.destination);
  this.pad=[0,7,12].map((n,i)=>{const o=c.createOscillator(),g=c.createGain(),f=c.createBiquadFilter();o.type='sawtooth';o.frequency.value=55*Math.pow(2,n/12);f.type='lowpass';f.frequency.value=300;g.gain.value=.05;o.connect(f);f.connect(g);g.connect(this.master);o.start();return{o,g,f};});
  this.pulse=c.createOscillator();this.pg=c.createGain();this.pg.gain.value=0;this.pulse.frequency.value=2;const lfo=c.createOscillator();lfo.frequency.value=1;this.pulse.type='sine';this.pulse.connect(this.pg);this.pg.connect(this.master);this.pulse.frequency.value=110;this.pulse.start();lfo.start();
  const b=c.createBuffer(1,c.sampleRate,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;this.noise=b;}
 setVolume(v){this.vol=v;if(this.master)this.master.gain.value=.55*v;}
 update(speed01,danger01,finish01){if(!this.ctx)return;const t=this.ctx.currentTime,s=Math.min(1,speed01),d=Math.min(1,danger01),f=Math.min(1,finish01);
  this.pad.forEach((p,i)=>{p.f.frequency.setTargetAtTime(250+s*900+f*700,t,.3);p.g.gain.setTargetAtTime(.04+.02*s,t,.3);p.o.detune.setTargetAtTime(d*(i-1)*30,t,.3);});
  this.pg.gain.setTargetAtTime(d*.12,t,.1);}
 tone(freq,dur,type='sine',vol=.2,slide=0){if(!this.ctx)return;const c=this.ctx,o=c.createOscillator(),g=c.createGain(),t=c.currentTime;o.type=type;o.frequency.setValueAtTime(freq,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,freq+slide),t+dur);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(g);g.connect(this.master);o.start(t);o.stop(t+dur);}
 noiseHit(dur,freq,vol=.2){if(!this.ctx)return;const c=this.ctx,s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain(),t=c.currentTime;s.buffer=this.noise;f.frequency.value=freq;g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);s.connect(f);f.connect(g);g.connect(this.master);s.start(t,0,dur);}
 handleEvent(e){const t=e&&e.type;switch(t){case'jump':this.tone(220,.15,'square',.1,200);break;case'land':this.noiseHit(.12,300,Math.min(.4,(e.impact||5)/30));break;case'footstep':this.noiseHit(.05,800,.04);break;case'crumble':this.noiseHit(.5,200,.25);break;case'death':this.tone(200,1,'sawtooth',.3,-170);this.noiseHit(.6,150,.4);break;case'checkpoint':this.tone(660,.3,'triangle',.2,300);break;case'goal':case'finish':[0,4,7,12].forEach((n,i)=>setTimeout(()=>this.tone(440*Math.pow(2,n/12),.5,'triangle',.2),i*120));break;case'grab':this.tone(300,.08,'square',.08);break;case'saw':this.noiseHit(.3,2500,.3);break;default:if(t)this.noiseHit(.08,500,.08);}}
}
