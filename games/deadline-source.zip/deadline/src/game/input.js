// Keyboard + mouse (pointer lock) + gamepad, merged into one physics-ready input per fixed tick.
// Physics convention: yaw 0 faces +z, moveX > 0 is world +x, which is the player's LEFT when facing +z.
// Everything is quantised here so a recorded run replays bit-for-bit.
const dz = (v, d) => (Math.abs(v) < d ? 0 : (v - Math.sign(v) * d) / (1 - d));
const q8 = (v) => Math.round(v * 8) / 8;
const DEFAULT_KEYS = { forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD', jump: 'Space', camera: 'KeyV' };

export class Input {
  constructor(el) {
    this.el = el; this.keys = new Set(); this.yaw = 0; this.pitch = 0.18;
    this.bind = { ...DEFAULT_KEYS }; this.sens = 0.0022; this.deadzone = 0.15; this.invertY = false;
    this.onToggleView = null; this.locked = false;
    this._h = [
      ['keydown', (e) => {
        if (e.repeat) return;
        this.keys.add(e.code);
        if (e.code === this.bind.camera && this.onToggleView) this.onToggleView();
        if (['Space', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault();
      }],
      ['keyup', (e) => this.keys.delete(e.code)],
      ['blur', () => this.keys.clear()],
      ['mousemove', (e) => {
        if (document.pointerLockElement !== el) return;
        this.yaw -= e.movementX * this.sens;
        this.pitch = Math.max(-1.2, Math.min(1.3, this.pitch + e.movementY * this.sens * (this.invertY ? -1 : 1)));
      }],
    ];
    for (const [n, f] of this._h) addEventListener(n, f);
    this._click = () => { if (el.requestPointerLock) { try { el.requestPointerLock(); } catch {} } };
    el.addEventListener('click', this._click);
  }
  configure(settings) {
    if (!settings) return;
    this.bind = { ...DEFAULT_KEYS, ...(settings.keys || {}) };
    this.deadzone = Math.max(0.02, (settings.deadzone ?? 15) / 100);
    this.invertY = !!settings.invertY;
  }
  dispose() { for (const [n, f] of this._h) removeEventListener(n, f); this.el.removeEventListener('click', this._click); if (document.pointerLockElement === this.el) document.exitPointerLock?.(); }
  // one tick of input in physics convention
  poll() {
    const k = this.keys, b = this.bind;
    let sx = (k.has(b.right) || k.has('ArrowRight') ? 1 : 0) - (k.has(b.left) || k.has('ArrowLeft') ? 1 : 0); // + = to the player's right
    let sz = (k.has(b.forward) || k.has('ArrowUp') ? 1 : 0) - (k.has(b.back) || k.has('ArrowDown') ? 1 : 0);
    let jump = k.has(b.jump), slide = k.has('ShiftLeft') || k.has('ShiftRight') || k.has('KeyC'), grab = k.has('KeyE') || k.has('KeyF');
    const gp = (navigator.getGamepads ? [...navigator.getGamepads()].find((g) => g && g.connected) : null);
    if (gp) {
      sx += dz(gp.axes[0] || 0, this.deadzone); sz -= dz(gp.axes[1] || 0, this.deadzone);
      this.yaw -= dz(gp.axes[2] || 0, this.deadzone + 0.05) * 0.048;
      this.pitch = Math.max(-1.2, Math.min(1.3, this.pitch + dz(gp.axes[3] || 0, this.deadzone + 0.05) * 0.032 * (this.invertY ? -1 : 1)));
      jump = jump || !!gp.buttons[0]?.pressed; slide = slide || !!gp.buttons[1]?.pressed || !!gp.buttons[2]?.pressed;
      grab = grab || !!gp.buttons[7]?.pressed || !!gp.buttons[5]?.pressed || !!gp.buttons[4]?.pressed;
      if (gp.buttons[3]?.pressed && !this._cam) { this._cam = true; this.onToggleView?.(); } else if (!gp.buttons[3]?.pressed) this._cam = false;
    }
    const l = Math.hypot(sx, sz); if (l > 1) { sx /= l; sz /= l; }
    return { moveX: q8(-sx), moveZ: q8(sz), jump, jumpHeld: jump, slide, grab, yaw: Math.round(this.yaw * 256) / 256, pitch: this.pitch };
  }
}
