// The runner: the Blender-made, 16-part low-poly model driven by either procedural animation
// (precision / momentum modes) or directly by the ragdoll physics skeleton.
import * as THREE from 'three';

// one gait cycle sampled every 1/12 (degrees -> radians): initial contact at index 0. Shapes follow published running kinematics:
// hip flexed ~40deg at contact, extends to ~-8 at toe-off, swings to ~55; knee ~40 in stance absorption, ~105 peak in swing; ankle dorsiflexes in stance, plantarflexes ~18 at push-off.
const D2R = Math.PI / 180;
const HIP = [40, 32, 20, 8, -4, -8, 5, 25, 42, 52, 55, 48].map((d) => d * D2R), KNEE = [18, 38, 42, 30, 20, 35, 70, 100, 105, 80, 45, 25].map((d) => d * D2R), ANK = [-2, 8, 22, 25, 5, -18, -12, -4, 5, 10, 8, 3].map((d) => d * D2R);
const HIP_M = 22 * D2R, KNEE_M = 50 * D2R;
const cr = (a, t) => { const n = a.length, x = (((t % 1) + 1) % 1) * n, i = Math.floor(x), f = x - i, p0 = a[(i + n - 1) % n], p1 = a[i], p2 = a[(i + 1) % n], p3 = a[(i + 2) % n]; return 0.5 * (2 * p1 + (-p0 + p2) * f + (2 * p0 - 5 * p1 + 4 * p2 - p3) * f * f + (-p0 + 3 * p1 - 3 * p2 + p3) * f * f * f); };
const damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));
const PARENT = {
  torso: 'pelvis', head: 'torso', scarf: 'torso', upper_arm_L: 'torso', upper_arm_R: 'torso',
  lower_arm_L: 'upper_arm_L', lower_arm_R: 'upper_arm_R', hand_L: 'lower_arm_L', hand_R: 'lower_arm_R',
  upper_leg_L: 'pelvis', upper_leg_R: 'pelvis', lower_leg_L: 'upper_leg_L', lower_leg_R: 'upper_leg_R', foot_L: 'lower_leg_L', foot_R: 'lower_leg_R',
};
const NAMES = ['pelvis', ...Object.keys(PARENT)];
const DOWN = new THREE.Vector3(0, -1, 0), UP = new THREE.Vector3(0, 1, 0);

function collect(group) {
  const parts = {}; group.traverse((o) => { if (NAMES.includes(o.name)) parts[o.name] = o; });
  return parts;
}

import * as THREE_ from 'three';
import { applySurface, clothTex } from './surface.js';
// real clothing colours; the glb's own vertex colours are only used as light shading
const WEAR = { jacket: '#66705f', pants: '#505a6c', shoe: '#e4dfd2', skin: '#c28f6c', scarf: '#d8452a', glove: '#1f2023', sole: '#b8b2a2', glass: '#17191c', pack: '#8a5a2e', beanie: '#d8452a' };
const PART_WEAR = { torso: 'jacket', upper_arm_L: 'jacket', upper_arm_R: 'jacket', lower_arm_L: 'jacket', lower_arm_R: 'jacket', hand_L: 'glove', hand_R: 'glove', head: 'skin', scarf: 'scarf', pelvis: 'pants', upper_leg_L: 'pants', upper_leg_R: 'pants', lower_leg_L: 'pants', lower_leg_R: 'pants', foot_L: 'shoe', foot_R: 'shoe' };
function dress(o) {
  const w = PART_WEAR[o.name] || (o.name.startsWith('sole_') ? 'sole' : o.name.startsWith('pack_') ? 'pack' : o.name.startsWith('trim_') ? (o.name.includes('beanie') ? 'beanie' : o.name.includes('glasses') ? 'glass' : o.name.includes('wrap') ? 'scarf' : 'jacket') : null); if (!w) return;
  const c = new THREE_.Color(WEAR[w]).multiplyScalar(1.15);
  o.material = new THREE_.MeshStandardMaterial({ color: c, vertexColors: true, roughness: w === 'skin' ? 0.62 : 0.86, metalness: 0, emissive: c.clone().multiplyScalar(w === 'glass' ? 0 : 0.2) });
  if (w !== 'skin') applySurface(o.material, clothTex(), 3.5, 0.8);
}
export function makeRunner(gltfScene, { ghost = false, ragdoll = false, tint = null, veh = null } = {}) {
  const model = gltfScene.clone(true);
  const parts = collect(model);
  const rest = {}; for (const n of NAMES) rest[n] = parts[n].position.clone();
  model.traverse((o) => {
    if (!o.isMesh) return;
    o.castShadow = !ghost; o.receiveShadow = false;
    o.material = o.material.clone(); dress(o);
    if (ghost) { o.material.transparent = true; o.material.opacity = 0.34; o.material.depthWrite = false; if (tint) o.material.color.set(tint); }
  });
  const root = new THREE.Group();

  if (ragdoll) { // flat: every part is a direct child, placed in world space from skeleton points
    for (const n of NAMES) { parts[n].removeFromParent(); root.add(parts[n]); }
    const v = (p) => new THREE.Vector3(p[0], p[1], p[2]);
    const aim = (part, from, to, axis) => {
      part.position.copy(from);
      const d = to.clone().sub(from); if (d.lengthSq() < 1e-8) return;
      part.quaternion.setFromUnitVectors(axis, d.normalize());
    };
    return {
      root, parts, ragdoll: true,
      poseRagdoll(P) { // P: array of 12 skeleton points [head, neck, chest, pelvis, lElbow, rElbow, lHand, rHand, lKnee, rKnee, lFoot, rFoot]
        const [hd, nk, ch, pv, le, re, lh, rh, lk, rk, lf, rf] = P.map(v);
        const up = ch.clone().sub(pv);
        aim(parts.pelvis, pv, ch, UP);
        aim(parts.torso, pv.clone().addScaledVector(up, 0.3), nk, UP);
        aim(parts.head, nk, hd, UP);
        aim(parts.scarf, nk, nk.clone().add(up.clone().normalize()), UP);
        const sl = nk.clone().add(new THREE.Vector3(-0.3, -0.08, 0)), sr = nk.clone().add(new THREE.Vector3(0.3, -0.08, 0));
        aim(parts.upper_arm_L, sl, le, DOWN); aim(parts.lower_arm_L, le, lh, DOWN); aim(parts.hand_L, lh, lh.clone().add(lh.clone().sub(le)), DOWN);
        aim(parts.upper_arm_R, sr, re, DOWN); aim(parts.lower_arm_R, re, rh, DOWN); aim(parts.hand_R, rh, rh.clone().add(rh.clone().sub(re)), DOWN);
        const hl = pv.clone().add(new THREE.Vector3(-0.11, -0.05, 0)), hr = pv.clone().add(new THREE.Vector3(0.11, -0.05, 0));
        aim(parts.upper_leg_L, hl, lk, DOWN); aim(parts.lower_leg_L, lk, lf, DOWN); aim(parts.foot_L, lf, lf.clone().add(lf.clone().sub(lk)), DOWN);
        aim(parts.upper_leg_R, hr, rk, DOWN); aim(parts.lower_leg_R, rk, rf, DOWN); aim(parts.foot_R, rf, rf.clone().add(rf.clone().sub(rk)), DOWN);
      },
    };
  }

  // hierarchical: children positioned relative to their parent joint
  for (const [child, par] of Object.entries(PARENT)) parts[child].position.copy(rest[child]).sub(rest[par]);
  for (const [child, par] of Object.entries(PARENT)) parts[par].add(parts[child]);
  const body = new THREE.Group(); root.add(body); body.add(parts.pelvis);
  // ---- wheeled modes: vehicle meshes + riding poses -----------------------------------------------------
  const kind = veh && veh.kind, VM = veh && veh.models;
  let wheels = [], fork = null, crank = null, wheelF = null, wheelR = null, wheelR_r = 0.0275, lift = 0;
  const grab = (name) => { const src = VM['veh_' + name]; return src.clone(true); };
  if (kind === 'board') {
    const g = grab('board'); root.add(g); lift = 0.092; wheels = [0, 1, 2, 3].map((i) => g.getObjectByName('wheel_' + i)); wheelR_r = 0.0275;
    g.traverse((o) => { if (o.isMesh) o.castShadow = !ghost; });
  } else if (kind === 'bike') {
    const g = grab('bike'); root.add(g); fork = g.getObjectByName('fork'); crank = g.getObjectByName('crank'); wheelF = g.getObjectByName('wheel_F'); wheelR = g.getObjectByName('wheel_R'); wheelR_r = 0.342;
    g.traverse((o) => { if (o.isMesh) o.castShadow = !ghost; });
  }
  if (ghost && kind) root.traverse((o) => { if (o.isMesh && !o.userData.ghosted) { o.userData.ghosted = true; o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = 0.34; o.material.depthWrite = false; } });
  const sin = Math.sin, cos = Math.cos, clampv = (v, a, b) => Math.max(a, Math.min(b, v));
  // two-link planar IK in (z forward, y up): returns [upper.x, lower.x] for a leg whose knee points forward (or an arm whose elbow points back)
  const ik2 = (tz, ty, L1, L2, kneeForward = true) => {
    let d = Math.hypot(tz, ty); d = clampv(d, 0.12, L1 + L2 - 0.004);
    const alpha = Math.atan2(tz, -ty), beta = Math.acos(clampv((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1)), gam = Math.acos(clampv((L1 * L1 + L2 * L2 - d * d) / (2 * L1 * L2), -1, 1));
    return kneeForward ? [-(alpha + beta), Math.PI - gam] : [-(alpha - beta), -(Math.PI - gam)];
  };
  let crankPh = 0, rideT = 0, steer = 0, roll2 = 0;
  const targets = {}, cur = {};
  for (const n of NAMES) { targets[n] = { x: 0, z: 0 }; cur[n] = { x: 0, z: 0 }; }
  let heading = 0, phase = 0, bounce = 0, scarfT = 0, pelvDrop = 0, gp = 0;

  return {
    root, parts,
    // state: idle|run|jump|fall|slide|wallrun|rope|vault|dead ; speed horizontal m/s ; vel: [vx,vy,vz]
    update(state, speed, vel, dt, landed = 0) {
      const T = targets;
      for (const n of NAMES) { T[n].x = 0; T[n].z = 0; }
      const runK = Math.min(1, speed / 9), s = Math.sin(phase), c = Math.cos(phase);
      phase += dt * (speed > 0.4 ? 5.5 + speed * 1.15 : 0);
      let lean = 0.07 + runK * 0.22, roll = 0;
      let sway = 0, twist = 0, bob = 0, headY = 0;
      if (state === 'run' || state === 'idle') {
        // joint angles come from sampled running-gait curves (hip / knee / ankle over one gait cycle, 0 = initial contact),
        // each leg half a cycle apart; pelvis height is solved so the lower foot stays on the ground
        const k = speed > 0.4 ? 1 : 0, ampK = Math.max(0.4, Math.min(1, speed / 6));
        gp = (gp + dt * k * Math.min(2.6, 0.95 + 0.115 * speed)) % 1;
        const joint = (tab, ph, mean, gain) => mean + (cr(tab, ph) - mean) * gain;
        const gh = 0.7 + 0.4 * ampK + 0.1 * runK, gk = 0.65 + 0.3 * ampK + 0.15 * runK;
        const hL = k ? joint(HIP, gp, HIP_M, gh) : 0.0, hR = k ? joint(HIP, gp + 0.5, HIP_M, gh) : 0.0;
        const kL = k ? joint(KNEE, gp, KNEE_M, gk) : 0.06, kR = k ? joint(KNEE, gp + 0.5, KNEE_M, gk) : 0.06;
        const aL = k ? cr(ANK, gp) : 0, aR = k ? cr(ANK, gp + 0.5) : 0;
        T.upper_leg_L.x = -hL; T.upper_leg_R.x = -hR; T.lower_leg_L.x = kL; T.lower_leg_R.x = kR; T.foot_L.x = -aL; T.foot_R.x = -aR;
        const depth = (h, kn) => 0.4 * Math.cos(h) + 0.4 * Math.cos(h - kn);
        if (k) bob = 0.9 - (Math.max(depth(hL, kL), depth(hR, kR)) + 0.1) - 0.018 * runK * Math.max(0, Math.sin(Math.PI * 2 * gp * 2 + 0.6));
        // arms swing opposite to the same-side leg, elbows near 90 degrees, closing as the hand comes forward
        const A = 0.3 + 0.32 * ampK, swingL = -Math.cos(Math.PI * 2 * (gp - 0.05)), swingR = -Math.cos(Math.PI * 2 * (gp + 0.45));
        T.upper_arm_L.x = -(0.08 + A * swingL) * k; T.upper_arm_R.x = -(0.08 + A * swingR) * k;
        T.lower_arm_L.x = -(1.45 + 0.24 * swingL * k); T.lower_arm_R.x = -(1.45 + 0.24 * swingR * k);
        T.upper_arm_L.z = -0.1; T.upper_arm_R.z = 0.1;
        twist = -(hL - hR) * 0.16 * k; sway = Math.sin(Math.PI * 2 * gp) * 0.035 * ampK * k; headY = -twist * 0.5;
        lean = 0.07 + runK * 0.16;
        if (state === 'idle') { lean = 0.02; T.lower_arm_L.x = -0.2; T.lower_arm_R.x = -0.2; T.upper_arm_L.z = -0.1; T.upper_arm_R.z = 0.1; bob = Math.sin(performance.now() * 0.0016) * 0.008 - 0.01; }
      } else if (state === 'jump') {
        const up = vel[1] > 0 ? 1 : 0.4; T.upper_leg_L.x = -1.05 * up - 0.1; T.lower_leg_L.x = 1.35; T.upper_leg_R.x = 0.45; T.lower_leg_R.x = 0.9; T.foot_L.x = -0.3; T.foot_R.x = 0.5;
        T.upper_arm_L.x = -2.3 * up - 0.3; T.upper_arm_R.x = -1.2; T.lower_arm_L.x = -0.4; T.lower_arm_R.x = -0.9; T.upper_arm_L.z = -0.25; T.upper_arm_R.z = 0.3; lean = 0.2 + (vel[1] < 0 ? 0.1 : 0);
      } else if (state === 'fall') {
        const reach = Math.min(1, Math.max(0, -vel[1] / 9)); T.upper_leg_L.x = -0.35 - reach * 0.45; T.upper_leg_R.x = 0.2 - reach * 0.25; T.lower_leg_L.x = 0.7 - reach * 0.45; T.lower_leg_R.x = 0.5 - reach * 0.3; T.foot_L.x = 0.3; T.foot_R.x = 0.3;
        T.upper_arm_L.z = -1.2 - reach * 0.35; T.upper_arm_R.z = 1.2 + reach * 0.35; T.upper_arm_L.x = -0.5; T.upper_arm_R.x = -0.4; T.lower_arm_L.x = -0.5; T.lower_arm_R.x = -0.5; lean = 0.12;
      } else if (state === 'slide') {
        T.upper_leg_L.x = -1.35; T.upper_leg_R.x = -1.25; T.lower_leg_L.x = 0.15; T.lower_leg_R.x = 0.15;
        T.upper_arm_L.x = -0.7; T.upper_arm_R.x = -0.7; T.upper_arm_L.z = -0.5; T.upper_arm_R.z = 0.5; lean = -1.05;
      } else if (state === 'wallrun') {
        const a = 0.7; T.upper_leg_L.x = -s * a; T.upper_leg_R.x = s * a; T.lower_leg_L.x = 0.6; T.lower_leg_R.x = 0.6;
        T.upper_arm_L.x = s * a; T.upper_arm_R.x = -s * a; roll = 0.45; lean = 0.2;
      } else if (state === 'rope') {
        T.upper_arm_L.x = -3.0; T.upper_arm_R.x = -3.0; T.lower_arm_L.x = -0.1; T.lower_arm_R.x = -0.1;
        T.upper_leg_L.x = 0.25 + s * 0.15; T.upper_leg_R.x = 0.1 - s * 0.15; T.lower_leg_L.x = 0.4; T.lower_leg_R.x = 0.4; lean = 0.0;
      } else if (state === 'vault') {
        T.upper_leg_L.x = -1.2; T.lower_leg_L.x = 1.5; T.upper_leg_R.x = 0.2; T.upper_arm_L.x = -1.0; T.upper_arm_R.x = -1.0; lean = 0.5;
      } else if (state === 'dead') {
        T.upper_arm_L.z = -1.0; T.upper_arm_R.z = 1.0; T.upper_leg_L.x = -0.5; T.upper_leg_R.x = 0.4; lean = 0.3;
      }
      if (kind) {
        const air = state === 'jump' || state === 'fall', braking = state === 'slide', moving = speed > 0.6;
        pelvDrop = 0; body.rotation.y = 0; body.position.set(0, lift, 0); T.scarf.x = 0;
        rideT += dt * (2.0 + speed * 0.16);
        if (kind === 'board') {
          // sideways stance, left foot forward; crouched knees, arms out; a back-foot push while slow
          body.rotation.y = Math.PI / 2; pelvDrop = air ? 0.1 : 0.15; lean = 0.12; twist = -0.42; headY = -0.7;
          const pushK = !air && speed < 8.5 ? Math.max(0, Math.sin(rideT * 1.6)) : 0;
          T.upper_leg_L.x = -0.62; T.lower_leg_L.x = 1.1; T.foot_L.x = -0.36; T.upper_leg_L.z = -0.3; T.lower_leg_L.z = 0.2;
          T.upper_leg_R.x = -0.5 + pushK * 0.1; T.lower_leg_R.x = 1.0 - pushK * 0.5; T.foot_R.x = -0.4; T.upper_leg_R.z = 0.3 + pushK * 0.5; T.lower_leg_R.z = -0.2 - pushK * 0.1;
          if (braking) { T.upper_leg_R.z = 0.75; T.lower_leg_R.x = 0.5; }
          if (air) { T.upper_leg_L.x = -0.9; T.lower_leg_L.x = 1.3; T.upper_leg_R.x = -0.8; T.lower_leg_R.x = 1.3; pelvDrop = 0.08; }
          T.upper_arm_L.z = -0.75 - 0.05 * Math.sin(rideT); T.upper_arm_R.z = 0.75 + 0.05 * Math.sin(rideT); T.upper_arm_L.x = -0.35; T.upper_arm_R.x = -0.2; T.lower_arm_L.x = -0.5; T.lower_arm_R.x = -0.5;
        } else if (kind === 'bike') {
          // seated on the saddle, torso forward to the bars, feet on a turning crank (leg IK to the pedals)
          crankPh += dt * (moving ? 2.2 + speed * 0.45 : 0);
          const seatZ = -0.2, hipY = 0.9 + lift + 0.12, standing = air ? 0.1 : 0;
          body.position.set(0, lift + 0.12 + standing, seatZ); pelvDrop = 0; lean = air ? 0.7 : 0.88; twist = 0; headY = 0;
          const bbz = -0.06 - seatZ, bby = 0.31 - (0.12 + lift + standing);
          for (const S of ['L', 'R']) {
            const ph = crankPh + (S === 'L' ? 0 : Math.PI), pz = bbz + (S === 'L' ? -0.17 * Math.sin(ph) : 0.17 * Math.sin(ph)), py = bby + (S === 'L' ? -0.17 * Math.cos(ph) : 0.17 * Math.cos(ph));
            const [u, l] = ik2(pz - 0.03, py + 0.09 - 0.9, 0.4, 0.4, true);
            T['upper_leg_' + S].x = u; T['lower_leg_' + S].x = l; T['foot_' + S].x = -(u + l) * 0.85 + 0.1;
          }
          // arms to the bars: shoulder position from the torso lean, grips ~0.47 m ahead and 0.12 m below the hips' height
          const th = lean, shz = 0.37 * Math.sin(th), shy = 1.05 + 0.37 * Math.cos(th);
          const gz = 0.47 - seatZ, gy = 0.93 - (0.12 + lift + standing);
          const [ua, la] = ik2(gz - shz, gy - shy, 0.3, 0.3, false);
          T.upper_arm_L.x = ua; T.upper_arm_R.x = ua; T.lower_arm_L.x = la; T.lower_arm_R.x = la; T.upper_arm_L.z = -0.1; T.upper_arm_R.z = 0.1;
        }
        // lean into the turn, steer the front wheel, spin the wheels
        const hd = Math.atan2(vel[0], vel[2]); let dd = hd - heading; while (dd > Math.PI) dd -= 2 * Math.PI; while (dd < -Math.PI) dd += 2 * Math.PI;
        const tgt = speed > 1.5 ? clampv(dd * 0.9, -0.5, 0.5) : 0; roll2 = damp(roll2, tgt, 6, dt); root.rotation.z = -roll2 * (kind === 'bike' ? 0.8 : 0.55);
        steer = damp(steer, clampv(dd * 1.2, -0.5, 0.5), 10, dt); if (fork) fork.rotation.y = steer;
        const spin = (speed / wheelR_r) * dt; for (const w of wheels) w.rotation.x += spin; if (wheelF) wheelF.rotation.x += spin; if (wheelR) wheelR.rotation.x += spin; if (crank) crank.rotation.x = crankPh;
      }
      for (const n of NAMES) {
        cur[n].x = damp(cur[n].x, T[n].x, 26, dt); cur[n].z = damp(cur[n].z, T[n].z, 16, dt);
        if (n !== 'pelvis') { parts[n].rotation.x = cur[n].x; parts[n].rotation.z = cur[n].z; }
      }
      bounce = damp(bounce, 0, 9, dt); if (landed > 0) bounce = Math.min(0.34, landed * 0.026);
      if (bounce > 0.02 && state !== 'slide') { for (const L of ['L', 'R']) { cur['upper_leg_' + L].x -= bounce * 1.6; cur['lower_leg_' + L].x += bounce * 3.2; } lean += bounce * 1.4; }
      for (const n of NAMES) if (n !== 'pelvis') parts[n].rotation.x = cur[n].x;
      parts.torso.rotation.x = damp(parts.torso.rotation.x, lean, 10, dt);
      parts.torso.rotation.y = damp(parts.torso.rotation.y, twist, 14, dt);
      parts.head.rotation.x = -parts.torso.rotation.x * 0.6; parts.head.rotation.y = damp(parts.head.rotation.y, headY - twist * 0.6, 12, dt);
      parts.pelvis.position.y = rest.pelvis.y - bounce * 0.9 - bob - pelvDrop - (state === 'slide' && !kind ? 0.45 : 0);
      parts.pelvis.rotation.y = damp(parts.pelvis.rotation.y, -twist * 0.7, 14, dt);
      parts.pelvis.rotation.z = damp(parts.pelvis.rotation.z, roll + sway, 10, dt);
      scarfT += dt * (3 + speed * 0.6);
      parts.scarf.rotation.x = Math.min(1.35, 0.1 + speed * 0.11) + Math.sin(scarfT) * 0.1 * runK; parts.scarf.rotation.z = Math.sin(scarfT * 0.7 + 1) * 0.14 * runK;
      if (speed > 0.8) { const h = Math.atan2(vel[0], vel[2]); let d = h - heading; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; heading += d * (1 - Math.exp(-14 * dt)); }
      root.rotation.y = heading;
    },
    setHeading(h) { heading = h; root.rotation.y = h; },
  };
}
