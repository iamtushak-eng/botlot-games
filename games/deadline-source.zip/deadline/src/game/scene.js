// Builds the three.js scene for a level and keeps its dynamic parts (moving platforms, saws, ropes,
// bridges, crumbling slabs) in sync with the physics world. Geometry is deliberately a little uneven:
// seeded vertex jitter and banded vertex colours, no textures, so nothing looks machine-perfect.
import * as THREE from 'three';
import { texturiseWorld } from './surface.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const KIT = ['antenna', 'billboard_frame', 'building_block', 'checkpoint_flag', 'crate', 'crumbling_slab', 'goal_gate', 'ledge', 'pipe', 'plank', 'rope_hook', 'saw_blade', 'spike_strip', 'vent'];
export async function loadModels(base = 'assets/models/') {
  const loader = new GLTFLoader(), out = {};
  await Promise.all([...KIT.map((k) => 'kit_' + k), 'runner', 'veh_board', 'veh_bike'].map(async (n) => {
    const emb = typeof window !== 'undefined' && window.__DEADLINE_MODELS;   // single-file build: models are embedded
    let g;
    if (emb && emb[n]) { const bin = atob(emb[n]), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); g = await loader.parseAsync(u.buffer, ''); }
    else g = await loader.loadAsync(base + n + '.glb');
    out[n.replace(/^kit_/, '')] = g.scene;
  }));
  return out;
}

// top / side / accent per theme, chosen to sit inside each mood's fog colour
const PALETTE = {
  rooftops: { top: '#8c8577', side: '#5a554d', acc: '#c8321f' }, factory: { top: '#7c7a74', side: '#47443f', acc: '#d89a2b' },
  void: { top: '#8e9bb0', side: '#4a5468', acc: '#e0e6ff' }, subway: { top: '#7f8f78', side: '#45523f', acc: '#c9d46a' },
  canyon: { top: '#b98a62', side: '#7a4a32', acc: '#f0c27a' }, ice: { top: '#bcd6e2', side: '#6f8fa6', acc: '#ffffff' },
  site: { top: '#9a9588', side: '#63594a', acc: '#e8a820' }, clocktower: { top: '#a6865a', side: '#5e4630', acc: '#e8d28a' },
  neon: { top: '#6a5a82', side: '#2f2646', acc: '#ff2a9a' }, docks: { top: '#8aa0a6', side: '#4c6068', acc: '#f08a3c' },
};

const hash3 = (x, y, z, s) => { let h = Math.imul(Math.round(x * 64) + 7919, 374761393) ^ Math.imul(Math.round(y * 64) + 104729, 668265263) ^ Math.imul(Math.round(z * 64) + 1299709, 2147483647) ^ s; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };

// slightly uneven box with banded vertex colours; jitter depends only on vertex position, so shared corners never crack
function roughBox(w, h, d, { top, side, seed = 1, jitter = 0.035, bands = 0, bandAmp = 0.1, darkenBottom = 0.45 }) {
  const sx = Math.max(1, Math.round(w / 3)), sy = bands || Math.max(1, Math.round(h / 3)), sz = Math.max(1, Math.round(d / 3));
  let g = new THREE.BoxGeometry(w, h, d, sx, sy, sz).toNonIndexed();
  const p = g.attributes.position, col = new Float32Array(p.count * 3), c = new THREE.Color(), t = new THREE.Color(top), s = new THREE.Color(side);
  const nrm = (g.computeVertexNormals(), g.attributes.normal);
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const edge = (Math.abs(x) > w / 2 - 1e-3) + (Math.abs(y) > h / 2 - 1e-3) + (Math.abs(z) > d / 2 - 1e-3);
    const j = jitter * (edge >= 2 ? 1.6 : 1);
    p.setXYZ(i, x + (hash3(x, y, z, seed) - 0.5) * 2 * j * (Math.abs(x) > w / 2 - 1e-3 ? 0.6 : 1), y + (hash3(x, y, z, seed + 1) - 0.5) * 2 * j * 0.7, z + (hash3(x, y, z, seed + 2) - 0.5) * 2 * j);
    const isTop = nrm.getY(i) > 0.5;
    if (isTop) c.copy(t); else c.copy(s);
    const band = Math.floor(((y + h / 2) / h) * sy), bv = 1 + (hash3(band, Math.round(x / 3), Math.round(z / 3), seed + 9) - 0.5) * 2 * bandAmp;
    c.multiplyScalar(bv);
    if (!isTop) c.multiplyScalar(1 - darkenBottom * (1 - (y + h / 2) / h)); // darker toward the base, cheap ambient occlusion
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.computeVertexNormals();
  return g;
}

const vcMat = (extra = {}) => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0.02, flatShading: true, ...extra });

export function buildScene(level, models) {
  const scene = new THREE.Scene(), pal = PALETTE[level.themeId] || PALETTE.rooftops;
  const root = new THREE.Group(); scene.add(root);
  const matBase = vcMat();
  const dyn = { boxes: [], hazards: [], ropes: [], bridges: [], crumbs: new Map() };
  const instance = (name, mat) => { const m = models[name].clone(true); m.traverse((o) => { if (o.isMesh) { o.material = (mat || o.material).clone(); o.castShadow = true; o.receiveShadow = true; } }); return m; };
  let seed = 11;

  // ---- solid boxes (index-aligned with physics world.boxes) ----
  level.boxes.forEach((b, i) => {
    const w = b.max[0] - b.min[0], h = b.max[1] - b.min[1], d = b.max[2] - b.min[2];
    const cx = (b.min[0] + b.max[0]) / 2, cy = (b.min[1] + b.max[1]) / 2, cz = (b.min[2] + b.max[2]) / 2;
    if (b.role === 'spikes') {
      const grp = new THREE.Group(); const n = Math.max(1, Math.round(w / 3));
      for (let k = 0; k < n; k++) { const sp = instance('spike_strip'); sp.scale.set(w / n / 3.02, 0.62, d / 0.6); sp.position.set(b.min[0] + (k + 0.5) * (w / n), b.min[1], cz); grp.add(sp); }
      root.add(grp); dyn.boxes.push({ mesh: grp, box: i, base: grp.position.clone(), axis: -1 }); return;
    }
    let top = pal.top, side = pal.side;
    if (b.surface === 'ice') { top = '#bfe3f2'; side = '#7aa6c2'; }
    if (b.surface === 'crumble') { top = '#b0875e'; side = '#6e4c34'; }
    if (b.role === 'mover') { top = '#caa13a'; side = '#5c4a22'; }
    if (b.role === 'wall') { top = pal.side; side = pal.side; }
    if (b.role === 'goal') { top = '#d9d2bf'; side = '#7c7566'; }
    if (b.role === 'start') { top = '#cfc7b4'; side = '#6b6558'; }
    { const v = 0.84 + 0.3 * hash3(i, 3, 7, 11), tint = (hash3(i, 5, 1, 4) - 0.5) * 0.06; const adj = (c) => { const k = new THREE.Color(c); k.multiplyScalar(v); k.r += tint; k.b -= tint; return '#' + k.getHexString(); }; top = adj(top); side = adj(side); }
    const g = roughBox(w, h, d, { top, side, seed: ++seed * 13, jitter: b.role === 'wall' ? 0.05 : 0.035, bands: Math.max(1, Math.round(h / 1.2)) });
    const m = new THREE.Mesh(g, matBase); m.castShadow = true; m.receiveShadow = true;
    const holder = new THREE.Group(); holder.position.set(cx, cy, cz); holder.add(m); root.add(holder);
    if (b.surface === 'crumble') { // dark hairline cracks, stay with the slab
      const crackMat = new THREE.MeshBasicMaterial({ color: '#3b2a1c' });
      for (let k = 0; k < 3; k++) { const cr = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.02, d * (0.35 + 0.1 * k)), crackMat); cr.position.set(-w / 2 + (k + 1) * w / 4 + (hash3(k, i, 1, 5) - 0.5) * 0.4, h / 2 + 0.012, (hash3(k, i, 2, 5) - 0.5) * d * 0.3); cr.rotation.y = (hash3(k, i, 3, 5) - 0.5) * 0.6; holder.add(cr); }
    }
    if (b.role === 'start' || b.role === 'goal') { // painted stripe
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.02, 0.35), new THREE.MeshBasicMaterial({ color: b.role === 'goal' ? '#c8321f' : '#1b1a17' }));
      stripe.position.set(0, h / 2 + 0.012, b.role === 'goal' ? -d / 2 + 1.2 : d / 2 - 1.4); holder.add(stripe);
    }
    if (b.move || b.surface === 'crumble') dyn.boxes.push({ mesh: holder, box: i, base: holder.position.clone(), axis: b.move ? b.move.axis : -1, crumble: b.surface === 'crumble' });
    if (b.surface === 'crumble') dyn.crumbs.set(i, holder);
  });

  // ---- ramps: wedge with a visible underside ----
  for (const r of level.ramps) {
    const x0 = r.min[0], x1 = r.max[0], z0 = r.min[2], z1 = r.max[2], [h00, h10, h01, h11] = r.heights, base = r.min[1] - 1.6;
    const pos = [], col = [], push = (v, c) => { pos.push(...v); col.push(c.r, c.g, c.b); };
    const top = new THREE.Color(pal.top), sd = new THREE.Color(pal.side);
    const A = [x0, h00, z0], B = [x1, h10, z0], C = [x0, h01, z1], D = [x1, h11, z1];
    const tri = (a, b, c, cl) => { push(a, cl); push(b, cl); push(c, cl); };
    tri(A, C, B, top); tri(B, C, D, top);                                                   // top
    tri([x0, base, z0], A, [x0, base, z1], sd); tri(A, C, [x0, base, z1], sd);               // left wall
    tri([x1, base, z0], [x1, base, z1], B, sd); tri(B, [x1, base, z1], D, sd);               // right wall
    tri([x0, base, z0], [x1, base, z0], A, sd); tri(A, [x1, base, z0], B, sd);               // front
    tri([x0, base, z1], C, [x1, base, z1], sd); tri(C, D, [x1, base, z1], sd);               // back
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, flatShading: true, side: THREE.DoubleSide })); m.castShadow = true; m.receiveShadow = true; root.add(m);
  }

  // ---- saws ----
  level.hazards.forEach((h, i) => {
    const grp = new THREE.Group(), saw = instance('saw_blade'); saw.scale.setScalar(h.radius / 0.7); grp.add(saw);
    const rail = new THREE.Mesh(new THREE.BoxGeometry(h.move && h.move.axis === 0 ? h.move.amp * 2 + 0.6 : 0.16, 0.12, h.move && h.move.axis === 2 ? h.move.amp * 2 + 0.6 : 0.16), new THREE.MeshStandardMaterial({ color: '#2a2824', roughness: 0.8, flatShading: true }));
    rail.position.set(h.pos[0], h.pos[1] - h.radius - 0.12, h.pos[2]); root.add(rail);
    root.add(grp); dyn.hazards.push({ grp, saw, h, i, spin: 0 });
  });

  // ---- ropes (gantry beam, hook, strand) ----
  const ropeMat = new THREE.MeshStandardMaterial({ color: '#b59a6a', roughness: 1, flatShading: true });
  level.ropes.forEach((r, i) => {
    const beam = new THREE.Mesh(roughBox(7, 0.5, 0.5, { top: pal.side, side: pal.side, seed: 50 + i, jitter: 0.02, bands: 1 }), matBase); beam.position.set(r.anchor[0], r.anchor[1] + 0.55, r.anchor[2]); beam.castShadow = true; root.add(beam);
    for (const sx of [-3.2, 3.2]) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.3, 14, 0.3), new THREE.MeshStandardMaterial({ color: pal.side, flatShading: true })); post.position.set(r.anchor[0] + sx, r.anchor[1] - 6.4, r.anchor[2]); root.add(post); }
    const hook = instance('rope_hook'); hook.position.set(r.anchor[0], r.anchor[1] - 0.1, r.anchor[2]); hook.scale.setScalar(0.9); root.add(hook);
    const segs = []; for (let k = 0; k < r.segments; k++) { const s = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1, 6), ropeMat); s.castShadow = true; root.add(s); segs.push(s); }
    dyn.ropes.push({ segs, idx: i });
  });

  // ---- bridges: planks + rail ropes following the verlet nodes ----
  level.bridges.forEach((b, i) => {
    const planks = [], rails = [[], []];
    for (let k = 0; k <= b.planks; k++) { const p = instance('plank'); p.scale.set(b.width / 3.0, 1, 1.35); root.add(p); planks.push(p); }
    for (let side = 0; side < 2; side++) for (let k = 0; k < b.planks; k++) { const s = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1, 5), ropeMat); root.add(s); rails[side].push(s); }
    for (const [pt, sx] of [[b.a, -1], [b.a, 1], [b.b, -1], [b.b, 1]]) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.5, 0.16), new THREE.MeshStandardMaterial({ color: '#3a3126', flatShading: true })); post.position.set(pt[0] + sx * b.width / 2, pt[1] + 0.7, pt[2]); root.add(post); }
    dyn.bridges.push({ planks, rails, idx: i, width: b.width });
  });

  // ---- checkpoints & goal ----
  level.checkpoints.forEach((c) => { const f = instance('checkpoint_flag'); f.position.set(c.pos[0] + 2.8, c.pos[1], c.pos[2]); root.add(f); });
  const gate = instance('goal_gate'); gate.scale.setScalar(1.6); gate.position.set(level.goal.pos[0], level.goal.pos[1], level.goal.z); root.add(gate);

  // ---- dressing (no collision): pillars, pipes, skyline, billboards, antennae ----
  const dark = new THREE.Color(pal.side).multiplyScalar(0.7).getStyle();
  for (const p of level.props) {
    if (p.type === 'pillar') { const g = roughBox(p.w, p.h, p.d, { top: dark, side: dark, seed: ++seed, jitter: 0.06, bands: Math.max(2, Math.round(p.h / 3)), bandAmp: 0.16 }); const m = new THREE.Mesh(g, matBase); m.position.set(p.pos[0], p.pos[1] - p.h / 2, p.pos[2]); m.castShadow = true; root.add(m); }
    else if (p.type === 'pipe') { const m = instance('pipe'); m.scale.set(Math.max(1, p.len / 4.04), 1.2, 1.2); m.rotation.y = Math.PI / 2; m.position.set(p.pos[0] + p.side * (p.w / 2 + 0.2), p.pos[1], p.pos[2]); root.add(m); }
    else if (p.type === 'tower') { const g = roughBox(p.w, p.h, p.d, { top: dark, side: pal.side, seed: ++seed, jitter: 0.12, bands: Math.max(3, Math.round(p.h / 2.5)), bandAmp: 0.2, darkenBottom: 0.2 }); const m = new THREE.Mesh(g, matBase); m.position.set(p.pos[0], p.pos[1] + p.h / 2, p.pos[2]); root.add(m); }
    else if (p.type === 'billboard') { const f = instance('billboard_frame'); f.position.set(p.pos[0], p.pos[1], p.pos[2]); f.rotation.y = (p.pos[0] > 0 ? -1 : 1) * Math.PI / 2 + p.rot; f.scale.setScalar(1.3); root.add(f); const panel = new THREE.Mesh(new THREE.PlaneGeometry(6, 3.2), new THREE.MeshBasicMaterial({ color: pal.acc })); panel.position.set(0, 2.4, 0.3); panel.scale.setScalar(0.85); f.add(panel); }
    else if (p.type === 'antenna') { const a = instance('antenna'); a.scale.setScalar(p.h / 3.8); a.position.set(p.pos[0], p.pos[1], p.pos[2]); root.add(a); }
  }
  // the void: a murky floor far below hides the edge of the world
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(600, 900), new THREE.MeshBasicMaterial({ color: '#000000' })); floor.rotation.x = -Math.PI / 2; floor.position.set(0, level.deathY + 10, level.length / 2); floor.userData.voidFloor = true; root.add(floor);

  // ---- per-frame sync with physics ----
  const v = new THREE.Vector3(), y = new THREE.Vector3(0, 1, 0), q = new THREE.Quaternion();
  const link = (mesh, a, b, thick = 1) => { v.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]); const len = v.length() || 1e-6; mesh.position.set((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2); mesh.quaternion.setFromUnitVectors(y, v.normalize()); mesh.scale.set(thick, len, thick); };
  texturiseWorld(scene);
  return {
    scene, root, dyn, palette: pal,
    sync(world, dt, alpha) {
      for (const d of dyn.boxes) {
        const wb = world.boxes[d.box];
        if (wb.dead) { if (d.mesh.visible) { d.fall = (d.fall || 0) + dt; d.mesh.position.y = d.base.y - d.fall * d.fall * 14; d.mesh.rotation.x += dt * 0.6; d.mesh.rotation.z += dt * 0.4; if (d.fall > 2.2) d.mesh.visible = false; } continue; }
        if (d.axis >= 0) { const o = wb.off; d.mesh.position.set(d.base.x + (d.axis === 0 ? o : 0), d.base.y + (d.axis === 1 ? o : 0), d.base.z + (d.axis === 2 ? o : 0)); }
        else if (d.crumble && wb.touched >= 0) { const t = (world.time - wb.touched) / 0.6; d.mesh.position.set(d.base.x + Math.sin(world.time * 90) * 0.03 * t, d.base.y, d.base.z + Math.cos(world.time * 83) * 0.03 * t); }
      }
      for (const d of dyn.hazards) { const h = world.hazards[d.i]; d.grp.position.set(h.pos[0], h.pos[1], h.pos[2]); d.spin += dt * 14; d.saw.rotation.z = d.spin; }
      for (const r of dyn.ropes) { const n = world.ropes[r.idx].nodes; r.segs.forEach((s, k) => link(s, n[k].p, n[k + 1].p)); }
      for (const b of dyn.bridges) {
        const n = world.bridges[b.idx].nodes;
        b.planks.forEach((p, k) => { const a = n[Math.max(0, k - 1)].p, c = n[Math.min(n.length - 1, k + 1)].p; p.position.set(n[k].p[0], n[k].p[1] + 0.03, n[k].p[2]); p.rotation.x = -Math.atan2(c[1] - a[1], c[2] - a[2]); });
        for (let side = 0; side < 2; side++) { const sx = side ? 1 : -1; b.rails[side].forEach((s, k) => link(s, [n[k].p[0] + sx * b.width / 2, n[k].p[1] + 0.95, n[k].p[2]], [n[k + 1].p[0] + sx * b.width / 2, n[k + 1].p[1] + 0.95, n[k + 1].p[2]])); }
      }
    },
  };
}
