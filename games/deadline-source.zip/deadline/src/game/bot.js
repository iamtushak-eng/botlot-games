// A scripted player. Used (1) to prove every daily course is beatable and (2) to produce a believable crowd:
// ghosts and death markers for the "yesterday's field" feature when there is no server.
// It only looks at world geometry through the same queries a human sees on screen, and it records plain inputs.
import { rampHeight } from '../physics/collide.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// highest walkable top under (x,z) whose top is within [lo, hi]; returns {y, solid} or null
export function supportAt(world, x, z, lo, hi, S = world) {
  let best = null;
  for (const b of S.boxes) {
    if (b.dead || b.surface === 'kill') continue;
    if (x < b.min[0] - 0.05 || x > b.max[0] + 0.05 || z < b.min[2] - 0.02 || z > b.max[2] + 0.02) continue;
    const y = b.max[1]; if (y < lo || y > hi) continue;
    if (!best || y > best.y) best = { y, solid: b };
  }
  for (const r of S.ramps) {
    if (x < r.min[0] || x > r.max[0] || z < r.min[2] || z > r.max[2]) continue;
    const y = rampHeight(r, x, z); if (y < lo || y > hi) continue;
    if (!best || y > best.y) best = { y, solid: r };
  }
  for (const br of S.bridges) {
    const ax = br.b[0] - br.a[0], az = br.b[2] - br.a[2], L2 = ax * ax + az * az;
    const t = ((x - br.a[0]) * ax + (z - br.a[2]) * az) / L2; if (t < 0 || t > 1) continue;
    const lat = Math.abs((x - br.a[0]) * -az + (z - br.a[2]) * ax) / Math.sqrt(L2); if (lat > br.width * 0.5) continue;
    const f = t * (br.nodes.length - 1), i = Math.min(br.nodes.length - 2, Math.floor(f)), w = f - i;
    const y = br.nodes[i].p[1] * (1 - w) + br.nodes[i + 1].p[1] * w + 0.05; if (y < lo || y > hi) continue;
    if (!best || y > best.y) best = { y, solid: br };
  }
  return best;
}

export class Bot {
  // opts.failZ: after the character passes this z the bot "chokes": stops jumping and dodging. Infinity = never.
  constructor(world, level, char, opts = {}) {
    this.w = world; this.L = level; this.c = char; this.failZ = opts.failZ ?? Infinity;
    this.ragdoll = char.mode === 'ragdoll'; this.footOff = this.ragdoll ? 0.88 : 0;
    this.jumpHold = 0; this.yaw = 0; this.laneBias = opts.laneBias ?? 0; this.lookBias = opts.lookBias ?? 0;
  }
  think() {
    const w = this.w, c = this.c, p = c.pos, vx = c.vel[0], vz = c.vel[2], hs = Math.hypot(vx, vz);
    const foot = p[1] - this.footOff, blind = p[2] > this.failZ;
    const S = this.S = { boxes: w.boxes.filter(b => !b.dead && b.max[2] > p[2] - 3 && b.min[2] < p[2] + 26), ramps: w.ramps.filter(r => r.max[2] > p[2] - 3 && r.min[2] < p[2] + 26), bridges: w.bridges.filter(b => b.b[2] > p[2] - 3 && b.a[2] < p[2] + 26) };
    const inp = { moveX: 0, moveZ: 1, jump: false, jumpHeld: false, slide: false, grab: false, yaw: 0 };
    const here = supportAt(w, p[0], p[2], foot - 0.6, foot + 0.6, S);
    if (c.onGround && here) this.home = here.solid;

    // --- where to steer: centre of the next surface we have to reach ---
    let tx = p[0], bestZ0 = Infinity, nextB = null;
    const cands = [];
    for (const b of w.boxes) if (!b.dead && b.surface !== 'kill' && b.tag !== 'wall' && b.max[2] > p[2] + 0.4 && b.min[2] < p[2] + 16 && b.max[1] > foot - 4 && b.max[1] < foot + 1.6) cands.push(b);
    for (const b of cands) { if (b === here?.solid) continue; if (b.min[2] < bestZ0 && b.min[2] > p[2] - 1) { bestZ0 = b.min[2]; nextB = b; } }
    for (const r of w.ramps) if (r.max[2] > p[2] + 0.4 && r.min[2] < bestZ0 && r.min[2] > p[2] - 1 && r !== here?.solid) { bestZ0 = r.min[2]; nextB = r; }
    for (const br of S.bridges) if (br.b[2] > p[2] + 0.4 && br.a[2] < bestZ0 && br.a[2] > p[2] - 1 && br !== here?.solid) { bestZ0 = br.a[2]; nextB = br; }
    if (here && here.solid.nodes) tx = here.solid.a[0];                       // on a bridge: hold its centre line
    else if (nextB && nextB.nodes) tx = nextB.a[0];
    else if (nextB) tx = (nextB.min[0] + nextB.max[0]) / 2;
    else if (here && here.solid.min) tx = (here.solid.min[0] + here.solid.max[0]) / 2;
    let targetX = tx + this.laneBias, urgent = false;

    // --- hazards: pick a lateral lane that is clear when we get there ---
    if (!blind) {
      const lanes = [];
      // lane bounds come from the surface the threat sits on (not necessarily the one we stand on)
      let tz = null; for (const h of w.hazards) { const dz = h.pos[2] - p[2]; if (dz > -1.8 && dz < 9 && (tz === null || h.pos[2] < tz)) tz = h.pos[2]; }
      for (const b of w.boxes) if (b.surface === 'kill' && b.max[2] > p[2] - 0.3 && b.min[2] < p[2] + 8 && (tz === null || b.min[2] < tz)) tz = (b.min[2] + b.max[2]) / 2;
      let hb = null; if (tz !== null) for (const b of S.boxes) if (b.surface !== 'kill' && b.tag !== 'wall' && tz >= b.min[2] && tz <= b.max[2] && b.max[1] > foot - 3) { hb = b; break; }
      if (!hb) hb = (here && here.solid.min ? here.solid : this.home && this.home.min ? this.home : null);
      const lo = hb ? hb.min[0] + 0.7 : p[0] - 2, hi = hb ? hb.max[0] - 0.7 : p[0] + 2;
      let threatened = false;
      for (const h of w.hazards) {
        const dz = h.pos[2] - p[2]; if (dz < -1.8 || dz > 9) continue;
        const arrive = Math.max(0, dz) / Math.max(hs, 3);
        let hx = h.pos[0];
        if (h.move && h.move.axis === 0) hx = h.base[0] + h.move.amp * Math.sin(Math.PI * 2 * h.move.speed * (w.time + arrive) + (h.move.phase || 0));
        lanes.push({ x: hx, r: h.radius + 0.75 }); if (Math.abs(p[0] - hx) < h.radius + 1.3) threatened = true;
      }
      for (const b of w.boxes) if (b.surface === 'kill' && b.max[2] > p[2] - 0.3 && b.min[2] < p[2] + 8) { lanes.push({ x: (b.min[0] + b.max[0]) / 2, r: (b.max[0] - b.min[0]) / 2 + 0.7 }); if (p[0] > b.min[0] - 0.9 && p[0] < b.max[0] + 0.9) threatened = true; }
      if (lanes.length && threatened) {
        let bestX = p[0], bestS = -1e9;
        for (let x = lo; x <= hi + 1e-6; x += 0.35) {
          let s = 0, clear = true;
          for (const l of lanes) { const d = Math.abs(x - l.x) - l.r; if (d < 0) { clear = false; s -= 100 + (-d); } else s += Math.min(d, 2) * 0.1; }
          s -= Math.abs(x - p[0]) * 0.4;
          if (clear) s += 50;
          if (s > bestS) { bestS = s; bestX = x; }
        }
        targetX = bestX; urgent = true;
      }
    }

    // --- jumping: leave the ground at the last safe moment, or hop a low obstacle ---
    this.jumpHold = Math.max(0, this.jumpHold - 1 / 60);
    if (c.onGround && !blind) {
      const look = 0.3 + hs * 0.035 + (this.ragdoll ? 0.05 : 0) + this.lookBias;
      const ahead = supportAt(w, p[0], p[2] + look, foot - 1.8, foot + 0.5, S); // a short drop onto lower ground is not a gap
      let doJump = !ahead && !(this.ragdoll && supportAt(w, p[0], p[2] + look + 0.6, foot - 0.45, foot + 0.5, S)); // ragdolls shuffle over cracks
      // a wall of raised floor right in front of us
      const step = supportAt(w, p[0], p[2] + 0.9 + hs * 0.06, foot + (this.ragdoll ? 0.85 : 0.35), foot + 1.6, S);
      if (step && step.solid.kind === 'box') doJump = true;
      // a short spike band we can't avoid
      for (const b of w.boxes) if (b.surface === 'kill' && b.min[2] - p[2] < 1.4 + hs * 0.08 && b.min[2] > p[2] && p[0] > b.min[0] - 0.5 && p[0] < b.max[0] + 0.5) doJump = true;
      this.reason = !ahead ? 'gap' : step ? 'step' : 'spike';
      if (doJump) this.jumpHold = this.ragdoll ? 0.35 : 0.5;
      inp.jump = doJump;
    }
    inp.jumpHeld = this.jumpHold > 0 && !blind;
    if (inp.jumpHeld) inp.jump = true;
    // convert "where I want to be" into a stick value for this mode (momentum rotates velocity, so keep it gentle)
    { const dvx = clamp((targetX - p[0]) * (urgent ? 3.0 : 0.8), -(urgent ? 6 : 4.5), urgent ? 6 : 4.5);
      if (['momentum', 'board', 'bike'].includes(c.mode)) inp.moveX = clamp(dvx / Math.max(vz, 6), -0.5, 0.5);
      else if (this.ragdoll) inp.moveX = clamp((targetX - p[0]) * (urgent ? 1.6 : 0.7) - vx * 0.5, -1, 1); // PD: the body lags its input
      else inp.moveX = clamp((targetX - p[0]) * (urgent ? 3 : 0.9), -1, 1); }
    if (!c.onGround && !blind && c.mode === 'precision') inp.moveZ = this.airBrake(foot);
    // quantised exactly like live input so recordings replay bit-for-bit
    inp.moveX = Math.round(inp.moveX * 8) / 8; inp.moveZ = Math.round(inp.moveZ * 8) / 8;
    return inp;
  }
  // choose forward/back stick in mid-air so the predicted landing is on solid ground, as far forward as possible
  airBrake(foot) {
    const c = this.c, S = this.S, g = 26;
    let best = 1, bestScore = -1e9;
    for (const cmd of [1, 0.75, 0.5, 0.25, 0, -0.25, -0.5, -1]) {
      let z = c.pos[2], x = c.pos[0], y = foot, vy = c.vel[1], vz = c.vel[2], score = null;
      for (let t = 0; t < 90; t++) {
        const dt = 1 / 60, tgt = cmd * 6.5; vz += Math.max(-28 * dt, Math.min(28 * dt, tgt - vz));
        vy -= g * (vy < 0 ? 1.9 : (this.jumpHold > 0 ? 1 : 3.6)) * dt;
        z += vz * dt; y += vy * dt;
        if (vy < 0) {
          const sp = supportAt(this.w, x, z, y - 0.6, y + 0.15, S);
          if (sp) { const b = sp.solid; score = (b.kind === 'box' ? Math.min(z - b.min[2], b.max[2] - z, 1.6) : 1.6) + (b === this.home ? -6 : 0) + (z - c.pos[2]) * 0.12; break; }
        }
        if (y < foot - 9) break;
      }
      if (score !== null) { const s = score; if (s > bestScore) { bestScore = s; best = cmd; } }
    }
    return best;
  }
}
const z_bonus = (cmd) => cmd * 0.05; // tie-break toward keeping momentum
