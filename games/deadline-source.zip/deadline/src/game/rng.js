export function hashString(s){let h=1779033703^s.length;for(let i=0;i<s.length;i++){h=Math.imul(h^s.charCodeAt(i),3432918353);h=(h<<13)|(h>>>19);}return h>>>0;}
export function mulberry32(a){return function(){a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}
export function utcDateString(d=new Date()){return d.toISOString().slice(0,10);}
export function yesterdayString(d=new Date()){return utcDateString(new Date(d.getTime()-864e5));}
export function makeRng(dateStr,salt=''){const r=mulberry32(hashString(dateStr+'|'+salt));
 r.range=(a,b)=>a+(b-a)*r();r.int=(a,b)=>Math.floor(a+(b-a+1)*r());r.pick=a=>a[Math.floor(r()*a.length)];r.chance=p=>r()<p;return r;}
