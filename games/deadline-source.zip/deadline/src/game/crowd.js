// "Yesterday's field": where other people died, and who runs alongside you as a ghost.
// With no server these are produced from a scripted player on the real level (deterministic per date+mode),
// so markers sit on actual platforms and ghosts really run the course. Real submissions are merged in by the caller.
import { simulate } from './sim.js';
import { makeRng } from './rng.js';

export function crowdMarkers(level, mode, date, n = 70) {
  const perfect = simulate(level, mode);
  const r = makeRng(date, 'crowd|' + mode);
  const danger = perfect.takeoffs.map((t) => ({ pos: t.pos, z: t.pos[2] }));
  for (const b of level.boxes) if (b.role === 'hall') danger.push({ pos: [(b.min[0] + b.max[0]) / 2, b.max[1], b.min[2] + (b.max[2] - b.min[2]) * 0.5], z: b.min[2] });
  danger.sort((a, b) => a.z - b.z);
  const out = [];
  for (let i = 0; i < n; i++) {
    const p = Math.pow(r(), 1.7) * 0.97, failZ = p * level.goal.z;
    const d = danger.find((x) => x.z >= failZ);
    if (!d) continue; // this one "finished"
    const jx = (r() - 0.5) * 1.6;
    out.push({ pos: [d.pos[0] + jx, d.pos[1], d.pos[2] + 0.4 + r() * 0.9], progress: Math.round((d.z / level.goal.z) * 100) });
  }
  return out;
}

// personalities for live bot ghosts: some choke early, a couple go the distance
export function ghostSpecs(level, date, mode, k = 4) {
  const r = makeRng(date, 'ghosts|' + mode), out = [];
  for (let i = 0; i < k; i++) {
    const strong = i === 0;
    out.push({ failZ: strong ? Infinity : (0.25 + r() * 0.7) * level.goal.z, laneBias: (r() - 0.5) * 1.8, lookBias: (r() - 0.5) * 0.25, tint: ['#9fd0ff', '#ffd59f', '#c9ffa8', '#ffb3d0'][i % 4] });
  }
  return out;
}
