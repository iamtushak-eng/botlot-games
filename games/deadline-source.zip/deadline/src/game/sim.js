// Headless simulation helpers: build a physics world from a level, and run a scripted player through it.
import { World } from '../physics/index.js';
import { Bot } from './bot.js';

export const TICK = 1 / 60;                 // input / recording rate
export const RUN_LIMIT = 90;                // seconds
export const quant = (inp) => ({ ...inp, moveX: Math.round(inp.moveX * 8) / 8, moveZ: Math.round(inp.moveZ * 8) / 8, yaw: Math.round(inp.yaw * 256) / 256 });

export function buildWorld(level) {
  const w = new World();
  for (const b of level.boxes) w.addBox({ min: b.min, max: b.max, surface: b.surface, move: b.move || null, tag: b.role });
  for (const r of level.ramps) w.addRamp(r);
  for (const r of level.ropes) w.addRope(r);
  for (const b of level.bridges) w.addBridge(b);
  for (const h of level.hazards) w.addHazard(h);
  return w;
}

// Play one run with the bot. Returns the recording in the same compact shape the live game records.
export function simulate(level, mode, { failZ = Infinity, limit = RUN_LIMIT } = {}) {
  const world = buildWorld(level);
  const ch = world.createCharacter({ mode, pos: level.start });
  const bot = new Bot(world, level, ch, { failZ });
  const rec = [], trail = [], takeoffs = []; let prevJ = false, status = 'timeout', cause = null, t = 0, maxZ = 0;
  for (let i = 0; i < limit / TICK; i++) {
    const inp = quant(bot.think());
    if (inp.jump && !prevJ && ch.onGround) takeoffs.push({ tick: i, pos: [...ch.pos] });
    prevJ = inp.jump; trail.push(ch.pos[0], ch.pos[1], ch.pos[2]);
    ch.setInput(inp); rec.push(inp);
    world.step(TICK); t += TICK;
    maxZ = Math.max(maxZ, ch.pos[2]);
    for (const e of world.events) if (e.type === 'death') cause = e.cause;
    world.events.length = 0;
    if (ch.dead || ch.pos[1] < level.deathY) { status = 'dead'; cause = cause || 'void'; break; }
    if (ch.pos[2] >= level.goal.z) { status = 'finished'; break; }
  }
  return { status, cause, time: t, progress: Math.max(0, Math.min(1, maxZ / level.goal.z)), pos: [...ch.pos], rec, trail, takeoffs };
}

// ---- compact run-length encoding so a 90 s run is a few KB, not a few hundred ----
const flags = (i) => (i.jump ? 1 : 0) | (i.slide ? 2 : 0) | (i.grab ? 4 : 0);
export function encodeRec(rec) {
  const out = []; let last = null;
  for (const i of rec) {
    const k = [Math.round(i.moveX * 8), Math.round(i.moveZ * 8), flags(i), Math.round(i.yaw * 256)];
    if (last && last[1] === k[0] && last[2] === k[1] && last[3] === k[2] && last[4] === k[3]) last[0]++; else { last = [1, ...k]; out.push(last); }
  }
  return out;
}
export function decodeRec(enc) {
  const out = [];
  for (const [n, mx, mz, f, yaw] of enc) for (let i = 0; i < n; i++) out.push({ moveX: mx / 8, moveZ: mz / 8, jump: !!(f & 1), jumpHeld: !!(f & 1), slide: !!(f & 2), grab: !!(f & 4), yaw: yaw / 256 });
  return out;
}
