// Procedural surface detail: tileable canvas textures sampled in 3D (triplanar, object space) so
// nothing needs UVs. Kept as multipliers on the existing vertex colours.
import * as THREE from 'three';

function mulberry(a) { return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// periodic value noise on an N×N grid with cx×cy lattice cells
function vnoise(N, cx, cy, rnd) {
  const g = new Float32Array(cx * cy); for (let i = 0; i < g.length; i++) g[i] = rnd();
  const out = new Float32Array(N * N), sm = (t) => t * t * (3 - 2 * t);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const fx = (x / N) * cx, fy = (y / N) * cy, x0 = Math.floor(fx), y0 = Math.floor(fy), tx = sm(fx - x0), ty = sm(fy - y0);
    const a = g[(y0 % cy) * cx + (x0 % cx)], b = g[(y0 % cy) * cx + ((x0 + 1) % cx)], c = g[(((y0 + 1) % cy)) * cx + (x0 % cx)], d = g[((y0 + 1) % cy) * cx + ((x0 + 1) % cx)];
    out[y * N + x] = (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
  }
  return out;
}

function toTexture(v, N) {
  const cv = document.createElement('canvas'); cv.width = cv.height = N; const ctx = cv.getContext('2d'), im = ctx.createImageData(N, N);
  for (let i = 0; i < N * N; i++) { const k = Math.max(0, Math.min(255, Math.round(v[i] * 255))); im.data[i * 4] = k; im.data[i * 4 + 1] = k; im.data[i * 4 + 2] = k; im.data[i * 4 + 3] = 255; }
  ctx.putImageData(im, 0, 0);
  const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; t.colorSpace = THREE.NoColorSpace; t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter; return t;
}

// concrete / weathered stone: blotches, pitting, vertical water streaks, a few cracks
export function makeStone(N = 256, seed = 1) {
  const r = mulberry(seed), v = new Float32Array(N * N).fill(0.5);
  [[3, 3, 0.20], [6, 6, 0.14], [12, 12, 0.10], [24, 24, 0.07], [48, 48, 0.05]].forEach(([cx, cy, a]) => { const n = vnoise(N, cx, cy, r); for (let i = 0; i < v.length; i++) v[i] += (n[i] - 0.5) * 2 * a; });
  const streak = vnoise(N, 5, 40, r); for (let i = 0; i < v.length; i++) v[i] -= Math.max(0, streak[i] - 0.55) * 0.5;
  for (let i = 0; i < v.length; i++) { const p = r(); if (p > 0.985) v[i] -= 0.22; else v[i] += (r() - 0.5) * 0.06; }
  for (let c = 0; c < 4; c++) { let x = r() * N, y = r() * N, a = r() * 6.28; const len = 30 + r() * 80; for (let s = 0; s < len; s++) { a += (r() - 0.5) * 0.7; x = (x + Math.cos(a) + N) % N; y = (y + Math.sin(a) + N) % N; const k = (y | 0) * N + (x | 0); v[k] -= 0.2; v[((y + 1) % N | 0) * N + (x | 0)] -= 0.12; } }
  return toTexture(v, N);
}

// woven fabric
export function makeCloth(N = 128, seed = 2) {
  const r = mulberry(seed), v = new Float32Array(N * N), n = vnoise(N, 8, 8, r), f = 24;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const w = Math.sin(2 * Math.PI * x * f / N) * Math.sin(2 * Math.PI * y * f / N); v[y * N + x] = 0.5 + w * 0.16 + (n[y * N + x] - 0.5) * 0.18 + (r() - 0.5) * 0.05; }
  return toTexture(v, N);
}

export function applySurface(mat, tex, scale = 0.25, strength = 0.9) {
  if (!mat || mat.userData.surf) return mat; mat.userData.surf = true;
  mat.userData.surfPatch = (sh) => {
    sh.uniforms.uTex = { value: tex }; sh.uniforms.uScale = { value: scale }; sh.uniforms.uStr = { value: strength };
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOP; varying vec3 vON;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvOP = position; vON = normal;');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vOP; varying vec3 vON; uniform sampler2D uTex; uniform float uScale, uStr;')
      .replace('#include <color_fragment>', `#include <color_fragment>
        vec3 _bw = pow(abs(vON), vec3(4.0)); _bw /= (_bw.x + _bw.y + _bw.z + 1e-4);
        vec3 _t1 = texture2D(uTex, vOP.yz * uScale).rgb * _bw.x + texture2D(uTex, vOP.xz * uScale).rgb * _bw.y + texture2D(uTex, vOP.xy * uScale).rgb * _bw.z;
        vec3 _o = vOP + vec3(13.7, 5.1, 9.3); mat2 _r = mat2(0.8, -0.6, 0.6, 0.8); float _s2 = uScale * 0.37;
        vec3 _t2 = texture2D(uTex, _r * _o.yz * _s2).rgb * _bw.x + texture2D(uTex, _r * _o.xz * _s2).rgb * _bw.y + texture2D(uTex, _r * _o.xy * _s2).rgb * _bw.z;
        vec3 _t = mix(_t1, _t2, 0.5);
        diffuseColor.rgb *= mix(vec3(1.0), _t * 2.0, uStr);`)
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = clamp(roughnessFactor * (1.2 - _t.r * 0.7), 0.25, 1.0);');
  };
  mat.onBeforeCompile = mat.userData.surfPatch; mat.customProgramCacheKey = () => 'surf';
  mat.needsUpdate = true; return mat;
}

let stone = null, cloth = null;
export const stoneTex = () => (stone ||= makeStone());
export const clothTex = () => (cloth ||= makeCloth());

// world surfaces: every vertex-coloured standard material gets the stone treatment
export function texturiseWorld(root) {
  root.traverse((o) => { if (o.isMesh && o.material && !Array.isArray(o.material) && o.material.vertexColors && o.material.isMeshStandardMaterial) applySurface(o.material, stoneTex(), 0.22, 0.85); });
}
