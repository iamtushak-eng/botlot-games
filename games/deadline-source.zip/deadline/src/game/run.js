// One attempt at one mode: countdown -> running -> dead | finished | timeout. Records inputs for replay.
import { utcDateString, yesterdayString } from './rng.js';
import { TICK, RUN_LIMIT, encodeRec } from './sim.js';
import { markStarted } from '../social/store.js';

export const MODES = ['momentum', 'board', 'bike'];
export class Run {
  constructor({ mode, practice, goalZ }) {
    this.mode = mode; this.practice = practice; this.goalZ = goalZ;
    this.date = practice ? yesterdayString() : utcDateString();
    this.state = 'countdown'; this.count = 3.0; this.ticks = 0; this.maxZ = 0; this.rec = []; this.cause = null;
    if (!practice) markStarted(this.date, mode); // the attempt is spent the moment it begins, even if the tab closes
  }
  get time() { return this.ticks * TICK; }
  get timeLeft() { return Math.max(0, RUN_LIMIT - this.time); }
  get progress() { return Math.max(0, Math.min(1, this.maxZ / this.goalZ)); }
  tickCountdown(dt) { this.count -= dt; if (this.count <= 0) { this.state = 'running'; return true; } return false; }
  record(inp, z) { this.rec.push(inp); this.ticks++; this.maxZ = Math.max(this.maxZ, z); if (this.time >= RUN_LIMIT) this.end('timeout', 'The clock ran out.'); }
  end(kind, cause) { if (this.state !== 'running') return; this.state = kind === 'finished' ? 'finished' : 'dead'; this.cause = cause; this.endedAt = performance.now(); }
  get encoded() { return encodeRec(this.rec); }
}
