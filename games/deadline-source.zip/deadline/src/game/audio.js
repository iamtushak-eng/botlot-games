// Score: the supplied MP3, looped with a crossfade and filtered by how fast you are moving. Effects: sfxr-style one-shots.
import { sfxr } from 'jsfxr';

const XF = 1.4;   // loop crossfade (s): the track fades out at its end, so overlap it with its own start

const BASE = { oldParams: true, wave_type: 0, p_env_attack: 0, p_env_sustain: 0.1, p_env_punch: 0, p_env_decay: 0.2, p_base_freq: 0.3, p_freq_limit: 0, p_freq_ramp: 0, p_freq_dramp: 0, p_vib_strength: 0, p_vib_speed: 0, p_arp_mod: 0, p_arp_speed: 0, p_duty: 0.5, p_duty_ramp: 0, p_repeat_speed: 0, p_pha_offset: 0, p_pha_ramp: 0, p_lpf_freq: 1, p_lpf_ramp: 0, p_lpf_resonance: 0, p_hpf_freq: 0, p_hpf_ramp: 0, sound_vol: 0.25, sample_rate: 44100, sample_size: 8 };
const S = (o) => ({ ...BASE, ...o });
const FX = {
  jump:       S({ wave_type: 0, p_base_freq: 0.32, p_freq_ramp: 0.2, p_env_sustain: 0.06, p_env_decay: 0.14, p_duty: 0.35, p_lpf_freq: 0.7, sound_vol: 0.16 }),
  landSoft:   S({ wave_type: 3, p_base_freq: 0.16, p_freq_ramp: -0.25, p_env_sustain: 0.015, p_env_decay: 0.1, p_lpf_freq: 0.35, sound_vol: 0.2 }),
  landHard:   S({ wave_type: 3, p_base_freq: 0.12, p_freq_ramp: -0.3, p_env_sustain: 0.04, p_env_decay: 0.28, p_env_punch: 0.4, p_lpf_freq: 0.3, sound_vol: 0.32 }),
  step:       S({ wave_type: 3, p_base_freq: 0.3, p_env_sustain: 0.005, p_env_decay: 0.035, p_lpf_freq: 0.4, p_hpf_freq: 0.1, sound_vol: 0.05 }),
  slide:      S({ wave_type: 3, p_base_freq: 0.4, p_env_sustain: 0.1, p_env_decay: 0.2, p_lpf_freq: 0.5, p_hpf_freq: 0.2, sound_vol: 0.08 }),
  crumble:    S({ wave_type: 3, p_base_freq: 0.2, p_freq_ramp: -0.1, p_env_sustain: 0.12, p_env_decay: 0.3, p_lpf_freq: 0.4, p_repeat_speed: 0.55, sound_vol: 0.16 }),
  grab:       S({ wave_type: 2, p_base_freq: 0.45, p_freq_ramp: 0.1, p_env_sustain: 0.02, p_env_decay: 0.1, sound_vol: 0.12 }),
  tick:       S({ wave_type: 0, p_base_freq: 0.5, p_env_sustain: 0.02, p_env_decay: 0.09, p_duty: 0.5, sound_vol: 0.1 }),
  deathHit:   S({ wave_type: 3, p_base_freq: 0.1, p_freq_ramp: -0.2, p_env_sustain: 0.1, p_env_decay: 0.45, p_env_punch: 0.6, p_lpf_freq: 0.5, sound_vol: 0.36 }),
  deathFall:  S({ wave_type: 1, p_base_freq: 0.4, p_freq_ramp: -0.35, p_env_sustain: 0.2, p_env_decay: 0.5, p_lpf_freq: 0.6, sound_vol: 0.16 }),
  checkpoint: S({ wave_type: 0, p_base_freq: 0.4, p_arp_mod: 0.4, p_arp_speed: 0.6, p_env_sustain: 0.1, p_env_decay: 0.25, p_duty: 0.5, sound_vol: 0.16 }),
  goal:       S({ wave_type: 0, p_base_freq: 0.3, p_freq_ramp: 0.12, p_arp_mod: 0.5, p_arp_speed: 0.5, p_env_sustain: 0.3, p_env_decay: 0.6, p_duty: 0.45, sound_vol: 0.22 }),
};

export class GameAudio {
  constructor() { this.vol = 0.7; this.ctx = null; this.buf = null; this.bus = null; this.timer = 0; this.nextT = 0; this.srcs = []; this.running = false; this.dead = false; this.cur = 0; this.cut = 900; }
  async _load() {
    if (this.buf) return;
    let ab; const emb = window.__DEADLINE_MUSIC;
    if (emb) { const bin = atob(emb), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); ab = u.buffer; }
    else ab = await (await fetch('assets/music/score.mp3')).arrayBuffer();
    this.buf = await this.ctx.decodeAudioData(ab);
  }
  start() {
    if (/nomusic/.test(location.search)) return;
    try {
      if (!this.ctx) {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        const g = this.ctx.createGain(), lp = this.ctx.createBiquadFilter(), lim = this.ctx.createDynamicsCompressor();
        lp.type = 'lowpass'; lp.Q.value = 0.7; lim.threshold.value = -8; lim.ratio.value = 10; lim.attack.value = 0.003; lim.release.value = 0.2;
        g.connect(lp); lp.connect(lim); lim.connect(this.ctx.destination); this.bus = { g, lp };
      }
      this.ctx.resume(); this.dead = false; this.running = true; this.cur = 0; this.cut = 900; this.bus.g.gain.value = 0; this.bus.lp.frequency.value = 900;
      this._load().then(() => { if (!this.running) return; this.nextT = this.ctx.currentTime + 0.05; this._pump(); this.timer = setInterval(() => this._pump(), 500); }).catch((e) => console.warn('music failed', e));
    } catch (e) { console.warn('music failed', e); }
  }
  _pump() {
    const d = this.buf.duration, t = this.ctx.currentTime;
    while (this.nextT < t + 3) {
      const src = this.ctx.createBufferSource(), env = this.ctx.createGain(), first = this.srcs.length === 0, at = this.nextT;
      src.buffer = this.buf; src.connect(env); env.connect(this.bus.g);
      env.gain.setValueAtTime(first ? 0.0001 : 0.0001, at); env.gain.linearRampToValueAtTime(1, at + (first ? 0.25 : XF));
      env.gain.setValueAtTime(1, at + d - XF); env.gain.linearRampToValueAtTime(0.0001, at + d);
      src.start(at); src.stop(at + d + 0.05); this.srcs.push(src); src.onended = () => { this.srcs = this.srcs.filter((x) => x !== src); };
      this.nextT += d - XF;
    }
  }
  setVolume(v) { this.vol = v; }
  stopMusic() { this.running = false; clearInterval(this.timer); if (!this.ctx || !this.bus) return; const t = this.ctx.currentTime; this.bus.g.gain.cancelScheduledValues(t); this.bus.g.gain.setTargetAtTime(0, t, 0.25); setTimeout(() => { for (const s of this.srcs) { try { s.stop(); } catch {} } this.srcs = []; }, 1200); }
  update(speed01, danger01, finish01) {
    if (!this.running || !this.bus) return;
    const k = Math.min(1, speed01 + finish01 * 0.5), t = this.ctx.currentTime;
    const wantCut = this.dead ? 260 : 700 * Math.pow(26, k);                 // 700 Hz closed room -> ~18 kHz fully open
    const wantGain = this.vol * (this.dead ? 0.35 : 0.5 + 0.4 * k) * (1 - 0.25 * danger01);
    this.cut += (wantCut - this.cut) * 0.08; this.cur += (wantGain - this.cur) * 0.06;
    this.bus.lp.frequency.setTargetAtTime(Math.max(120, Math.min(20000, this.cut)), t, 0.05); this.bus.g.gain.setTargetAtTime(Math.max(0, this.cur), t, 0.05);
  }
  play(def, vol = 1, rate = 1) {
    try { const s = { ...def, sound_vol: def.sound_vol * vol * this.vol * 1.4, p_base_freq: Math.max(0.02, Math.min(0.98, def.p_base_freq * rate)) }; sfxr.play(s); } catch {}
  }
  handleEvent(e) {
    const r = 0.94 + Math.random() * 0.12;
    switch (e.type) {
      case 'jump': this.play(FX.jump, 1, r); break;
      case 'land': { const k = Math.min(1, (e.impact || 0) / 18); if (k > 0.55) this.play(FX.landHard, 0.6 + k * 0.6, r); else if (k > 0.12) this.play(FX.landSoft, 0.5 + k, r); break; }
      case 'footstep': this.play(FX.step, 1, r); break;
      case 'slide': this.play(FX.slide, 1, r); break;
      case 'crumble': this.play(FX.crumble, 1, r); break;
      case 'grab': this.play(FX.tick, 1, 1); break;
      case 'checkpoint': this.play(FX.checkpoint, 1, 1); break;
      case 'goal': this.play(FX.goal, 1, 1); break;
      case 'death': this.play(FX.deathHit, 1, r); this.play(FX.deathFall, 1, 1); this.dead = true; break;
    }
  }
}
