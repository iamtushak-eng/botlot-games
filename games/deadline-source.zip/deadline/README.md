# Deadline

One course a day. One life. 90 seconds. Same course for everyone (seeded by UTC date), three modes, one attempt each per day.

## Run
    npm i esbuild three        # three@0.170
    node tools/build.mjs       # writes dist/
    cd dist && python3 -m http.server 8000

`dist/` is static, so you can put it on any host.

## Controls
WASD move, Space jump, Shift/C slide, E grab, mouse look, V toggles first/third person, P leaves practice. Gamepad: left stick, right stick look, A jump, B slide, X grab.

## Backend (optional)
Without it, runs and "yesterday's field" live in localStorage and the crowd is simulated. For the real thing:
1. Create a Cloudflare KV namespace; put its id in `wrangler.toml`; `wrangler secret put IP_SALT`; `wrangler deploy server/worker.js`.
2. Set `window.DEADLINE_API = 'https://your-worker.workers.dev'` before app.js loads.

## Tests / tools
`node tests/physics.test.mjs`, `node tools/measure_reach.mjs 24 [mode]` (bot solvability), `tools/play.mjs`, `flow.mjs` (headless-Chrome drivers; need puppeteer-core).
