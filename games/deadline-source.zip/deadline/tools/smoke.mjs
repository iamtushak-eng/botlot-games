import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 1100, height: 650 });
const logs = []; p.on('console', m => logs.push(m.type() + ': ' + m.text().slice(0, 400))); p.on('pageerror', e => logs.push('PAGEERROR: ' + String(e).slice(0, 400)));
await p.goto('http://localhost:8123/index.html'); await new Promise(r => setTimeout(r, 6000));
await p.screenshot({ path: '/tmp/s_title.png' });
console.log(logs.slice(0, 15).join('\n')); await b.close();
