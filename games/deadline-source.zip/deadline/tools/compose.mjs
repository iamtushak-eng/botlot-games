// Builds the score with BeepBox's own Song class and checks it by rendering each channel alone.
import { Song, Synth } from '../node_modules/beepbox/esm/synth/index.js';
import fs from 'node:fs';
const j = new Song().toJsonObject();
const drumT = JSON.parse(JSON.stringify(j.channels[3])), pitchT = JSON.parse(JSON.stringify(j.channels[0]));
Object.assign(j, { scale: 'free', key: 'C', beatsPerMinute: 124, loopBars: 8, introBars: 0, beatsPerBar: 4, ticksPerBeat: 4 });
const roots = [0, 0, 8, 10, 0, 0, 8, 7], maj = [0, 0, 1, 1, 0, 0, 1, 1];
const N = (p, t, len, v = 100) => ({ pitches: Array.isArray(p) ? p : [p], points: [{ tick: t, pitchBend: 0, volume: v }, { tick: t + len, pitchBend: 0, volume: v }] });
const bass = [], pad = [], lead = [], kick = [], snare = [], hat = [];
for (let b = 0; b < 8; b++) {
  const r = roots[b], th = maj[b] ? 4 : 3;           // one bar = 16 ticks (sixteenths)
  bass.push({ notes: [0, 0, 12, 0, 0, 12, 7, 0].map((o, i) => N(12 + r + o, i * 2, 2)) });
  pad.push({ notes: [N([24 + r, 24 + r + th, 24 + r + 7], 0, 16)] });
  const ln = [];
  if (b % 4 >= 2) for (let i = 0; i < 16; i++) ln.push(N(30 + r + [0, th, 7, 12][i % 4] + (i >= 8 ? 0 : 0), i, 1, i % 4 === 0 ? 100 : 80));
  else ln.push(N(30 + r + 12, 0, 5), N(30 + r + th + 12, 6, 3), N(30 + r + 7 + 12, 10, 5));
  lead.push({ notes: ln });
  kick.push({ notes: [0, 4, 8, 12].map((t) => N(0, t, 2)).concat(b % 4 === 3 ? [N(0, 14, 1)] : []) });
  snare.push({ notes: [4, 12].map((t) => N(6, t, 2)).concat(b % 4 === 3 ? [N(6, 15, 1, 80)] : []) });
  hat.push({ notes: (b % 2 ? [0, 2, 4, 6, 8, 10, 12, 14].map((t, i) => N(11, t, 1, i % 2 ? 60 : 90)) : [2, 6, 10, 14].map((t) => N(11, t, 1, 90))) });
}
const mkPitch = (patterns, wave, env, vol = 100) => { const c = JSON.parse(JSON.stringify(pitchT)); c.patterns = patterns; c.sequence = [1, 2, 3, 4, 5, 6, 7, 8]; Object.assign(c.instruments[0], { wave, volume: vol, effects: [], chord: 'simultaneous', envelopes: env ? [{ target: 'noteVolume', envelope: env }] : [] }); return c; };
const mkDrum = (patterns, wave, env, vol = 100) => { const c = JSON.parse(JSON.stringify(drumT)); c.patterns = patterns; c.sequence = [1, 2, 3, 4, 5, 6, 7, 8]; Object.assign(c.instruments[0], { wave, volume: vol, effects: [], chord: 'simultaneous', envelopes: [{ target: 'noteVolume', envelope: env }] }); return c; };
const CFG = JSON.parse(process.env.CFG || '{"bass":100,"pad":100,"lead":100,"kick":100,"snare":90,"hat":70}');
j.channels = [mkPitch(bass, process.env.BW || 'sawtooth', 'decay 1', CFG.bass), mkPitch(pad, 'rounded', null, CFG.pad), mkPitch(lead, 'pulse width', 'decay 2', CFG.lead), mkDrum(kick, process.env.KW || 'deep', 'decay 2', CFG.kick), mkDrum(snare, process.env.SW || 'white', 'decay 2', CFG.snare), mkDrum(hat, process.env.HW || 'white', 'decay 3', CFG.hat)];
const s = new Song(); s.fromJsonObject(j); const hash = s.toBase64String(); fs.writeFileSync('/tmp/song_hash.txt', hash);
// ---- measurements ----
const sr = 44100, nSamp = Math.floor(sr * (60 / 124) * 4 * 8);
const rend = (mute) => { const y = new Synth(hash); y.samplesPerSecond = sr; y.loopRepeatCount = 0; y.snapToStart(); y.song.channels.forEach((c, i) => c.muted = mute.includes(i)); const L = new Float32Array(nSamp), R = new Float32Array(nSamp); y.isPlayingSong = true; y.synthesize(L, R, nSamp, true); return L; };
const rms = (a) => Math.sqrt(a.reduce((q, v) => q + v * v, 0) / a.length), pk = (a) => a.reduce((m, v) => Math.max(m, Math.abs(v)), 0);
const cent = (a) => { let num = 0, den = 0; for (let st = 0; st + 2048 < a.length && st < sr * 4; st += 4096) { for (let k = 2; k < 512; k++) { let re = 0, im = 0; for (let n = 0; n < 2048; n += 2) { const ph = 2 * Math.PI * k * n / 2048; re += a[st + n] * Math.cos(ph); im -= a[st + n] * Math.sin(ph); } const m = Math.hypot(re, im); num += m * k * sr / 2048; den += m; } } return Math.round(num / (den || 1)); };
const names = ['bass', 'pad', 'lead', 'kick', 'snare', 'hat'], all = rend([]);
console.log('MIX rms', rms(all).toFixed(4), 'peak', pk(all).toFixed(3), 'hash', hash.length);
names.forEach((nm, i) => { const o = rend(names.map((_, k) => k).filter((k) => k !== i)); console.log(nm.padEnd(6), 'rms', rms(o).toFixed(4), 'peak', pk(o).toFixed(3), 'centroidHz', cent(o)); });
