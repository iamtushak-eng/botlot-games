"""Deadline runner v2: hand-built low-poly free-runner. Run: python3 tools/model_runner_v2.py
Blender Z-up -> glTF Y-up. Character faces Blender -Y (glTF +Z). L = -X.
Writes assets/models/runner.glb (backs up old as runner_old.glb once). COLOR_0 = greyscale AO only."""
import bpy, bmesh, math, os, shutil, random, json
from mathutils import Vector as V, Matrix, Euler
from mathutils.bvhtree import BVHTree

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "assets/models")
rng = random.Random(7)

# ---------------------------------------------------------------- primitives
def sweep(bm, rings, w=(1, 0, 0), segs=10, sq=2.0, noise=0.0, cap=True):
    """rings: (cx,cy,cz,rw,rt). Ring plane is perpendicular to the path; rw along w, rt along n."""
    cs = [V(r[:3]) for r in rings]; wv = V(w); out = []
    for i, r in enumerate(rings):
        t = (cs[min(i + 1, len(cs) - 1)] - cs[max(i - 1, 0)]).normalized()
        ww = (wv - t * wv.dot(t)).normalized(); n = t.cross(ww)
        ring = []
        for k in range(segs):
            a = 2 * math.pi * k / segs; c, s = math.cos(a), math.sin(a)
            p = 2.0 / sq
            c = math.copysign(abs(c) ** p, c); s = math.copysign(abs(s) ** p, s)
            f = 1 + (rng.uniform(-noise, noise) if noise else 0)
            ring.append(bm.verts.new(cs[i] + ww * (r[3] * c * f) + n * (r[4] * s * f)))
        out.append(ring)
    for i in range(len(out) - 1):
        for k in range(segs):
            bm.faces.new((out[i][k], out[i][(k + 1) % segs], out[i + 1][(k + 1) % segs], out[i + 1][k]))
    if cap:
        bm.faces.new(out[0]); bm.faces.new(out[-1][::-1])
    return out

def _xf(verts, center, size, rot):
    m = Matrix.Translation(center) @ Euler(rot).to_matrix().to_4x4() @ Matrix.Diagonal((*size, 1))
    for v in verts: v.co = m @ v.co

def box(bm, center, size, rot=(0, 0, 0), bevel=0.012, seg=2):
    r = bmesh.ops.create_cube(bm, size=1.0); vs = r['verts']; _xf(vs, center, size, rot)
    b = min(bevel, min(size) * 0.34)
    if b > 0:
        es = list({e for v in vs for e in v.link_edges})
        bmesh.ops.bevel(bm, geom=es, offset=b, segments=seg, affect='EDGES')

def ell(bm, center, radii, rot=(0, 0, 0), u=10, v=7):
    r = bmesh.ops.create_uvsphere(bm, u_segments=u, v_segments=v, radius=1.0); _xf(r['verts'], center, radii, rot)

# ---------------------------------------------------------------- joints (Blender coords)
def J(name):
    S = -1 if name.endswith("_L") else 1
    t = {"pelvis": (0, 0, .95), "torso": (0, 0, 1.05), "head": (0, 0, 1.56), "scarf": (0, 0, 1.52),
         "upper_arm": (.3 * S, 0, 1.42), "lower_arm": (.3 * S, 0, 1.12), "hand": (.3 * S, 0, .82),
         "upper_leg": (.11 * S, 0, .9), "lower_leg": (.11 * S, 0, .5), "foot": (.11 * S, 0, .1)}
    return V(t[name.rsplit("_", 1)[0] if name[-2:] in ("_L", "_R") else name])

parts = {}   # name -> dict(bm, origin, parent)
def P(name, parent=None, origin=None):
    bm = bmesh.new(); parts[name] = dict(bm=bm, origin=V(origin) if origin is not None else J(name), parent=parent)
    return bm

def Z(bm, x, rings, **kw):  # vertical loft: rings (z, rx, ry, cy, cx_off)
    return sweep(bm, [(x + (r[4] if len(r) > 4 else 0), r[3] if len(r) > 3 else 0, r[0], r[1], r[2]) for r in rings], **kw)

# ---------------------------------------------------------------- pelvis (trousers waist + hips)
b = P("pelvis")
Z(b, 0, [(.80, .150, .100, 0.0), (.86, .185, .118, 0.0), (.93, .198, .125, 0.0), (1.00, .185, .118, 0), (1.07, .178, .112, 0)],
  segs=12, sq=2.3, noise=.004)

# ---------------------------------------------------------------- torso (zip jacket)
b = P("torso")
Z(b, 0, [(.935, .200, .128, .0), (.965, .212, .136, .0), (1.00, .200, .130, 0), (1.10, .180, .120, 0), (1.20, .195, .128, -.004),
         (1.31, .212, .138, -.006), (1.40, .226, .142, -.004), (1.455, .232, .128, .0), (1.495, .13, .095, .0), (1.51, .10, .08, 0)],
  segs=14, sq=2.4)
for s_ in (-1, 1):
    box(b, (.095 * s_, -.128, 1.06), (.09, .03, .10), rot=(.05, 0, -.12 * s_), bevel=.012, seg=1)
    box(b, (.105 * s_, -.138, 1.29), (.08, .026, .055), rot=(.1, 0, 0), bevel=.01, seg=1)
# trim: collar, zipper, pack
t = P("trim_collar", "torso", J("torso"))
Z(t, 0, [(1.44, .135, .115, .004), (1.49, .125, .108, .006), (1.54, .105, .095, .008)], segs=12, sq=2.2, cap=False)
box(t, (0, -.145, 1.27), (.016, .012, .46), bevel=.004, seg=1)
box(t, (0, -.152, 1.04), (.03, .014, .04), bevel=.004, seg=1)
t = P("pack_bag", "torso", J("torso"))
box(t, (0, .205, 1.22), (.30, .11, .32), bevel=.035, seg=3)
box(t, (0, .21, 1.375), (.29, .12, .08), rot=(-.08, 0, 0), bevel=.025, seg=3)
box(t, (0, .275, 1.18), (.16, .02, .12), bevel=.01)
for s in (-1, 1):
    box(t, (.158 * s, .2, 1.13), (.035, .085, .15), bevel=.012)
    sweep(t, [(.10 * s, .15, 1.40, .022, .006), (.105 * s, .125, 1.465, .022, .006), (.105 * s, .05, 1.505, .022, .006),
              (.105 * s, -.07, 1.49, .022, .006), (.105 * s, -.135, 1.43, .022, .006), (.105 * s, -.152, 1.32, .022, .006)],
          segs=6, sq=3.0, cap=True)
box(t, (0, -.15, 1.34), (.2, .014, .022), bevel=.004, seg=1)   # sternum strap

# ---------------------------------------------------------------- head
b = P("head")
Z(b, 0, [(1.585, .040, .050, -.035), (1.615, .066, .074, -.018), (1.655, .082, .092, -.004), (1.705, .088, .102, .004),
         (1.755, .084, .098, .006), (1.79, .062, .075, .006), (1.805, .028, .04, .006)], segs=12, sq=2.1)
ell(b, (0, -.095, 1.675), (.014, .024, .028), rot=(.35, 0, 0), u=6, v=4)              # nose
box(b, (0, -.087, 1.700), (.115, .03, .016), rot=(-.1, 0, 0), bevel=.006, seg=1)             # brow ridge
for s in (-1, 1):
    ell(b, (.088 * s, .004, 1.68), (.012, .026, .036), u=6, v=5)                      # ears
ell(b, (0, -.082, 1.605), (.03, .03, .02), u=6, v=4)                                 # chin
t = P("trim_beanie", "head", J("head"))
Z(t, 0, [(1.712, .094, .108, .006), (1.742, .097, .110, .006), (1.752, .092, .105, .006), (1.78, .088, .102, .008),
         (1.805, .062, .078, .01), (1.825, .022, .03, .01)], segs=14, sq=2.1, noise=.002)
Z(t, 0, [(1.708, .098, .112, .006), (1.742, .100, .114, .006)], segs=14, sq=2.1)    # folded cuff

for _n in ('head', 'trim_beanie'):
    for v in parts[_n]['bm'].verts: v.co.x *= 1.12; v.co.y = (v.co.y - .006) * 1.1 + .006
# ---------------------------------------------------------------- scarf / neck gaiter
b = P("scarf")
Z(b, 0, [(1.455, .128, .108, .006), (1.49, .12, .104, .004), (1.52, .112, .10, .0), (1.555, .102, .092, -.004), (1.60, .092, .086, -.008)],
  segs=12, sq=2.2, noise=.004, cap=False)
Z(b, 0, [(1.50, .128, .110, .006), (1.52, .128, .110, .006)], segs=12, sq=2.2)    # knot band
for s, L, sh in ((1, 1.0, 0.0), (-1, .72, .7)):
    pts = [(.07 * s, .10, 1.50), (.075 * s, .165, 1.455), (.085 * s + .01 * sh, .25, 1.405), (.09 * s - .015 * sh, .30, 1.34 * 1 - .03 * L),
           (.085 * s + .02 * sh, .325, 1.34 - .10 * L), (.08 * s, .335, 1.34 - .19 * L)]
    sweep(b, [(p[0], p[1], p[2], .042 - i * .002, .008) for i, p in enumerate(pts)], segs=6, sq=3.0)
    box(b, (pts[-1][0], pts[-1][1], pts[-1][2] - .015), (.05, .014, .05), rot=(0, 0, .1 * s), bevel=.004, seg=1)

# ---------------------------------------------------------------- arms
for s, S in (("L", -1), ("R", 1)):
    X = .3 * S
    b = P(f"upper_arm_{s}")
    Z(b, X, [(1.465, .040, .040, 0), (1.44, .062, .066, 0), (1.36, .056, .062, .002), (1.24, .050, .056, .0), (1.14, .046, .052, 0)],
      segs=10, sq=2.2, noise=.003)
    ell(b, (X, 0, 1.435), (.066, .068, .06), u=8, v=5); ell(b, (X, 0, 1.12), (.047, .052, .047), u=8, v=5)
    b = P(f"lower_arm_{s}")
    ell(b, (X, 0, 1.12), (.047, .052, .047), u=8, v=5)
    Z(b, X, [(1.12, .047, .052, 0), (1.04, .047, .054, -.004), (.99, .058, .062, -.004), (.965, .052, .056, -.004),
             (.93, .042, .046, 0), (.86, .036, .040, 0), (.835, .037, .041, 0)], segs=10, sq=2.2, noise=.003)  # rolled sleeve bunch
    t = P(f"trim_wrap_{s}", f"lower_arm_{s}", J(f"lower_arm_{s}"))
    Z(t, X, [(.925, .045, .049, 0), (.90, .047, .051, 0), (.86, .046, .05, 0), (.835, .045, .049, 0)], segs=10, sq=2.2, cap=True)
    b = P(f"hand_{s}")
    box(b, (X, 0.0, .765), (.088, .042, .10), bevel=.014, seg=2)
    for i, fx in enumerate((-.032, -.011, .011, .032)):
        ln = (.058, .066, .062, .05)[i]
        pts = [(X + fx, -.004, .73), (X + fx, -.012, .73 - ln * .45), (X + fx, -.03, .73 - ln * .8), (X + fx, -.05, .73 - ln * .92)]
        sweep(b, [(p[0], p[1], p[2], .0105 - j * .0008, .0115 - j * .0008) for j, p in enumerate(pts)], segs=6)
    inn = -S
    pts = [(X + inn * .04, -.012, .79), (X + inn * .055, -.035, .765), (X + inn * .058, -.055, .74)]
    sweep(b, [(p[0], p[1], p[2], .012 - j * .001, .013 - j * .001) for j, p in enumerate(pts)], segs=6)

# ---------------------------------------------------------------- legs
for s, S in (("L", -1), ("R", 1)):
    X = .11 * S
    b = P(f"upper_leg_{s}")
    Z(b, X, [(.925, .092, .104, .0), (.86, .096, .108, -.004), (.74, .086, .098, -.006), (.62, .075, .086, -.004), (.52, .066, .076, -.002)],
      segs=10, sq=2.3, noise=.004)
    ell(b, (X, -.004, .5), (.066, .074, .066), u=8, v=5)
    box(b, (X + S * .08, -.01, .70), (.035, .09, .12), rot=(0, 0, S * .05), bevel=.012, seg=1)       # cargo pocket
    box(b, (X + S * .085, -.01, .745), (.04, .095, .02), bevel=.006, seg=1)                     # pocket flap
    b = P(f"lower_leg_{s}")
    ell(b, (X, -.004, .5), (.066, .074, .066), u=8, v=5)
    Z(b, X, [(.50, .066, .076, -.003), (.42, .060, .072, -.006), (.32, .054, .066, -.006), (.24, .050, .060, -.002),
             (.20, .060, .070, 0), (.15, .068, .078, 0), (.115, .066, .076, 0)], segs=10, sq=2.2, noise=.003)  # taper + cuff flare
    box(b, (X, -.068, .46), (.08, .025, .09), rot=(.1, 0, 0), bevel=.012, seg=1)                           # knee patch
    # shoe
    b = P(f"foot_{s}")
    Y = [(.115, .105, .062, .040), (.09, .11, .08, .060), (.04, .125, .095, .070), (-.02, .122, .090, .072),
         (-.09, .108, .076, .077), (-.16, .095, .062, .081), (-.22, .082, .048, .072), (-.275, .074, .038, .048)]
    sweep(b, [(X, y, cz, rw, rz) for y, cz, rz, rw in Y], segs=10, sq=2.6)
    for y, z in ((-.03, .22), (-.07, .20), (-.11, .176), (-.15, .152)):
        box(b, (X, y, z), (.05, .011, .009), rot=(0, 0, 0), bevel=.003, seg=1)
    box(b, (X, .115, .205), (.05, .03, .04), bevel=.01, seg=1)                                             # heel pull tab
    t = P(f"sole_{s}", f"foot_{s}", J(f"foot_{s}"))
    Sx = [(.125, .024, .024, .046), (.09, .024, .026, .072), (.0, .026, .026, .082), (-.15, .030, .026, .088), (-.25, .040, .026, .072), (-.295, .048, .022, .042)]
    sweep(t, [(X, y, cz, rw, rz) for y, cz, rz, rw in Sx], segs=8, sq=3.2)
    
# ---------------------------------------------------------------- finish: smooth/sharp, triangulate, AO, objects
mat = bpy.data.materials.new("runner_mat"); mat.use_nodes = True
mat.node_tree.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.85

for d in parts.values():
    bm = d['bm']
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces: f.smooth = True
    for e in bm.edges:
        if len(e.link_faces) == 2 and e.calc_face_angle(0) > math.radians(52): e.smooth = False
    bmesh.ops.triangulate(bm, faces=bm.faces[:])

# ambient occlusion by ray casting against the whole assembled character (rest pose)
allv, allp = [], []
for d in parts.values():
    d['bm'].verts.index_update(); d['bm'].faces.index_update()
    off = len(allv); allv += [v.co.copy() for v in d['bm'].verts]
    allp += [tuple(off + v.index for v in f.verts) for f in d['bm'].faces]
tree = BVHTree.FromPolygons(allv, allp)
N = 40; dirs = []
for i in range(N):
    z = (i + .5) / N; r = math.sqrt(1 - z * z); a = i * 2.39996
    dirs.append((r * math.cos(a), r * math.sin(a), z))
ao = {}
for name, d in parts.items():
    bm = d['bm']; a_ = {}
    for v in bm.verts:
        n = v.normal.normalized() if v.normal.length > 0 else V((0, 0, 1))
        tx = n.cross(V((0, 0, 1)) if abs(n.z) < .9 else V((1, 0, 0))).normalized(); ty = n.cross(tx)
        hit = 0.0
        for dx, dy, dz in dirs:
            dv = tx * dx + ty * dy + n * dz
            loc, nn, idx, dist = tree.ray_cast(v.co + n * 0.003, dv, 0.22)
            if loc is not None: hit += 1 - dist / 0.22 * 0.6
        a_[v.index] = hit / N
    ao[name] = a_
vals = sorted(x for a_ in ao.values() for x in a_.values())
p95 = vals[int(len(vals) * .95)] or 1
def shade(name, vi, v):
    k = min(1.0, ao[name][vi] / p95)
    g = 1.0 - 0.34 * k ** 0.9
    g *= 0.97 + 0.03 * min(1, max(0, (v.co.z - .3) / 1.5))          # slightly lighter toward the top
    if name.startswith("sole_"): g *= 0.80
    if name.startswith("foot_") and v.co.z < .07: g *= .85
    return max(0.6, min(1.0, g))

bpy.ops.wm.read_factory_settings(use_empty=True)
mat = bpy.data.materials.new("runner_mat"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.85
_ca = nt.nodes.new("ShaderNodeVertexColor"); _ca.layer_name = "COLOR_0"
nt.links.new(_ca.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
objs = {}; tot = 0; gs = []
for name, d in parts.items():
    bm = d['bm']; col = bm.loops.layers.color.new("COLOR_0")
    for f in bm.faces:
        for l in f.loops:
            g = shade(name, l.vert.index, l.vert); gs.append(g); h = g ** (1 / 2.2); l[col] = (h, h, h, 1.0)
    bmesh.ops.translate(bm, verts=bm.verts, vec=-d['origin'])
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    me.materials.append(mat)
    ob = bpy.data.objects.new(name, me); bpy.context.collection.objects.link(ob)
    ob.location = d['origin']; objs[name] = ob; tot += len(me.polygons)
for name, d in parts.items():
    if d['parent']:
        ob = objs[name]; ob.parent = objs[d['parent']]; ob.matrix_parent_inverse = Matrix.Identity(4)
        ob.location = (0, 0, 0)
print('ATTRS', [a.name for a in objs['torso'].data.color_attributes]); print("TRIS", tot, "AO mean", sum(gs) / len(gs), "min", min(gs))

dst = os.path.join(OUT, "runner.glb"); bak = os.path.join(OUT, "runner_old.glb")
if os.path.exists(dst) and not os.path.exists(bak): shutil.copy(dst, bak)
for o in bpy.context.scene.objects: o.select_set(True)
try: bpy.ops.export_scene.gltf(filepath=dst, export_format='GLB', use_selection=True, export_yup=True, export_apply=True, export_vertex_color='MATERIAL', export_all_vertex_colors=False)
except TypeError: bpy.ops.export_scene.gltf(filepath=dst, export_format='GLB', use_selection=True, export_yup=True, export_apply=True)
print("WROTE", dst)
