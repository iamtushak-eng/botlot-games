import puppeteer from 'puppeteer-core';
const mode = process.argv[2];
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 640, height: 400 });
p.on('pageerror', e => console.log('ERR', String(e.stack).slice(0, 400)));
await p.goto('http://localhost:8123/index.html'); await new Promise(r => setTimeout(r, 3000));
await p.evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.includes('Begin today')).click());
await new Promise(r => setTimeout(r, 300));
await p.evaluate((m) => document.querySelector(`.mode[data-mode="${m}"]`).click(), mode);
await p.keyboard.down('KeyW');
for (let i = 0; i < 8; i++) { await new Promise(r => setTimeout(r, 3000)); console.log(await p.evaluate(() => { const g = window.__deadline.game; if (!g) return 'game ended'; const c = g.world.chars[0]; return JSON.stringify({ st: g.run.state, cd: g.run.count, z: +c.pos[2].toFixed(1), v: +Math.hypot(c.vel[0], c.vel[2]).toFixed(1), s: c.state, t: +g.run.timeLeft.toFixed(1) }); })); }
await b.close();
