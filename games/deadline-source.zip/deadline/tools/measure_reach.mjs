// Solvability + calibration: can a competent scripted player finish every day's course, in every mode?
import { generateLevel } from '../src/game/levelgen.js';
import { simulate } from '../src/game/sim.js';
const N = +(process.argv[2] || 20), modes = process.argv[3] ? [process.argv[3]] : ['precision', 'momentum', 'ragdoll', 'board', 'bike'];
const day = (i) => new Date(Date.UTC(2026, 10, 1 + i)).toISOString().slice(0, 10);
for (const mode of modes) {
  let ok = 0, tsum = 0; const fails = [];
  const t0 = Date.now();
  for (let i = 0; i < N; i++) {
    const d = day(i), L = generateLevel(d, mode), r = simulate(L, mode);
    if (r.status === 'finished') { ok++; tsum += r.time; } else fails.push(`${d}(${L.themeId}) ${r.status}/${r.cause} at ${(r.progress * 100).toFixed(0)}% z=${r.pos[2].toFixed(0)} y=${r.pos[1].toFixed(1)}`);
  }
  console.log(`${mode}: ${ok}/${N} finished, avg time ${(tsum / Math.max(1, ok)).toFixed(1)}s, ${((Date.now() - t0) / N).toFixed(0)}ms/run`);
  fails.slice(0, 8).forEach(f => console.log('   FAIL', f));
}
