import { Synth } from '../node_modules/beepbox/esm/synth/index.js';
export function render(hash, mutedSet = []) {
  const sr = 44100, s = new Synth(hash); s.samplesPerSecond = sr; s.loopRepeatCount = 0; s.snapToStart();
  s.song.channels.forEach((c, i) => { c.muted = mutedSet.includes(i); });
  const secs = 16 * 60 / s.song.tempo / 2 * 2; const n = Math.floor(sr * (60 / s.song.tempo) * 4 * s.song.barCount);
  const L = new Float32Array(n), R = new Float32Array(n); s.isPlayingSong = true; s.synthesize(L, R, n, true); return { L, sr, n, tempo: s.song.tempo, bars: s.song.barCount, nch: s.song.channels.length };
}
const rms = (a) => Math.sqrt(a.reduce((q, v) => q + v * v, 0) / a.length);
if (process.argv[2]) {
  const h = process.argv[2]; const all = render(h); console.log({ tempo: all.tempo, bars: all.bars, channels: all.nch, mixPeak: all.L.reduce((m, v) => Math.max(m, Math.abs(v)), 0).toFixed(3), mixRms: rms(all.L).toFixed(4) });
  for (let c = 0; c < all.nch; c++) { const only = render(h, [...Array(all.nch).keys()].filter(i => i !== c)); const peak = only.L.reduce((m, v) => Math.max(m, Math.abs(v)), 0); const hitsPerSec = (() => { let on = 0, last = 0; const w = 441; for (let i = 0; i < only.n; i += w) { let q = 0; for (let k = 0; k < w && i + k < only.n; k++) q += only.L[i + k] ** 2; const e = Math.sqrt(q / w); if (e > 0.01 && last <= 0.01) on++; last = e; } return (on / (only.n / only.sr)).toFixed(2); })(); console.log('ch' + c, 'rms', rms(only.L).toFixed(4), 'peak', peak.toFixed(3), 'onsets/s', hitsPerSec); }
}
