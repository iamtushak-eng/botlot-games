import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 480, height: 300 });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
await p.goto('http://localhost:8123/index.html' + (process.argv[2] || '')); await sleep(3500);
await p.evaluate(() => document.querySelector('#begin').click());
for (let i = 0; i < 5; i++) { await sleep(4000); console.log(await p.evaluate(async () => { let n = 0; const t0 = performance.now(); await new Promise(r => { const f = () => { n++; performance.now() - t0 < 2000 ? requestAnimationFrame(f) : r(); }; requestAnimationFrame(f); }); const g = window.__deadline.game; return JSON.stringify({ fps: n / 2, cd: g?.run.count, st: g?.run.state }); })); }
await b.close();
