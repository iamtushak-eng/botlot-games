import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { makeRunner } from '../src/game/runner.js';
const W = 1500, H = 520, r = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true }); r.setSize(W, H); r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping; document.body.appendChild(r.domElement);
const sc = new THREE.Scene(); sc.background = new THREE.Color('#9aa3a6'); sc.add(new THREE.HemisphereLight('#dfe8ee', '#6b5a48', 1.2));
const sun = new THREE.DirectionalLight('#fff1d6', 2.6); sun.position.set(3, 5, 4); sc.add(sun);
const ld = new GLTFLoader(), models = {};
for (const n of ['runner', 'veh_board', 'veh_bike', 'veh_skates']) models[n] = (await ld.loadAsync('/assets/models/' + n + '.glb')).scene;
const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ color: '#b9b3a6' })); floor.rotation.x = -Math.PI / 2; sc.add(floor);
const cases = [['board', 'run', 4, 0], ['board', 'run', 12, 20], ['skates', 'run', 6, 0], ['skates', 'run', 6, 40], ['skates', 'jump', 12, 0], ['bike', 'run', 12, 0], ['bike', 'run', 12, 25]];
cases.forEach(([kind, st, sp, extra], i) => {
  const R = makeRunner(models.runner, { veh: { kind, models } }); R.root.position.set(i * 1.9 - 1.5, 0, 0); sc.add(R.root); R.setHeading(Math.PI / 2);
  for (let k = 0; k < 160 + extra; k++) R.update(st, sp, [sp, st === 'jump' ? 3 : 0, 0], 0.016, 0);
});
const cam = new THREE.PerspectiveCamera(32, W / H, 0.1, 80); cam.position.set(4, 1.2, 7.5); cam.lookAt(3, 0.8, 0); r.render(sc, cam); window.__done = true;
