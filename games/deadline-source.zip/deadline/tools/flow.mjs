import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 1000, height: 600 });
p.on('pageerror', e => console.log('ERR', String(e.stack).slice(0, 500))); p.on('console', m => m.type() === 'error' && console.log('CERR', m.text().slice(0, 300)));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const click = (sel) => p.evaluate((sel) => { const e = document.querySelector(sel); if (e) e.click(); return !!e; }, sel);
const btn = (t) => p.evaluate((t) => { const e = [...document.querySelectorAll('button')].find(b => b.textContent.includes(t) && b.offsetParent); if (e) e.click(); return !!e; }, t);
await p.goto('http://localhost:8123/index.html'); await sleep(3000);
await btn('Begin today'); await sleep(300); await click('.mode[data-mode="precision"]');
await p.keyboard.down('KeyW'); await sleep(32000); await p.screenshot({ path: '/tmp/f_death.png' });
console.log('active screen:', await p.evaluate(() => document.querySelector('.screen.active')?.id));
// continue → social
await btn('See the card').then(x => console.log('continue', x)); await sleep(500); await p.screenshot({ path: '/tmp/f_after.png' });
console.log('active screen:', await p.evaluate(() => document.querySelector('.screen.active')?.id));
for (const t of ['Yesterday', 'Markers', 'Ghost']) { await sleep(300); const ok = await btn(t); console.log('click', t, ok, await p.evaluate(() => document.querySelector('.screen.active')?.id)); }
await p.screenshot({ path: '/tmp/f_social.png' });
await btn('Precision'); await sleep(14000); await p.screenshot({ path: '/tmp/f_practice.png' });
console.log('practice state', await p.evaluate(() => { const g = window.__deadline.game; return g ? [g.run.state, g.run.practice] : null; }));
console.log('buttons:', await p.evaluate(() => [...document.querySelectorAll('.screen.active button')].map(b => b.textContent.trim().slice(0, 30))));
await b.close();
