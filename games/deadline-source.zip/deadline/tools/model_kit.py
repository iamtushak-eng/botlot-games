import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lowpoly import *
import math
P = {}
def piece(name):
    def d(fn): P[name] = fn; return fn
    return d
@piece("building_block")
def _(b):
    b.box((4,4,3),(0,0,1.5),'brick',bevel=0.06); b.box((4.3,4.3,0.25),(0,0,3.1),'concrete')
    for x in (-1.1,1.1):
        for z in (0.9,2.1): b.box((0.9,0.1,0.8),(x,-2.02,z),'dark',bevel=0.02); b.box((1.0,0.08,0.1),(x,-2.06,z-0.45),'concrete_d')
    b.box((0.8,0.12,1.5),(0,2.03,0.75),'concrete_d')
@piece("ledge")
def _(b):
    b.box((3,0.6,0.25),(0,0,0),'concrete',bevel=0.05)
    for x in (-1.1,1.1): b.box((0.2,0.45,0.5),(x,0.1,-0.35),'metal_d')
@piece("pipe")
def _(b):
    b.cyl(0.18,4,(0,0,0.18),'metal',rot=(0,math.pi/2,0),seg=10)
    for x in (-1.5,0,1.5): b.cyl(0.23,0.12,(x,0,0.18),'metal_d',rot=(0,math.pi/2,0),seg=10)
    b.box((0.3,0.1,0.1),(1.7,0,0.5),'rust')
@piece("crate")
def _(b):
    b.box((1,1,1),(0,0,0.5),'wood',bevel=0.04)
    for z in (0.06,0.94): b.box((1.04,1.04,0.12),(0,0,z),'wood_d')
    for x in (-0.46,0.46):
        for y in (-0.46,0.46): b.box((0.1,0.1,1.02),(x,y,0.5),'wood_d')
    b.box((0.08,1.05,0.1),(0,0,0.5),'wood_d',rot=(0,0.8,0))
@piece("vent")
def _(b):
    b.box((1.2,0.6,0.9),(0,0,0.45),'metal',bevel=0.04)
    for i in range(5): b.box((0.9,0.05,0.07),(0,-0.31,0.2+i*0.14),'metal_d',rot=(0.3,0,0))
    b.cyl(0.25,0.1,(0,0.35,0.5),'dark',rot=(math.pi/2,0,0),seg=10)
    b.box((1.3,0.7,0.08),(0,0,0.92),'metal_d')
@piece("antenna")
def _(b):
    b.box((0.6,0.6,0.15),(0,0,0.07),'concrete_d'); b.cyl(0.05,3.5,(0,0,1.9),'metal',seg=6)
    for z,w in ((1.5,0.9),(2.1,0.7),(2.7,0.5)): b.box((w,0.05,0.05),(0,0,z),'metal_d')
    b.cyl(0.07,0.12,(0,0,3.7),'red',seg=6)
    b.box((0.04,0.04,1.6),(0.3,0,0.9),'metal_d',rot=(0,0.35,0))
@piece("billboard_frame")
def _(b):
    for x in (-1.6,1.6): b.box((0.2,0.2,3),(x,0,1.5),'metal_d')
    b.box((3.8,0.2,0.15),(0,0,2.3),'metal'); b.box((3.8,0.2,0.15),(0,0,3.85),'metal')
    for x in (-1.9,1.9): b.box((0.15,0.2,1.7),(x,0,3.08),'metal')
    b.box((3.5,0.06,1.4),(0,0.08,3.08),'white'); b.box((3.5,0.3,0.1),(0,0.1,0.05),'concrete_d')
    b.box((0.1,0.5,0.1),(0,-0.3,3.95),'metal_d',rot=(0.3,0,0))
@piece("rope_hook")
def _(b):
    b.box((0.2,0.2,1.2),(0,0,0.6),'metal_d'); b.box((0.6,0.2,0.2),(0.2,0,1.3),'metal_d')
    b.box((0.25,0.2,0.2),(0.5,0,1.15),'metal',rot=(0,-0.8,0)); b.box((0.25,0.2,0.2),(0.4,0,0.95),'metal',rot=(0,0.8,0))
    b.cyl(0.05,0.6,(0.55,0,0.65),'wood',rot=(0,0,0),seg=6)
    b.box((0.5,0.5,0.1),(0,0,0.05),'concrete_d')
@piece("plank")
def _(b):
    b.box((3,0.4,0.08),(0,0,0),'wood',bevel=0.02)
    for x in (-1.3,1.3):
        for y in (-0.12,0.12): b.cyl(0.035,0.03,(x,y,0.05),'metal_d',seg=6,bevel=0)
    b.box((0.03,0.4,0.09),(0.4,0,0),'wood_d')
@piece("crumbling_slab")
def _(b):
    r = random.Random(7)
    for i in range(3):
        for j in range(2):
            h = 0.28 - r.uniform(0,0.06)
            b.box((0.95,0.95,h),(-1+i*1.0,-0.5+j*1.0,0),'concrete' if (i+j)%2 else 'concrete_d',rot=(r.uniform(-.05,.05),r.uniform(-.05,.05),r.uniform(-.08,.08)),bevel=0.05)
    b.box((0.2,0.2,0.1),(1.5,0.9,-0.3),'concrete_d',rot=(0.4,0.3,0.2))
@piece("spike_strip")
def _(b):
    b.box((3,0.6,0.12),(0,0,0.06),'metal_d',bevel=0.02)
    for i in range(6):
        for y in (-0.15,0.15): b.cyl(0.1,0.4,(-1.25+i*0.5,y,0.32),'metal',seg=4,r2=0.0)
@piece("saw_blade")
def _(b):
    b.cyl(0.55,0.06,(0,0,0),'metal',rot=(math.pi/2,0,0),seg=12,bevel=0.01)
    for i in range(10):
        a=i*math.pi/5; b.box((0.18,0.05,0.12),(math.cos(a)*0.6,0,math.sin(a)*0.6),'metal',rot=(0,-a+0.5,0),bevel=0.005)
    b.cyl(0.14,0.12,(0,0,0),'red',rot=(math.pi/2,0,0),seg=8); b.cyl(0.05,0.2,(0,0,0),'dark',rot=(math.pi/2,0,0),seg=6)
@piece("goal_gate")
def _(b):
    for x in (-1.3,1.3): b.box((0.3,0.3,3.2),(x,0,1.6),'yellow'); b.box((0.5,0.5,0.15),(x,0,0.07),'concrete_d')
    b.box((3.2,0.35,0.4),(0,0,3.3),'yellow'); b.box((2.4,0.1,0.6),(0,-0.2,3.3),'dark')
    for i in range(6): b.box((0.2,0.12,0.2),(-1.0+i*0.4,-0.27,3.3),'white' if i%2 else 'red',bevel=0.01)
@piece("checkpoint_flag")
def _(b):
    b.cyl(0.05,2.6,(0,0,1.3),'metal',seg=6); b.cyl(0.4,0.1,(0,0,0.05),'concrete_d',seg=8)
    b.box((0.9,0.04,0.6),(0.5,0,2.2),'scarf',rot=(0,0,0),bevel=0.01); b.box((0.3,0.045,0.6),(0.1+0.05,0,2.2),'white',bevel=0.005)
    b.box((0.4,0.04,0.3),(1.1,0,2.2),'scarf',rot=(0,0.15,0),bevel=0.01); b.cyl(0.08,0.12,(0,0,2.65),'yellow',seg=6)
files = []
for i,(n,fn) in enumerate(P.items()):
    reset(); mat = material(); b = Builder(1000+i); fn(b)
    ob = b.build(n, (0,0,0), mat)
    files.append(export(f"kit_{n}.glb", [ob]))
r = json.load(open("/tmp/runner_manifest.json"))
json.dump(dict(up_axis="Y", units="meters", vertex_colors="COLOR_0", files=[r]+files), open(os.path.join(OUT,"manifest.json"),"w"), indent=1)
for f in [r]+files: print(f['file'], f['total_triangles'])
