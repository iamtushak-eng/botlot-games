import puppeteer from 'puppeteer-core';
const mode = process.argv[2] || 'precision', look = process.argv[3] || 'lowpoly', fp = process.argv[4] === 'fp';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 1000, height: 600 });
const logs = []; p.on('console', m => { if (m.type() !== 'warn') logs.push(m.type() + ': ' + m.text().slice(0, 300)); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + String(e.stack).slice(0, 700)));
await p.evaluateOnNewDocument((look, fp) => { localStorage.clear(); localStorage.setItem('deadline.settings', JSON.stringify({ look, camera: fp ? 'first' : 'third' })); }, look, fp);
await p.goto('http://localhost:8123/index.html'); await new Promise(r => setTimeout(r, 4000));
const clickText = (t) => p.evaluate((t) => { const e = [...document.querySelectorAll('button')].find(b => b.textContent.includes(t) && b.offsetParent); if (e) e.click(); return !!e; }, t);
console.log('begin', await p.evaluate((m) => { const e = document.querySelector('[data-start="' + m + '"]'); if (e) e.click(); return !!e; }, mode)); await new Promise(r => setTimeout(r, 400));

await new Promise(r => setTimeout(r, 1500)); await p.screenshot({ path: `/tmp/g_${mode}_cd.png` });
await new Promise(r => setTimeout(r, 2500));
await p.keyboard.down('KeyW');
for (let i = 0; i < 6; i++) { await new Promise(r => setTimeout(r, 1500)); await p.keyboard.press('Space'); }
await p.screenshot({ path: `/tmp/g_${mode}_${look}${fp ? '_fp' : ''}.png` });
const st = await p.evaluate(() => { const g = window.__deadline?.game; return g ? { state: g.run.state, z: g.world.chars[0]?.pos, prog: g.run.progress, t: g.run.timeLeft } : null; });
console.log(JSON.stringify(st)); console.log(logs.slice(0, 12).join('\n')); await b.close();
