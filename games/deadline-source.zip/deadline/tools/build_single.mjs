// One self-contained index.html: JS, CSS, models (base64) and art (data URIs) all inline.
import { build } from 'esbuild';
import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..'), out = path.join(root, 'dist-single');
fs.mkdirSync(out, { recursive: true });
const r = await build({ entryPoints: [path.join(root, 'src/app.js')], bundle: true, format: 'iife', minify: true, target: 'es2022', write: false, logLevel: 'warning' });
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const models = {}; for (const f of fs.readdirSync(path.join(root, 'assets/models'))) if (f.endsWith('.glb') && !f.includes('_old') && !/runner_v\d/.test(f)) models[f.slice(0, -4)] = fs.readFileSync(path.join(root, 'assets/models', f)).toString('base64');
let html = fs.readFileSync(path.join(root, 'src/ui/index.html'), 'utf8');
const mime = { jpg: 'image/jpeg', png: 'image/png', svg: 'image/svg+xml' };
const uri = (rel) => { const f = path.join(root, rel); return `data:${mime[f.split('.').pop()]};base64,${fs.readFileSync(f).toString('base64')}`; };
const css = fs.readFileSync(path.join(root, 'src/ui/ui.css'), 'utf8').replace(/url\((assets\/art\/[\w-]+\.(?:jpg|png|svg))\)/g, (_, r) => `url(${uri(r)})`);
html = html.replace(/src="(assets\/art\/[\w-]+\.(?:jpg|png|svg))"/g, (_, r) => `src="${uri(r)}"`);
html = html.replace(/href="assets\/art\/([\w-]+)\.svg"/g, (_, n) => `href="data:image/svg+xml;base64,${fs.readFileSync(path.join(root, 'assets/art', n + '.svg')).toString('base64')}"`);
html = html.replace('<link rel="stylesheet" href="ui.css">', () => `<style>${css}</style>`);
html = html.replace('<script src="app.js" type="module"></script>', () => `<script>window.__DEADLINE_MODELS=${JSON.stringify(models)};window.__DEADLINE_MUSIC="${fs.readFileSync(path.join(root, 'assets/music/score.mp3')).toString('base64')}";</script>\n<script>${js}</script>`);
fs.writeFileSync(path.join(out, 'index.html'), html);
console.log('index.html', (html.length / 1048576).toFixed(2) + ' MB', 'external refs left:', (html.match(/(?:src|href)="(?!data:|#|http)[^"]+"/g) || []));
