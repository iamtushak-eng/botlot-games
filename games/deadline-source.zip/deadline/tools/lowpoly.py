import bpy, bmesh, random, json, os
from mathutils import Matrix, Euler, Vector

OUT = "/home/claude/deadline/assets/models"
def hexc(h):
    h = h.lstrip('#'); r, g, b = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
    f = lambda c: c ** 2.2
    return (f(r), f(g), f(b), 1.0)

PAL = {k: hexc(v) for k, v in dict(
    skin='e8b48c', jacket='e8742c', jacket_d='b5521c', pants='2b3040', shoe='15171d', scarf='1fb5a8',
    concrete='9a9a94', concrete_d='6c6c68', brick='a4553f', metal='7d8791', metal_d='4b535c',
    wood='b98a54', wood_d='7d5a33', rust='9c4a24', dark='1b1d22', yellow='e8c32c', red='c9323a',
    white='e9e6dc', glow='5ad1ff').items()}

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)

class Builder:
    def __init__(self, seed, jitter=0.012):
        self.bm = bmesh.new(); self.rng = random.Random(seed); self.j = jitter
        self.col = self.bm.loops.layers.color.new("Col")
    def _finish(self, before, color, mat, bevel, jit=True):
        bm = self.bm
        new = [f for f in bm.faces if f not in before]
        verts = {v for f in new for v in f.verts}
        for v in verts: v.co = mat @ v.co
        if bevel:
            edges = list({e for f in new for e in f.edges})
            bmesh.ops.bevel(bm, geom=edges, offset=bevel, segments=1, affect='EDGES')
        new = [f for f in bm.faces if f not in before]
        if jit and self.j:
            for v in {v for f in new for v in f.verts}:
                v.co += Vector([self.rng.uniform(-self.j, self.j) for _ in range(3)])
        c = PAL[color] if isinstance(color, str) else color
        for f in new:
            for l in f.loops: l[self.col] = c
    def box(self, size, center, color, rot=(0,0,0), bevel=0.025, jit=True):
        before = set(self.bm.faces)
        bmesh.ops.create_cube(self.bm, size=1.0)
        S = Matrix.Diagonal((*size, 1.0))
        m = Matrix.Translation(center) @ Euler(rot).to_matrix().to_4x4() @ S
        self._finish(before, color, m, min(bevel, min(size) * 0.3), jit)
    def cyl(self, r, h, center, color, rot=(0,0,0), seg=8, bevel=0.015, r2=None):
        before = set(self.bm.faces)
        bmesh.ops.create_cone(self.bm, cap_ends=True, cap_tris=False, segments=seg,
                              radius1=r, radius2=r if r2 is None else r2, depth=h)
        m = Matrix.Translation(center) @ Euler(rot).to_matrix().to_4x4()
        self._finish(before, color, m, bevel if r2 is None else 0)
    def build(self, name, origin=(0,0,0), mat=None):
        bm = self.bm
        bmesh.ops.triangulate(bm, faces=bm.faces[:])
        bmesh.ops.translate(bm, verts=bm.verts, vec=-Vector(origin))
        me = bpy.data.meshes.new(name + "_mesh"); bm.to_mesh(me); bm.free()
        me.shade_flat()
        if mat: me.materials.append(mat)
        ob = bpy.data.objects.new(name, me); bpy.context.collection.objects.link(ob)
        ob.location = origin
        return ob

def material():
    m = bpy.data.materials.new("vertex_color_mat"); m.use_nodes = True
    b = m.node_tree.nodes.get("Principled BSDF")
    b.inputs["Base Color"].default_value = (1,1,1,1); b.inputs["Roughness"].default_value = 0.9
    return m

def tris(ob):
    ob.data.calc_loop_triangles(); return len(ob.data.loop_triangles)

def export(fname, objs):
    for o in bpy.context.scene.objects: o.select_set(False)
    for o in objs: o.select_set(True)
    kw = dict(filepath=os.path.join(OUT, fname), export_format='GLB', use_selection=True, export_yup=True,
              export_apply=True)
    try: bpy.ops.export_scene.gltf(export_vertex_color='ACTIVE', **kw)
    except TypeError: bpy.ops.export_scene.gltf(**kw)
    return dict(file=fname, objects=[dict(name=o.name, triangles=tris(o)) for o in objs],
                total_triangles=sum(tris(o) for o in objs))
