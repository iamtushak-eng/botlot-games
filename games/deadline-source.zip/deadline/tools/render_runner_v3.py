"""Clay/dressed turnaround renders of runner.glb. usage: python3 render_runner_v3.py in.glb prefix"""
import bpy, sys, math
from mathutils import Vector as V
src, pre = sys.argv[1], sys.argv[2]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=src)
WEAR = {'jacket': '#66705f', 'pants': '#3d414c', 'shoe': '#e4dfd2', 'skin': '#c28f6c', 'scarf': '#d8452a', 'glove': '#1f2023', 'sole': '#b8b2a2', 'pack': '#8a5a2e', 'beanie': '#d8452a'}
PW = {'torso': 'jacket', 'head': 'skin', 'scarf': 'scarf', 'pelvis': 'pants'}
def wear(n):
    if n.startswith('upper_arm') or n.startswith('lower_arm'): return 'jacket'
    if n.startswith('hand'): return 'glove'
    if 'leg' in n: return 'pants'
    if n.startswith('foot'): return 'shoe'
    if n.startswith('sole'): return 'sole'
    if n.startswith('pack'): return 'pack'
    if n.startswith('trim_'): return 'beanie' if 'beanie' in n else 'scarf' if 'wrap' in n else 'jacket'
    return PW.get(n)
def hexc(h): return tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
for o in bpy.data.objects:
    if o.type != 'MESH': continue
    w = wear(o.name.split('.')[0]); m = bpy.data.materials.new(o.name); m.use_nodes = True
    nt = m.node_tree; bsdf = nt.nodes['Principled BSDF']; bsdf.inputs['Roughness'].default_value = .8
    vc = nt.nodes.new('ShaderNodeVertexColor'); vc.layer_name = (o.data.color_attributes[0].name if o.data.color_attributes else 'COLOR_0')
    mix = nt.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.blend_type = 'MULTIPLY'; mix.inputs[0].default_value = 1
    c = [x ** 2.2 for x in hexc(WEAR[w])] if w else (.5, .5, .5)
    mix.inputs[6].default_value = (*c, 1); nt.links.new(vc.outputs['Color'], mix.inputs[7]); nt.links.new(mix.outputs[2], bsdf.inputs['Base Color'])
    o.data.materials.clear(); o.data.materials.append(m)
sc = bpy.context.scene; sc.render.engine = 'CYCLES'; sc.cycles.samples = 24; sc.cycles.device = 'CPU'
sc.cycles.use_denoising = False
sc.render.resolution_x, sc.render.resolution_y = 600, 800
w = bpy.data.worlds.new('w'); sc.world = w; w.use_nodes = True; w.node_tree.nodes['Background'].inputs[0].default_value = (.55, .58, .62, 1); w.node_tree.nodes['Background'].inputs[1].default_value = 1.0
sun = bpy.data.objects.new('sun', bpy.data.lights.new('sun', 'SUN')); sun.data.energy = 3.5; sun.rotation_euler = (math.radians(50), 0, math.radians(35)); sc.collection.objects.link(sun)
bpy.ops.mesh.primitive_plane_add(size=6); bpy.context.object.data.materials.append(bpy.data.materials.new('g')); 
cam = bpy.data.objects.new('cam', bpy.data.cameras.new('cam')); sc.collection.objects.link(cam); sc.camera = cam
def shot(name, loc, tgt, lens=70):
    cam.location = loc; cam.data.lens = lens
    d = V(tgt) - V(loc); cam.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = f'/tmp/runner3_{pre}_{name}.png'; bpy.ops.render.render(write_still=True)
# glTF import: Y-up converted to Blender Z-up, character faces -Y
D = 5.5
shot('front', (0, -D, .9), (0, 0, .9)); shot('side', (D, 0, .9), (0, 0, .9)); shot('back', (0, D, .9), (0, 0, .9))
shot('q34', (D * .7, -D * .7, 1.1), (0, 0, .9))
shot('head', (.8, -1.4, 1.6), (0, 0, 1.55), lens=85)
shot('hand', (.9, -1.0, .75), (.3, -.1, .55), lens=70)
shot('shoe', (.6, -.9, .3), (.1, -.05, .1), lens=70)
