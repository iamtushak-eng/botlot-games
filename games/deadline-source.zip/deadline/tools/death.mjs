import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 480, height: 300 });
const logs = []; p.on('pageerror', e => logs.push('PAGEERR ' + String(e.stack).slice(0, 400))); p.on('console', m => m.type() === 'error' && logs.push(m.text().slice(0, 200)));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
await p.goto('http://localhost:8123/index.html'); await sleep(3500);
await p.evaluate(() => document.querySelector('#begin').click());
await sleep(34000);
const info = await p.evaluate(() => { const g = window.__deadline.game, c = g.world.chars[0], h = g.level.hazards.find(h => !h.move) || g.level.hazards[0]; if (!h) return 'no hazard'; c.pos[0] = h.pos[0]; c.pos[1] = h.pos[1]; c.pos[2] = h.pos[2] - 3; c.vel[2] = 10; g.world.chars[0].setInput({ moveZ: 1, moveX: 0, jump: false, jumpHeld: false, slide: false, grab: false, yaw: 0 }); return JSON.stringify({ h: h.pos, state: g.run.state }); });
console.log(info);
for (let i = 0; i < 4; i++) { await sleep(1800); await p.screenshot({ path: `/tmp/d${i}.png` }); console.log(await p.evaluate(() => { const g = window.__deadline.game; return g ? g.run.state + ' ' + (g.run.cause || '') : 'ended'; })); }
console.log(logs.join('\n') || 'no errors'); await b.close();
