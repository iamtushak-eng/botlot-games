// Bundle the game into dist/ (static files: drop on any host, or open via any local web server).
import { build } from 'esbuild';
import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..'), dist = path.join(root, 'dist');
fs.rmSync(dist, { recursive: true, force: true }); fs.mkdirSync(dist, { recursive: true });
await build({ entryPoints: [path.join(root, 'src/app.js')], bundle: true, format: 'esm', outfile: path.join(dist, 'app.js'), minify: !process.env.DEBUG, target: 'es2022', logLevel: 'info' });
fs.copyFileSync(path.join(root, 'src/ui/index.html'), path.join(dist, 'index.html'));
fs.copyFileSync(path.join(root, 'src/ui/ui.css'), path.join(dist, 'ui.css'));
fs.cpSync(path.join(root, 'assets/models'), path.join(dist, 'assets/models'), { recursive: true });
fs.cpSync(path.join(root, 'assets/music'), path.join(dist, 'assets/music'), { recursive: true });
fs.mkdirSync(path.join(dist, 'assets/art'), { recursive: true });
for (const f of fs.readdirSync(path.join(root, 'assets/art'))) if (/\.(svg|jpg|png)$/.test(f) && !f.startsWith('theme-')) fs.copyFileSync(path.join(root, 'assets/art', f), path.join(dist, 'assets/art', f));
console.log('built', fs.readdirSync(dist));
