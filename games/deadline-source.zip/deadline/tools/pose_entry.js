import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { makeRunner } from '../src/game/runner.js';
const W = 1500, H = 560, r = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true }); r.setSize(W, H); r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping; document.body.appendChild(r.domElement);
const sc = new THREE.Scene(); sc.background = new THREE.Color('#9aa3a6'); sc.add(new THREE.HemisphereLight('#dfe8ee', '#6b5a48', 1.2));
const sun = new THREE.DirectionalLight('#fff1d6', 2.6); sun.position.set(3, 5, 4); sc.add(sun);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshStandardMaterial({ color: '#b9b3a6' })); floor.rotation.x = -Math.PI / 2; sc.add(floor);
const gl = await new GLTFLoader().loadAsync('/assets/models/runner.glb'); const speed = +(new URLSearchParams(location.search).get('v') || 9);
// 8 frames across ONE gait cycle at the given speed, in a row (side view)
const hz = Math.min(2.6, 0.95 + 0.115 * speed), steps = 8;
for (let i = 0; i < steps; i++) {
  const R = makeRunner(gl.scene); R.root.position.set((i - 3.5) * 1.1, 0, 0); sc.add(R.root); R.setHeading(Math.PI / 2);
  const dt = 1 / 120, n = Math.round(240 + (i / steps) / hz / dt);
  for (let k = 0; k < n; k++) R.update('run', speed, [speed, 0, 0], dt, 0);
}
const cam = new THREE.PerspectiveCamera(30, W / H, 0.1, 80); cam.position.set(0, 0.95, 11); cam.lookAt(0, 0.85, 0); r.render(sc, cam); window.__done = true;
