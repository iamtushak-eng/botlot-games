import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--autoplay-policy=no-user-gesture-required','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); const logs = [];
p.on('console', m => ['error','warning'].includes(m.type()) && !/GL Driver|flatShading/.test(m.text()) && logs.push(m.type() + ' ' + m.text().slice(0, 200))); p.on('pageerror', e => logs.push('PAGEERR ' + String(e.stack).slice(0, 300)));
await p.goto('http://localhost:8123/index.html'); await new Promise(r => setTimeout(r, 4000));
await p.evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.includes('Begin today')).click());
await new Promise(r => setTimeout(r, 300)); await p.evaluate(() => document.querySelector('.mode[data-mode="momentum"]').click());
await new Promise(r => setTimeout(r, 5000));
console.log(await p.evaluate(() => { const g = window.__deadline.game; return g ? 'game ok ' + g.run.state : 'no game'; })); console.log(logs.join('\n') || 'no errors'); await b.close();
