import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 1500, height: 500 }); const logs = []; p.on('pageerror', e => logs.push(String(e).slice(0, 300))); p.on('console', m => m.type() === 'error' && logs.push(m.text().slice(0, 200)));
await p.goto('http://localhost:8123/pose.html?v=9'); await new Promise(r => setTimeout(r, 6000)); await p.screenshot({ path: process.argv[2] || '/tmp/pose.png' }); console.log(logs.join('\n') || 'ok'); await b.close();
