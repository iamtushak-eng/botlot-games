"""Deadline runner v3: organic athletic runner. Run: python3 tools/model_runner_v3.py
Blender Z-up -> glTF Y-up. Faces Blender -Y (glTF +Z). L = -X. Same node contract / joints as v2.
Lofted anatomical profiles (Catmull-Rom resampled), clothing as inflated shells, surface-conforming details
(ray cast onto torso), ray-cast AO into greyscale COLOR_0."""
import bpy, bmesh, math, os, shutil, random
from mathutils import Vector as V, Matrix, Euler
from mathutils.bvhtree import BVHTree

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "assets/models")
rng = random.Random(11)
SEGS = int(os.environ.get("SEGS", "10"))

def G(x, mu, s): return math.exp(-((x - mu) / s) ** 2 / 2)

# ------------------------------------------------------------ loft
def _cr(p0, p1, p2, p3, t):
    return tuple(0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t ** 3)
                 for a, b, c, d in zip(p0, p1, p2, p3))

def interp(keys, sub):
    if sub <= 1: return [tuple(k) for k in keys]
    out = []; n = len(keys)
    for i in range(n - 1):
        for s in range(sub):
            out.append(_cr(keys[max(i - 1, 0)], keys[i], keys[i + 1], keys[min(i + 2, n - 1)], s / sub))
    out.append(tuple(keys[-1])); return out

def loft(bm, keys, segs=None, sub=2, sq=2.2, w=(1, 0, 0), mod=None, cap=True, noise=0.0, capend=True):
    """keys: (cx,cy,cz,rw,rt[,nx,ny,nz]). rw along width axis, rt along normal axis."""
    segs = segs or SEGS
    ks = interp(keys, sub); cs = [V(k[:3]) for k in ks]; wv = V(w); rings = []
    for i, k in enumerate(ks):
        t = (cs[min(i + 1, len(cs) - 1)] - cs[max(i - 1, 0)]).normalized()
        if len(k) >= 8 and V(k[5:8]).length > 1e-6:
            n = V(k[5:8]); n = (n - t * n.dot(t)).normalized(); ww = n.cross(t)
        else:
            ww = (wv - t * wv.dot(t)).normalized(); n = t.cross(ww)
        ring = []
        for j in range(segs):
            a = 2 * math.pi * j / segs; c, s = math.cos(a), math.sin(a); p = 2.0 / sq
            c = math.copysign(abs(c) ** p, c); s = math.copysign(abs(s) ** p, s)
            f = 1.0 + (rng.uniform(-noise, noise) if noise else 0)
            if mod: f *= mod(cs[i], a)
            ring.append(bm.verts.new(cs[i] + ww * (k[3] * c * f) + n * (k[4] * s * f)))
        rings.append(ring)
    for i in range(len(rings) - 1):
        for j in range(segs):
            bm.faces.new((rings[i][j], rings[i][(j + 1) % segs], rings[i + 1][(j + 1) % segs], rings[i + 1][j]))
    if cap:
        bm.faces.new(rings[0])
        if capend: bm.faces.new(rings[-1][::-1])
    return rings

def _xf(verts, center, size, rot):
    m = Matrix.Translation(center) @ Euler(rot).to_matrix().to_4x4() @ Matrix.Diagonal((*size, 1))
    for v in verts: v.co = m @ v.co

def box(bm, center, size, rot=(0, 0, 0), bevel=0.012, seg=2):
    r = bmesh.ops.create_cube(bm, size=1.0); vs = r['verts']; _xf(vs, center, size, rot)
    b = min(bevel, min(size) * 0.34)
    if b > 0:
        es = list({e for v in vs for e in v.link_edges})
        bmesh.ops.bevel(bm, geom=es, offset=b, segments=seg, affect='EDGES')

def ell(bm, center, radii, rot=(0, 0, 0), u=8, v=5):
    u = min(u, 7); v = min(v, 4)
    r = bmesh.ops.create_uvsphere(bm, u_segments=u, v_segments=v, radius=1.0); _xf(r['verts'], center, radii, rot)

def Zk(x, rows, y0=0.0):
    """rows (z, rx, ry[, cy[, cx]]) -> loft keys"""
    return [(x + (r[4] if len(r) > 4 else 0), y0 + (r[3] if len(r) > 3 else 0), r[0], r[1], r[2]) for r in rows]

# ------------------------------------------------------------ joints (same as v2)
def J(name):
    S = -1 if name.endswith("_L") else 1
    t = {"pelvis": (0, 0, .95), "torso": (0, 0, 1.05), "head": (0, 0, 1.56), "scarf": (0, 0, 1.52),
         "upper_arm": (.3 * S, 0, 1.42), "lower_arm": (.3 * S, 0, 1.12), "hand": (.3 * S, 0, .82),
         "upper_leg": (.11 * S, 0, .9), "lower_leg": (.11 * S, 0, .5), "foot": (.11 * S, 0, .1)}
    return V(t[name.rsplit("_", 1)[0] if name[-2:] in ("_L", "_R") else name])

parts = {}
def P(name, parent=None, origin=None):
    bm = bmesh.new(); parts[name] = dict(bm=bm, origin=V(origin) if origin is not None else J(name), parent=parent); return bm

# ------------------------------------------------------------ pelvis (joggers hips)
b = P("pelvis")
loft(b, Zk(0, [(.78, .165, .115), (.85, .186, .122), (.92, .187, .123), (.96, .181, .119), (1.0, .17, .112)]), sub=2, sq=2.3)

# ------------------------------------------------------------ torso (hoodie)
b = P("torso")
def torso_mod(c, a):
    s = abs(math.sin(a)); f = 1 - .012 * G(s, 0, .10)          # side seams
    if c.z > 1.36: f *= 1 + .03 * G(c.z, 1.43, .05) * (1 if math.cos(a) * 0 == 0 else 1) * G(abs(math.cos(a)), 1, .6) * .0
    return f
T_ROWS = [(.935, .190, .122, 0), (.950, .207, .134, 0), (.975, .204, .133, 0), (1.06, .190, .125, 0), (1.14, .183, .119, 0),
          (1.22, .190, .122, -.003), (1.31, .213, .133, -.008), (1.385, .238, .138, -.004), (1.425, .205, .128, 0),
          (1.450, .150, .105, 0), (1.478, .118, .088, 0), (1.505, .092, .078, 0), (1.525, .080, .072, 0)]
loft(b, Zk(0, T_ROWS), sub=2, sq=2.4, mod=torso_mod, segs=16)
tri = b.copy(); bmesh.ops.triangulate(tri, faces=tri.faces[:])
torso_tree = BVHTree.FromBMesh(tri); tri.free()

def hit(o, d):
    loc, nrm, idx, dist = torso_tree.ray_cast(V(o), V(d).normalized(), 3.0)
    return (loc, nrm) if loc is not None else (None, None)

def patch(bm, xs, zs, off):
    """closed surface-conforming raised patch on the torso front (rays +y)."""
    top, bot = [], []
    for z in zs:
        rt, rb = [], []
        for x in xs:
            loc, n = hit((x, -.6, z), (0, 1, 0))
            if loc is None: return
            o = off(x, z); rb.append(bm.verts.new(loc - n * .004)); rt.append(bm.verts.new(loc + n * o))
        top.append(rt); bot.append(rb)
    R, C = len(zs), len(xs)
    for i in range(R - 1):
        for j in range(C - 1):
            bm.faces.new((top[i][j], top[i][j + 1], top[i + 1][j + 1], top[i + 1][j]))
    for j in range(C - 1):
        bm.faces.new((bot[0][j], bot[0][j + 1], top[0][j + 1], top[0][j])); bm.faces.new((bot[-1][j + 1], bot[-1][j], top[-1][j], top[-1][j + 1]))
    for i in range(R - 1):
        bm.faces.new((bot[i][0], top[i][0], top[i + 1][0], bot[i + 1][0])); bm.faces.new((bot[i][-1], bot[i + 1][-1], top[i + 1][-1], top[i][-1]))
    for i in range(R - 1):
        for j in range(C - 1):
            bm.faces.new((bot[i][j + 1], bot[i][j], bot[i + 1][j], bot[i + 1][j + 1]))

TJ = J("torso")
t = P("trim_pocket", "torso", TJ)         # kangaroo pocket
xs = [-.115 + .23 * i / 8 for i in range(9)]; zs = [.98 + .15 * i / 6 for i in range(7)]
patch(t, xs, zs, lambda x, z: .004 + .010 * min(1, (z - .98) / .03) * min(1, (.23 - abs(x) * 2 + .0) / .1) * (1 - .35 * ((z - .98) / .15) ** 2) + .003 * G(z, 1.12, .012))
t = P("trim_zip", "torso", TJ)
patch(t, [-.009, 0, .009], [.97 + .45 * i / 14 for i in range(15)], lambda x, z: .007 - .003 * abs(x) / .009)
t = P("trim_cord", "torso", TJ)           # drawstrings
for s in (-1, 1):
    pts = []
    for i in range(6):
        z = 1.43 - .035 * i; x = .032 * s + .004 * s * i
        loc, n = hit((x, -.6, z), (0, 1, 0))
        if loc: pts.append((loc.x, loc.y + n.y * .005 - (.003 * i * 0), loc.z, .0038, .0038))
    if len(pts) > 3:
        loft(t, pts, sub=1, segs=6, sq=2)
        ell(t, (pts[-1][0], pts[-1][1] - .004, pts[-1][2] - .008), (.005, .005, .012), u=6, v=4)

# backpack (pack_) with straps over shoulders conforming to torso
t = P("pack_bag", "torso", TJ)
loft(t, [(0, .192, z, rx, ry) for z, rx, ry in [(1.03, .120, .040), (1.07, .146, .054), (1.15, .156, .062), (1.26, .156, .064), (1.34, .146, .058), (1.40, .124, .046)]],
     sub=1, sq=3.0, segs=12)
loft(t, [(0, .205, z, rx, ry) for z, rx, ry in [(1.36, .152, .068), (1.395, .150, .070), (1.425, .126, .056)]], sub=1, sq=3.0, segs=12)       # lid
box(t, (0, .262, 1.17), (.17, .04, .15), rot=(.04, 0, 0), bevel=.014, seg=2)
for s in (-1, 1):
    ell(t, (.165 * s, .2, 1.11), (.036, .05, .085), u=10, v=6)
def strap(bm, x, phi0, phi1, c0, wid=.024, N=12):
    keys = []
    for i in range(N):
        ph = math.radians(phi0 + (phi1 - phi0) * i / (N - 1)); d = (0, math.sin(ph), math.cos(ph))
        loc, n = hit((x, c0[0], c0[1]), d)
        if loc is None: continue
        p = loc + n * .008; keys.append((p.x, p.y, p.z, wid / 2, .0065, n.x, n.y, n.z))
    if len(keys) > 3: loft(bm, keys, sub=1, segs=6, sq=3.0)
for s in (-1, 1):
    strap(t, .105 * s, 150, -130, (0, 1.33))
    ps = []
    for i in range(7):
        x = (-.1 + .2 * i / 6); loc, n = hit((x, -.6, 1.33), (0, 1, 0))
        if loc: p = loc + n * .010; ps.append((p.x, p.y, p.z, .011, .0045, n.x, n.y, n.z))
    if s == 1 and len(ps) > 4: loft(t, ps, sub=1, segs=8, sq=3.0)

# ------------------------------------------------------------ head
b = P("head")
def face_mod(c, a):
    z = c.z; s = math.sin(a); co = abs(math.cos(a)); front = max(0, -s); f = 1.0
    f *= 1 - .075 * G(z, 1.693, .011) * front * G(co, .42, .17)         # eye sockets
    f *= 1 + .035 * G(z, 1.652, .016) * front * G(co, .6, .22)          # cheekbones
    f *= 1 - .09 * G(z, 1.600, .016) * front ** 2 * G(co, .15, .7)      # chin taper
    f *= 1 - .03 * G(z, 1.65, .03) * G(co, 1, .12) * (1 if True else 0)  # slight hollow under ears
    f *= 1 - .05 * G(z, 1.738, .03) * G(co, 1, .3)                      # temple
    return f
H_ROWS = [(1.50, .056, .062, .004), (1.55, .054, .061, .0), (1.582, .056, .074, -.012), (1.608, .070, .088, -.009), (1.645, .081, .098, -.004),
          (1.69, .087, .103, 0), (1.74, .086, .102, .004), (1.78, .070, .086, .006), (1.806, .035, .052, .006), (1.816, .012, .018, .006)]
loft(b, Zk(0, H_ROWS), sub=2, sq=2.15, mod=face_mod, segs=16)
for s_ in (-1, 1): ell(b, (.034 * s_, -.093, 1.688), (.015, .009, .008), u=8, v=5)   # eyelids
ell(b, (0, -.099, 1.683), (.010, .013, .028), rot=(.28, 0, 0), u=8, v=6)          # nose bridge
ell(b, (0, -.108, 1.656), (.014, .014, .012), u=8, v=6)                          # nose tip
for s in (-1, 1):
    ell(b, (.015 * s, -.1, 1.652), (.011, .014, .011), u=6, v=4)                # alae
    ell(b, (.034 * s, -.093, 1.704), (.032, .014, .008), rot=(0, .16 * s, 0), u=8, v=5)   # brow
    ell(b, (.086 * s, .012, 1.668), (.008, .020, .030), rot=(0, 0, .12 * s), u=8, v=6)   # ears
    ell(b, (.082 * s, .012, 1.670), (.005, .011, .019), u=6, v=4)
ell(b, (0, -.094, 1.628), (.028, .012, .007), u=8, v=4); ell(b, (0, -.093, 1.616), (.024, .011, .008), u=8, v=4)   # lips
ell(b, (0, -.084, 1.592), (.028, .02, .02), u=8, v=5)                           # chin
t = P("trim_beanie", "head", J("head"))
def rib(c, a): return 1 + .011 * math.cos(a * 30) * (1 if c.z < 1.765 else 0)
B_ROWS = [(1.706, .093, .108, .005), (1.716, .100, .114, .005), (1.738, .103, .117, .005), (1.754, .099, .113, .005), (1.762, .094, .108, .005),
          (1.782, .093, .107, .006), (1.805, .076, .090, .007), (1.825, .047, .060, .008), (1.836, .02, .03, .008)]
loft(t, Zk(0, B_ROWS), sub=2, sq=2.15, mod=rib, segs=20)
ell(t, (0, .008, 1.842), (.014, .014, .012), u=6, v=4)
# sport sunglasses: wrap band + two lenses, hides the face detail that doesn't survive close-up
g = P("trim_glasses", "head", J("head"))
loft(g, Zk(0, [(1.676, .090, .105, .002), (1.690, .091, .106, .002), (1.704, .090, .105, .002)]), sub=2, sq=2.15, segs=18)
for s_ in (-1, 1):
    ell(g, (.036 * s_, -.098, 1.690), (.036, .010, .022), rot=(0, .12 * s_, 0), u=10, v=6)
box(g, (0, -.100, 1.698), (.026, .008, .008))

# ------------------------------------------------------------ scarf: wraps + ribbon tails
b = P("scarf")
def wrap_mod(c, a): return 1 + .02 * math.sin(a * 3 + c.z * 40)
W_ROWS = [(1.447, .160, .124, .004), (1.470, .142, .116, .004), (1.488, .120, .105, .003), (1.505, .130, .113, .002), (1.523, .120, .106, 0),
          (1.542, .126, .108, -.002), (1.562, .112, .099, -.004), (1.60, .095, .088, -.008)]
loft(b, Zk(0, W_ROWS), sub=2, sq=2.2, mod=wrap_mod, segs=16, cap=False)
def tail(bm, s, L, sh):
    pts = [(.060 * s, .095, 1.505), (.074 * s + .01 * sh, .150, 1.470), (.092 * s + .02 * sh, .205, 1.420), (.088 * s, .250, 1.352 + (1 - L) * .03),
           (.070 * s - .02 * sh, .275, 1.290 - .12 * (L - 1) * -1 * 0 - .0), (.074 * s, .292, 1.215), (.084 * s + .01 * sh, .296, 1.14 + .1 * (1 - L)), (.082 * s, .292, 1.075 + .17 * (1 - L))]
    pts = pts[:max(5, int(len(pts) * (0.55 + .45 * L)))] if L < 1 else pts
    keys = []; n = len(pts)
    for i, p in enumerate(pts):
        wd = (.052 - .018 * i / (n - 1)) / 2 * (1 if i < n - 1 else .7)
        ang = .5 * math.sin(i * .9 + s) + .25 * i / n * s
        tdir = V(pts[min(i + 1, n - 1)]) - V(pts[max(i - 1, 0)])
        nn = V((math.sin(ang) * 0, 0, 0)); 
        keys.append((p[0], p[1], p[2], wd, .0055))
    # twisting ribbon: width axis rotates around the path tangent
    rings = loft(bm, keys, sub=2, segs=6, sq=3.4, w=(math.cos(.4 * s), 0, math.sin(.4 * s)))
    return pts
tail(b, 1, 1.0, 0.0); tail(b, -1, .66, .8)
ell(b, (.0, -.015, 1.508), (.0, .0, .0), u=3, v=3)

# ------------------------------------------------------------ arms (hoodie sleeves, gloves) - relaxed bend
for s, S in (("L", -1), ("R", 1)):
    X = .3 * S
    b = P(f"upper_arm_{s}")
    loft(b, [(X - .032 * S, .000, 1.462, .030, .036), (X - .018 * S, .000, 1.448, .056, .060), (X - .004 * S, .0, 1.41, .067, .069), (X + .002 * S, .008, 1.34, .059, .064),
             (X, .014, 1.27, .054, .060), (X, .020, 1.195, .051, .055), (X, .026, 1.15, .050, .054), (X, .030, 1.128, .050, .050), (X, .030, 1.12, .048, .048)],
         sub=2, sq=2.2, noise=.0015)
    b = P(f"lower_arm_{s}")
    loft(b, [(X, .030, 1.12, .048, .048), (X, .024, 1.095, .052, .055), (X, .008, 1.065, .053, .058), (X - .004 * S, -.016, 1.015, .052, .060), (X - .010 * S, -.045, .965, .047, .054),
             (X - .016 * S, -.070, .915, .041, .045), (X - .020 * S, -.082, .875, .049, .052), (X - .022 * S, -.088, .848, .050, .050), (X - .022 * S, -.090, .836, .043, .043)],
         sub=2, sq=2.2, noise=.0015)
    t = P(f"trim_wrap_{s}", f"lower_arm_{s}", J(f"lower_arm_{s}"))
    loft(t, [(X - .013 * S, -.074, .93, .0455, .0495), (X - .017 * S, -.079, .905, .047, .051), (X - .019 * S, -.083, .88, .0465, .05)], sub=2, sq=2.2)
    b = P(f"hand_{s}")                       # relaxed glove: palm, 4 fused fingers curled, thumb
    inn = -S; HX = X - .022 * S; HY = -.024
    loft(b, [(HX, HY - .066, .842, .036, .034), (HX, HY - .07, .812, .046, .027), (HX, HY - .074, .775, .048, .026), (HX, HY - .077, .742, .046, .026)], sub=1, sq=2.4, segs=8)
    for i, fx in enumerate((-.0345, -.0115, .0115, .0345)):
        ln = (.9, 1.0, .95, .8)[i]; r = .0118 - abs(fx) * .06
        pts = [(HX + fx * S, HY - .078, .745), (HX + fx * S, HY - .092, .718 - .01 * ln), (HX + fx * S, HY - .116, .692 - .017 * ln), (HX + fx * S, HY - .130, .672 - .016 * ln + .012)]
        loft(b, [(p[0], p[1], p[2], r - j * .0011, r * 0.95 - j * .0008) for j, p in enumerate(pts)], sub=1, sq=2.0, segs=6)
    th = [(HX + inn * .042, HY - .068, .805, .016, .016), (HX + inn * .056, HY - .088, .778, .0145, .0145), (HX + inn * .057, HY - .108, .752, .013, .013), (HX + inn * .048, HY - .122, .735, .0105, .0105)]
    loft(b, th, sub=1, sq=2.0, segs=6)

# ------------------------------------------------------------ legs (joggers, cuffs, shoes)
SHOE = [(.122, .088, .052, .040), (.100, .098, .064, .052), (.060, .103, .068, .058), (.010, .095, .060, .064), (-.04, .088, .053, .068),
        (-.10, .080, .046, .074), (-.16, .076, .042, .078), (-.22, .072, .038, .072), (-.265, .067, .033, .058), (-.296, .062, .027, .036)]
def shoe_top(y):
    ys = [r[0] for r in SHOE]
    for i in range(len(SHOE) - 1):
        if ys[i] >= y >= ys[i + 1]:
            t = (ys[i] - y) / (ys[i] - ys[i + 1]); a, b_ = SHOE[i], SHOE[i + 1]
            return (a[1] + a[2]) * (1 - t) + (b_[1] + b_[2]) * t
    return .1
for s, S in (("L", -1), ("R", 1)):
    X = .11 * S
    b = P(f"upper_leg_{s}")
    loft(b, [(X, .004, .93, .096, .106), (X, .002, .86, .103, .112), (X, -.004, .78, .098, .108), (X, -.016, .68, .088, .100), (X, -.028, .60, .079, .090),
             (X, -.037, .535, .072, .080), (X, -.040, .505, .070, .077), (X, -.040, .5, .069, .076)], sub=2, sq=2.3, noise=.002)
    b = P(f"lower_leg_{s}")
    loft(b, [(X, -.040, .50, .069, .076), (X, -.042, .475, .071, .080), (X, -.036, .44, .066, .076), (X, -.018, .37, .061, .082), (X, -.004, .31, .056, .072),
             (X, .004, .245, .049, .058), (X, .006, .20, .056, .066), (X, .004, .16, .066, .076), (X, .002, .13, .064, .074), (X, .0, .115, .061, .071)],
         sub=2, sq=2.2, noise=.002)
    b = P(f"foot_{s}")
    loft(b, [(X, y, cz, rw, rt) for y, cz, rt, rw in SHOE], sub=2, sq=2.6, segs=12)
    ell(b, (X, -.215, .085), (.050, .072, .033), u=10, v=6)                                # toe cap
    loft(b, [(X, y, shoe_top(y) + .001, .021, .005) for y in (.04, 0, -.04, -.08, -.12, -.16)], sub=1, segs=6, sq=3.0)        # tongue
    for y in (-.01, -.045, -.08, -.115):
        z = shoe_top(y)
        loft(b, [(X - .032, y, z - .006, .0045, .0045), (X, y, z + .006, .0045, .0045), (X + .032, y, z - .006, .0045, .0045)], sub=2, segs=6, sq=2)  # laces
    t = P(f"sole_{s}", f"foot_{s}", J(f"foot_{s}"))
    Sx = [(.138, .028, .030, .052), (.108, .028, .030, .066), (.0, .028, .030, .080), (-.15, .029, .031, .091), (-.24, .040, .034, .086), (-.305, .062, .030, .054)]
    loft(t, [(X, y, cz, rw, rt) for y, cz, rt, rw in Sx], sub=1, sq=3.0, segs=12)

# ------------------------------------------------------------ finish
for d in parts.values():
    bm = d['bm']
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces: f.smooth = True
    for e in bm.edges:
        if len(e.link_faces) == 2 and e.calc_face_angle(0) > math.radians(58): e.smooth = False
    bmesh.ops.triangulate(bm, faces=bm.faces[:])

allv, allp = [], []
for d in parts.values():
    d['bm'].verts.index_update(); d['bm'].faces.index_update(); d['bm'].verts.ensure_lookup_table()
    off = len(allv); allv += [v.co.copy() for v in d['bm'].verts]
    allp += [tuple(off + v.index for v in f.verts) for f in d['bm'].faces]
tree = BVHTree.FromPolygons(allv, allp)
N = 48; dirs = []
for i in range(N):
    z = (i + .5) / N; r = math.sqrt(1 - z * z); a = i * 2.39996
    dirs.append((r * math.cos(a), r * math.sin(a), z))
ao = {}; R = .26
for name, d in parts.items():
    bm = d['bm']; a_ = {}
    for v in bm.verts:
        n = v.normal.normalized() if v.normal.length > 0 else V((0, 0, 1))
        tx = n.cross(V((0, 0, 1)) if abs(n.z) < .9 else V((1, 0, 0))).normalized(); ty = n.cross(tx); h = 0.0
        for dx, dy, dz in dirs:
            loc, nn, idx, dist = tree.ray_cast(v.co + n * 0.004, tx * dx + ty * dy + n * dz, R)
            if loc is not None: h += 1 - dist / R * 0.55
        a_[v.index] = h / N
    ao[name] = a_
vals = sorted(x for a_ in ao.values() for x in a_.values()); p95 = vals[int(len(vals) * .95)] or 1
def shade(name, vi, v):
    k = min(1.0, ao[name][vi] / p95); g = 1.0 - 0.36 * k ** 0.85
    g *= 0.97 + 0.03 * min(1, max(0, (v.co.z - .3) / 1.5))
    if name.startswith("sole_"): g *= 0.84
    return max(0.6, min(1.0, g))

bpy.ops.wm.read_factory_settings(use_empty=True)
mat = bpy.data.materials.new("runner_mat"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.85
_ca = nt.nodes.new("ShaderNodeVertexColor"); _ca.layer_name = "COLOR_0"
nt.links.new(_ca.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
objs = {}; tot = 0; gs = []
for name, d in parts.items():
    bm = d['bm']; col = bm.loops.layers.color.new("COLOR_0")
    for f in bm.faces:
        for l in f.loops:
            g = shade(name, l.vert.index, l.vert); gs.append(g); h = g ** (1 / 2.2); l[col] = (h, h, h, 1.0)
    bmesh.ops.translate(bm, verts=bm.verts, vec=-d['origin'])
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free(); me.materials.append(mat)
    ob = bpy.data.objects.new(name, me); bpy.context.collection.objects.link(ob); ob.location = d['origin']; objs[name] = ob; tot += len(me.polygons)
for name, d in parts.items():
    if d['parent']:
        ob = objs[name]; ob.parent = objs[d['parent']]; ob.matrix_parent_inverse = Matrix.Identity(4); ob.location = (0, 0, 0)
print({k:len(o.data.polygons) for k,o in objs.items()}); print("TRIS", tot, "AO mean", sum(gs) / len(gs), "min", min(gs))
dst = os.environ.get("OUT_GLB", os.path.join(OUT, "runner.glb"))
for o in bpy.context.scene.objects: o.select_set(True)
bpy.ops.export_scene.gltf(filepath=dst, export_format='GLB', use_selection=True, export_yup=True, export_apply=True, export_vertex_color='MATERIAL', export_all_vertex_colors=False)
print("WROTE", dst)
