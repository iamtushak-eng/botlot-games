import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--allow-file-access-from-files','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); await p.setViewport({ width: 1000, height: 600 });
const logs = []; p.on('console', m => m.type() === 'error' && logs.push(m.text().slice(0, 300))); p.on('pageerror', e => logs.push('PAGEERROR ' + String(e.stack).slice(0, 400))); p.on('requestfailed', r => logs.push('REQFAIL ' + r.url().slice(0, 100)));
await p.goto('file:///home/claude/deadline/dist-single/index.html'); await new Promise(r => setTimeout(r, 6000));
await p.evaluate(() => document.querySelector('[data-start="momentum"]').click());
await new Promise(r => setTimeout(r, 300));
await new Promise(r => setTimeout(r, 6000)); await p.screenshot({ path: '/tmp/single.png' });
console.log(await p.evaluate(() => { const g = window.__deadline?.game; return g ? g.run.state : 'no game'; })); console.log(logs.join('\n') || 'no errors'); await b.close();
