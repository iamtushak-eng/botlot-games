import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage(); p.on('console', m => console.log(m.type(), m.text().slice(0, 300)));
await p.goto('http://localhost:8123/index.html'); await new Promise(r => setTimeout(r, 4000));
await p.evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.includes('Begin today')).click());
await new Promise(r => setTimeout(r, 300)); await p.evaluate(() => document.querySelector('.mode[data-mode="precision"]').click());
await new Promise(r => setTimeout(r, 3000));
console.log(await p.evaluate(() => { const g = window.__deadline.game; let n=0,sf=0,vc=0; const kinds={}; g.scene.traverse(o=>{ if(o.isMesh){ n++; const m=o.material; kinds[m.type+':'+m.vertexColors]=(kinds[m.type+':'+m.vertexColors]||0)+1; if(m.userData.surf) sf++; }}); return JSON.stringify({n,sf,kinds}); }));
await b.close();
