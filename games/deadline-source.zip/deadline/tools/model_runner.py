import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lowpoly import *
reset(); mat = material(); objs = []
def part(name, origin, fn, seed):
    b = Builder(seed); fn(b); objs.append(b.build(name, origin, mat))
for s, S in (("L", -1), ("R", 1)):
    # legs (z up, feet at z=0)
    part(f"upper_leg_{s}", (S*0.11, 0, 0.9), lambda b, S=S: (
        b.box((0.19, 0.2, 0.42), (S*0.11, 0, 0.69), 'pants'),
        b.box((0.2, 0.21, 0.1), (S*0.11, 0, 0.6), 'jacket_d')), 10+S)
    part(f"lower_leg_{s}", (S*0.11, 0, 0.5), lambda b, S=S: (
        b.box((0.16, 0.17, 0.4), (S*0.11, 0, 0.3), 'pants'),
        b.box((0.18, 0.19, 0.07), (S*0.11, 0, 0.16), 'scarf')), 20+S)
    part(f"foot_{s}", (S*0.11, 0, 0.1), lambda b, S=S: (
        b.box((0.17, 0.3, 0.1), (S*0.11, -0.05, 0.05), 'shoe'),
        b.box((0.17, 0.08, 0.04), (S*0.11, -0.19, 0.04), 'white')), 30+S)
    # arms
    part(f"upper_arm_{s}", (S*0.3, 0, 1.42), lambda b, S=S: (
        b.box((0.15, 0.16, 0.34), (S*0.3, 0, 1.27), 'jacket'),
        b.box((0.17, 0.18, 0.1), (S*0.3, 0, 1.4), 'jacket_d')), 40+S)
    part(f"lower_arm_{s}", (S*0.3, 0, 1.12), lambda b, S=S: (
        b.box((0.13, 0.14, 0.3), (S*0.3, 0, 0.97), 'jacket'),
        b.box((0.15, 0.16, 0.05), (S*0.3, 0, 0.86), 'jacket_d')), 50+S)
    part(f"hand_{s}", (S*0.3, 0, 0.82), lambda b, S=S: (
        b.box((0.12, 0.12, 0.12), (S*0.3, 0, 0.76), 'skin', bevel=0.02)), 60+S)
part("pelvis", (0, 0, 0.95), lambda b: (
    b.box((0.38, 0.23, 0.2), (0, 0, 0.95), 'pants'),
    b.box((0.4, 0.25, 0.05), (0, 0, 1.02), 'dark')), 70)
part("torso", (0, 0, 1.05), lambda b: (
    b.box((0.46, 0.27, 0.46), (0, 0, 1.28), 'jacket'),
    b.box((0.1, 0.285, 0.46), (0, 0, 1.28), 'jacket_d', jit=False),
    b.box((0.48, 0.29, 0.07), (0, 0, 1.08), 'jacket_d'),
    b.box((0.14, 0.05, 0.1), (-0.12, -0.15, 1.3), 'dark')), 80)
part("head", (0, 0, 1.56), lambda b: (
    b.box((0.3, 0.3, 0.3), (0, 0, 1.72), 'skin', bevel=0.05),
    b.box((0.32, 0.32, 0.12), (0, 0.01, 1.82), 'dark', bevel=0.03),
    b.box((0.2, 0.03, 0.05), (0, -0.155, 1.74), 'dark', bevel=0.01),
    b.box((0.07, 0.07, 0.12), (0, -0.17, 1.7), 'skin', bevel=0.015)), 90)
part("scarf", (0, 0, 1.52), lambda b: (
    b.box((0.34, 0.31, 0.1), (0, 0, 1.54), 'scarf', bevel=0.03),
    b.box((0.12, 0.05, 0.4), (0.12, 0.2, 1.38), 'scarf', rot=(0.25, 0, 0.1)),
    b.box((0.12, 0.05, 0.3), (0.2, 0.26, 1.28), 'scarf', rot=(0.5, 0, -0.1))), 100)
m = export("runner.glb", objs)
json.dump(m, open("/tmp/runner_manifest.json", "w")); print(m)
