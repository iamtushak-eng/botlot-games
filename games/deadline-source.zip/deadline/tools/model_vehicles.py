"""Deadline vehicles: skateboard, bike, inline skates. Run: python3 tools/model_vehicles.py
Blender Z-up -> glTF Y-up. Vehicles face Blender -Y (glTF +Z), origin on the ground under the middle.
Node contract used by src/game/runner.js:
  board.glb : root 'board', children wheel_0..3 (origin = hub, spin about X)
  bike.glb  : root 'bike', children 'fork' (pivot = head tube, holds wheel_F + bars), wheel_R, 'crank' (pivot = bottom bracket)
  skates.glb: roots 'skate_L','skate_R' (origin = foot joint), each with wheel_0..3
Real dimensions in metres. Materials are plain PBR; colours are set in code per day palette where needed."""
import bpy, bmesh, math, os
from mathutils import Vector as V, Matrix, Euler

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "assets/models")

def lin(h):
    h = h.lstrip('#'); c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return [x / 12.92 if x <= .04045 else ((x + .055) / 1.055) ** 2.4 for x in c] + [1]
MATS = {}
def mat(name, hexc, rough=.7, metal=0.0):
    if name not in MATS:
        m = bpy.data.materials.new(name); m.use_nodes = True; b = m.node_tree.nodes["Principled BSDF"]
        b.inputs["Base Color"].default_value = lin(hexc); b.inputs["Roughness"].default_value = rough; b.inputs["Metallic"].default_value = metal
        MATS[name] = m
    return MATS[name]

def link(ob):
    bpy.context.collection.objects.link(ob); return ob
def mesh_from(bm, name, m, loc=(0, 0, 0)):
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free(); me.materials.append(m)
    ob = bpy.data.objects.new(name, me); ob.location = loc; link(ob)
    for p in me.polygons: p.use_smooth = True
    return ob
def empty(name, loc=(0, 0, 0)):
    ob = bpy.data.objects.new(name, None); ob.location = loc; return link(ob)
def parent(ch, par):
    bpy.context.view_layer.update(); ch.parent = par; ch.matrix_parent_inverse = par.matrix_world.inverted()

def bevel_box(bm, c, s, bev=0.006):
    r = bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=s, verts=r['verts']); bmesh.ops.translate(bm, vec=c, verts=r['verts'])
    if bev > 0:
        edges = list({e for v in r['verts'] for e in v.link_edges})
        bmesh.ops.bevel(bm, geom=edges, offset=bev, segments=2, affect='EDGES')
def tube(bm, a, b, r, segs=10, r2=None):
    a, b = V(a), V(b); d = b - a; L = d.length
    cs = bmesh.ops.create_cone(bm, cap_ends=True, segments=segs, radius1=r, radius2=r2 if r2 is not None else r, depth=L)
    q = V((0, 0, 1)).rotation_difference(d.normalized()).to_matrix().to_4x4()
    bmesh.ops.transform(bm, matrix=Matrix.Translation((a + b) / 2) @ q, verts=cs['verts'])
def disc_x(bm, c, r, w, segs=16):  # cylinder with its axis along X
    cs = bmesh.ops.create_cone(bm, cap_ends=True, segments=segs, radius1=r, radius2=r, depth=w)
    bmesh.ops.transform(bm, matrix=Matrix.Translation(c) @ Matrix.Rotation(math.pi / 2, 4, 'Y'), verts=cs['verts'])
def torus_x(bm, c, R, r, ns=28, nm=8):
    verts = [[None] * nm for _ in range(ns)]
    for i in range(ns):
        a = i / ns * math.tau
        for j in range(nm):
            b = j / nm * math.tau; rr = R + r * math.cos(b)
            verts[i][j] = bm.verts.new(V(c) + V((r * math.sin(b), rr * math.sin(a), rr * math.cos(a))))
    for i in range(ns):
        for j in range(nm):
            bm.faces.new((verts[i][j], verts[(i + 1) % ns][j], verts[(i + 1) % ns][(j + 1) % nm], verts[i][(j + 1) % nm]))
def ell(bm, c, rad, rot=(0, 0, 0)):
    r = bmesh.ops.create_uvsphere(bm, u_segments=12, v_segments=8, radius=1.0)
    bmesh.ops.scale(bm, vec=rad, verts=r['verts'])
    bmesh.ops.transform(bm, matrix=Matrix.Translation(c) @ Euler(rot).to_matrix().to_4x4(), verts=r['verts'])

def export(path, roots):
    for o in bpy.context.scene.objects: o.select_set(False)
    for o in bpy.context.scene.objects: o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True, export_yup=True, export_apply=True)

def reset(): bpy.ops.wm.read_factory_settings(use_empty=True); MATS.clear()

# ------------------------------------------------------------ skateboard
def wheel_urethane(parent_ob, name, loc, r=0.0275, w=0.036, hexc='#e9e2cf'):
    bm = bmesh.new(); disc_x(bm, (0, 0, 0), r, w, 18); ob = mesh_from(bm, name, mat('urethane', hexc, .5), loc); parent(ob, parent_ob); return ob
def build_board():
    reset(); root = empty('board')
    # deck: 0.80 x 0.205, concave ends kicked up, top at 0.085
    bm = bmesh.new()
    zc = 0.075
    N = 22; prof = []
    for i in range(N + 1):
        t = i / N * 2 - 1; y = t * 0.40
        kick = max(0, abs(t) - 0.62) / 0.38; z = zc + 0.05 * kick * kick
        w = 0.1025 * (1 - 0.1 * max(0, abs(t) - 0.85) / 0.15)
        prof.append((y, z, w))
    rows = []
    for (y, z, w) in prof:
        row = []
        for k in range(7):  # cross-section with slight concave
            u = k / 6 * 2 - 1; row.append(bm.verts.new((u * w, y, z + 0.012 * u * u + 0.0)))
        rows.append(row)
    for i in range(N):
        for k in range(6): bm.faces.new((rows[i][k], rows[i][k + 1], rows[i + 1][k + 1], rows[i + 1][k]))
    top = bmesh.ops.extrude_face_region(bm, geom=list(bm.faces)); bmesh.ops.translate(bm, vec=(0, 0, -0.011), verts=[v for v in top['geom'] if isinstance(v, bmesh.types.BMVert)])
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    deck = mesh_from(bm, 'deck', mat('deck', '#c9a46a', .6)); parent(deck, root)
    bm = bmesh.new(); bevel_box(bm, (0, 0, zc + 0.016), (0.19, 0.42, 0.003), 0); bm.faces.ensure_lookup_table()
    grip = mesh_from(bm, 'grip', mat('griptape', '#1b1c1f', .95)); parent(grip, root)
    bm = bmesh.new(); bevel_box(bm, (0, -0.19, zc + 0.0185), (0.205, 0.025, 0.002), 0); bevel_box(bm, (0, 0.19, zc + 0.0185), (0.205, 0.025, 0.002), 0)
    stripe = mesh_from(bm, 'stripe', mat('stripe', '#ff5a1f', .7)); parent(stripe, root)
    for sy, nm in ((-0.245, 'truck_F'), (0.245, 'truck_R')):
        bm = bmesh.new(); bevel_box(bm, (0, sy, 0.066), (0.09, 0.05, 0.012), 0.004); tube(bm, (-0.085, sy, 0.042), (0.085, sy, 0.042), 0.007, 8)
        bevel_box(bm, (0, sy, 0.055), (0.05, 0.04, 0.02), 0.004)
        ob = mesh_from(bm, nm, mat('truck', '#9ea3a8', .35, .8)); parent(ob, root)
    for i, (sx, sy) in enumerate(((-0.07, -0.245), (0.07, -0.245), (-0.07, 0.245), (0.07, 0.245))):
        wheel_urethane(root, f'wheel_{i}', (sx + (-0.02 if sx < 0 else 0.02), sy, 0.0275))
    export(os.path.join(OUT, 'veh_board.glb'), [root])

# ------------------------------------------------------------ bike
def build_bike():
    reset(); root = empty('bike')
    FRAME = mat('frame', '#2d6a68', .45, .2); BLACK = mat('black', '#17181a', .6); STEEL = mat('steel', '#a9adb2', .35, .8); TIRE = mat('tire', '#1d1e20', .85); LEATHER = mat('saddle', '#7a4a26', .7)
    RA = V((0, .5, .34)); FA = V((0, -.5, .34)); BB = V((0, .06, .31)); ST = V((0, .17, .90)); HT = V((0, -.40, .80)); HB = V((0, -.435, .70))
    bm = bmesh.new()
    for a, b, r in ((BB, ST, .016), (ST, HT, .015), (BB, HB, .021), (HB, HT, .02), (BB, RA, .011), (ST, RA + V((0, 0, .02)), .01)):
        tube(bm, a, b, r, 10)
    tube(bm, ST, ST + V((0, .03, .09)), .0125)  # seat post
    frame = mesh_from(bm, 'frame', FRAME); parent(frame, root)
    bm = bmesh.new(); ell(bm, (0, .20, 1.0), (.065, .13, .026), (math.radians(-8), 0, 0)); sad = mesh_from(bm, 'saddle', LEATHER); parent(sad, root)
    # rear wheel
    def wheel(name, c, parent_ob):
        bm = bmesh.new(); torus_x(bm, (0, 0, 0), .318, .024); ob = mesh_from(bm, name, TIRE, c)
        bm2 = bmesh.new(); torus_x(bm2, (0, 0, 0), .296, .008, 24, 6); disc_x(bm2, (0, 0, 0), .02, .09, 10)
        for k in range(12):
            a = k / 12 * math.tau; tube(bm2, (0, 0, 0), (0, .296 * math.sin(a), .296 * math.cos(a)), .0025, 4)
        rim = mesh_from(bm2, name + '_rim', STEEL, c); parent(ob, parent_ob); parent(rim, ob); return ob
    wheel('wheel_R', RA, root)
    # fork group: pivot at head tube; steering rotates it about Y
    fork = empty('fork', HT); parent(fork, root)
    bm = bmesh.new()
    for sx in (-.045, .045): tube(bm, HB + V((sx, 0, 0)), FA + V((sx, 0, 0)), .011, 8)
    tube(bm, HB + V((-.045, 0, .0)), HB + V((.045, 0, .0)), .012, 8)
    tube(bm, HT, HT + V((0, .01, .13)), .013, 8)   # steerer / stem
    tube(bm, HT + V((0, .01, .13)), HT + V((0, -.035, .14)), .012, 8)
    tube(bm, HT + V((-.21, -.07, .13)), HT + V((.21, -.07, .13)), .0115, 8)  # bars
    for sx in (-.21, .21): tube(bm, HT + V((sx, -.07, .13)), HT + V((sx * 1.02, .06, .105)), .011, 8)
    for sx in (-.2, .2): tube(bm, HT + V((sx, -.07, .13)), HT + V((sx * 1.1, -.085, .13)), .015, 8)
    fk = mesh_from(bm, 'fork_mesh', BLACK); parent(fk, fork)
    wheel('wheel_F', FA, fork)
    # crank + pedals
    crank = empty('crank', BB); parent(crank, root)
    bm = bmesh.new(); tube(bm, (-.07, 0, 0), (.07, 0, 0), .012, 8); disc_x(bm, (0, 0, 0), .05, .01, 18)
    tube(bm, (-.07, 0, 0), (-.07, 0, -.17), .012, 8); tube(bm, (.07, 0, 0), (.07, 0, .17), .012, 8)
    bevel_box(bm, (-.09, 0, -.17), (.06, .1, .015), .003); bevel_box(bm, (.09, 0, .17), (.06, .1, .015), .003)
    cr = mesh_from(bm, 'crank_mesh', mat('crank', '#6b6f75', .4, .8)); parent(cr, crank)
    export(os.path.join(OUT, 'veh_bike.glb'), [root])

# ------------------------------------------------------------ inline skates (frame + wheels under the runner's shoes)
def pass:
    reset(); FOOT_Z = 0.10  # foot joint height above the shoe sole in runner space
    for S, nm in ((-1, 'L'), (1, 'R')):
        root = empty('skate_' + nm, (0.11 * S, 0, 0.0))  # root origin sits at the sole centre line; code places it on the foot
        bm = bmesh.new()
        bevel_box(bm, (0, -0.0, -0.012), (0.045, 0.34, 0.016), 0.004)
        for y in (-0.15, 0.13): bevel_box(bm, (0, y, -0.035), (0.03, 0.03, 0.035), 0.004)
        for sx in (-.03, .03): bevel_box(bm, (sx, 0.0, -0.045), (0.006, 0.33, 0.045), 0.003)
        fr = mesh_from(bm, f'frame_{nm}', mat('skate_frame', '#202226', .5, .4), (0.11 * S, 0, 0)); parent(fr, root)
        for i, y in enumerate((-0.135, -0.045, 0.045, 0.135)):
            bm = bmesh.new(); disc_x(bm, (0, 0, 0), .037, .03, 18)
            w = mesh_from(bm, f'wheel_{nm}{i}', mat('skate_wheel', '#ff5a1f', .45), (0.11 * S, y, -0.063)); w.location = (0.11 * S, y, -0.063 + 0.0)
            parent(w, root)
    export(os.path.join(OUT, 'veh_skates.glb'), [])

build_board(); build_bike(); print('WROTE vehicles')
