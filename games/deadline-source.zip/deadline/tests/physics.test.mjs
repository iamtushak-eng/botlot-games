import assert from 'node:assert/strict';
import { World, getPose } from '../src/physics/index.js';

function level() {
  const w = new World();
  w.addBox({ min: [-50, -1, -50], max: [50, 0, 50] });
  w.addBox({ min: [8, 0, -5], max: [9, 5, 5] });
  return w;
}
function run(seed) {
  const w = level(); const c = w.createCharacter({ mode: 'momentum', pos: [0, 0.1, 0] });
  const r = w.createCharacter({ mode: 'ragdoll', pos: [-10, 1, 0] });
  w.addRope({ anchor: [0, 6, 10], length: 4, segments: 8, stiffness: 1 });
  for (let i = 0; i < 1200; i++) {
    c.setInput({ moveZ: 1, moveX: Math.sin(i * 0.01 + seed), jump: i % 150 === 0, jumpHeld: i % 150 < 40, yaw: 0.3 });
    r.setInput({ moveZ: 1, yaw: 0 });
    w.step(1 / 60);
  }
  return w.hash();
}
// determinism
assert.equal(run(1), run(1)); assert.notEqual(run(1), run(2)); console.log('ok determinism');

// no tunneling at 40 m/s into thin wall
{
  const w = new World(); w.addBox({ min: [-50, -1, -50], max: [50, 0, 50] });
  w.addBox({ min: [10, 0, -5], max: [10.1, 4, 5] });
  const c = w.createCharacter({ mode: 'momentum', pos: [0, 0.05, 0] });
  c.vel[0] = 40;
  for (let i = 0; i < 240; i++) { c.setInput({ moveZ: 0 }); w.step(1 / 120); c.vel[0] = Math.max(c.vel[0], i < 100 ? 40 : 0); assert.ok(c.pos[0] < 10, 'tunneled at ' + i); }
  console.log('ok no tunneling (x=' + c.pos[0].toFixed(2) + ')');
}
// slope sliding on ice ramp
{
  const w = new World();
  w.addRamp({ min: [-5, 0, -5], max: [5, 0, 5], heights: [6, 0, 6, 0], surface: 'ice' }); // ~50deg? 6m over 10m = 31deg
  const c = w.createCharacter({ mode: 'precision', pos: [-4, 4.5, 0] });
  for (let i = 0; i < 120; i++) w.step(1 / 60);
  assert.ok(c.pos[0] > -3, 'did not slide, x=' + c.pos[0]); assert.ok(c.pos[1] < 4, 'y=' + c.pos[1]);
  console.log('ok slope sliding x=' + c.pos[0].toFixed(2));
}
// ground standing, jump, coyote
{
  const w = level(); const c = w.createCharacter({ mode: 'precision', pos: [0, 2, 0] });
  for (let i = 0; i < 120; i++) w.step(1 / 60);
  assert.ok(c.onGround && Math.abs(c.pos[1]) < 0.05, 'stand y=' + c.pos[1]);
  c.setInput({ jump: true, jumpHeld: true }); w.step(1 / 60);
  assert.ok(w.events.some(e => e.type === 'jump')); assert.ok(w.events.some(e => e.type === 'land'));
  console.log('ok ground/jump/land');
}
// rope swing
{
  const w = new World(); w.addBox({ min: [-50, -10, -50], max: [50, -9, 50] });
  const rope = w.addRope({ anchor: [0, 8, 0], length: 5, segments: 10, stiffness: 1 });
  const c = w.createCharacter({ mode: 'momentum', pos: [0, 3.4, 0.5] });
  c.setInput({ grab: true });
  let minX = 0, maxX = 0;
  for (let i = 0; i < 480; i++) { c.setInput({ grab: true, moveX: i < 200 ? 1 : 0 }); w.step(1 / 120); minX = Math.min(minX, c.pos[0]); maxX = Math.max(maxX, c.pos[0]); }
  assert.equal(c.state, 'rope'); assert.ok(w.events.some(e => e.type === 'grab'));
  assert.ok(maxX - minX > 0.5, 'no swing ' + (maxX - minX));
  const d = Math.hypot(c.pos[0], c.pos[1] + 1.6 - 8, c.pos[2]); assert.ok(d < 5.5);
  console.log('ok rope swing amp=' + (maxX - minX).toFixed(2));
}
// ragdoll pose + bridge
{
  const w = level(); const r = w.createCharacter({ mode: 'ragdoll', pos: [0, 0.2, 0] });
  for (let i = 0; i < 360; i++) w.step(1 / 60);
  const pose = getPose(r); assert.equal(Object.keys(pose).length, 12);
  assert.ok(pose.head[1] > pose.pelvis[1] && pose.pelvis[1] > -0.1, 'ragdoll collapsed');
  const w2 = new World(); w2.addBridge({ a: [0, 5, 0], b: [10, 5, 0], planks: 10, sag: 0.3 });
  const c = w2.createCharacter({ mode: 'precision', pos: [5, 6, 0] });
  for (let i = 0; i < 240; i++) w2.step(1 / 60);
  assert.ok(c.onGround, 'bridge not holding y=' + c.pos[1]);
  console.log('ok ragdoll + bridge');
}
// moving platform carries the character, hazards kill, raycast hits
{
  const w = new World();
  const plat = w.addBox({ min: [-2, -1, -2], max: [2, 0, 2], move: { axis: 0, amp: 3, speed: 0.25, phase: 0 } });
  const c = w.createCharacter({ mode: 'precision', pos: [0, 0.05, 0] });
  let maxx = 0; for (let i = 0; i < 360; i++) { w.step(1 / 60); maxx = Math.max(maxx, c.pos[0]); }
  assert.ok(maxx > 1.5 && c.onGround, 'platform did not carry: ' + maxx);
  const w2 = new World(); w2.addBox({ min: [-5, -1, -5], max: [5, 0, 5] });
  w2.addHazard({ pos: [0, 1, 0], radius: 1.2 }); const k = w2.createCharacter({ mode: 'momentum', pos: [0, 0.1, 0] });
  w2.step(1 / 30); assert.ok(k.dead && w2.events.some(e => e.type === 'death' && e.cause === 'saw'));
  const w3 = new World(); w3.addBox({ min: [5, 0, -1], max: [6, 3, 1] });
  assert.ok(Math.abs(w3.raycast([0, 1, 0], [1, 0, 0], 20).distance - 5) < 1e-6);
  console.log('ok moving platform + hazard + raycast');
}
