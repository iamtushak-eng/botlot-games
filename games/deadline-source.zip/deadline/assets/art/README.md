# Deadline art
Hand-wobbled SVG (generated with seeded jitter; stamp/rough filters via feTurbulence).
Palette: ink #1b1a17, paper #efe4cc, red #c8321f (only accent), muted dust #9a8c70, muted teal #5c7573.
Files: logo.svg, logo-mark.svg (512), favicon.svg, title-art.svg (1600x800), precision.svg, momentum.svg, ragdoll.svg, theme-01..10.svg.
Wordmark uses system heavy sans (Impact fallback); outline text before print.
