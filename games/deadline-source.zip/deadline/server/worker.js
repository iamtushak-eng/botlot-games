// Deadline API: Cloudflare Worker + KV (binding: DEADLINE_KV).
// POST /run  {date,mode,progress,died,pos,inputs}  -> {ok,percentile}
// GET  /day/:date/:mode -> {date,mode,total,deaths,ghosts}
const MODES = new Set(['precision', 'momentum', 'ragdoll']);
const MAX_BODY = 32 * 1024, MAX_INPUTS = 600, MAX_STORED = 2000, RATE_PER_MIN = 20;
const CORS = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'content-type' };
const json = (o, s = 200, h = {}) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json', ...CORS, ...h } });

async function sha(text) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(b)].slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join('');
}
const validDate = d => /^\d{4}-\d{2}-\d{2}$/.test(d) && !isNaN(Date.parse(d));
const today = () => new Date().toISOString().slice(0, 10);
const num = (v, lo, hi) => typeof v === 'number' && isFinite(v) && v >= lo && v <= hi;

function percentile(list, progress) {
  if (!list.length) return 0;
  let below = 0; for (const r of list) if (r.p < progress) below++;
  return Math.round((below / list.length) * 100);
}

async function rateLimit(env, ip) {
  const key = 'rl:' + await sha(ip + (env.IP_SALT || '')) + ':' + Math.floor(Date.now() / 60000);
  const n = parseInt(await env.DEADLINE_KV.get(key) || '0', 10);
  if (n >= RATE_PER_MIN) return false;
  await env.DEADLINE_KV.put(key, String(n + 1), { expirationTtl: 120 });
  return true;
}

async function postRun(req, env) {
  const ip = req.headers.get('cf-connecting-ip') || '0.0.0.0';
  if (!(await rateLimit(env, ip))) return json({ ok: false, error: 'rate_limited' }, 429, { 'retry-after': '60' });
  const raw = await req.text();
  if (raw.length > MAX_BODY) return json({ ok: false, error: 'too_large' }, 413);
  let b; try { b = JSON.parse(raw); } catch { return json({ ok: false, error: 'bad_json' }, 400); }
  if (!b || !MODES.has(b.mode) || !validDate(b.date) || !num(b.progress, 0, 100)) return json({ ok: false, error: 'invalid' }, 400);
  if (b.date !== today()) return json({ ok: false, error: 'wrong_day' }, 400);
  let pos = null;
  if (b.pos != null) {
    if (!Array.isArray(b.pos) || b.pos.length !== 3 || !b.pos.every(v => num(v, -10000, 10000))) return json({ ok: false, error: 'bad_pos' }, 400);
    pos = b.pos;
  }
  let inputs = null;
  if (b.inputs != null) {
    if (!Array.isArray(b.inputs) || b.inputs.length > MAX_INPUTS) return json({ ok: false, error: 'inputs_too_large' }, 413);
    inputs = b.inputs;
  }
  // one run per IP hash per mode per day
  const once = `once:${b.date}:${b.mode}:${await sha(ip + (env.IP_SALT || ''))}`;
  if (await env.DEADLINE_KV.get(once)) return json({ ok: false, error: 'already_played' }, 409);
  await env.DEADLINE_KV.put(once, '1', { expirationTtl: 172800 });

  const key = `day:${b.date}:${b.mode}`;
  const day = JSON.parse(await env.DEADLINE_KV.get(key) || '{"runs":[]}');
  const percentileVal = percentile(day.runs, b.progress);
  if (day.runs.length < MAX_STORED) {
    day.runs.push({ p: Math.round(b.progress * 100) / 100, d: !!b.died, pos, i: inputs && day.runs.filter(r => r.i).length < 10 ? inputs : null });
    await env.DEADLINE_KV.put(key, JSON.stringify(day), { expirationTtl: 60 * 60 * 24 * 7 });
  }
  return json({ ok: true, percentile: percentileVal, total: day.runs.length });
}

async function getDay(date, mode, env) {
  if (!validDate(date) || !MODES.has(mode)) return json({ error: 'invalid' }, 400);
  const day = JSON.parse(await env.DEADLINE_KV.get(`day:${date}:${mode}`) || '{"runs":[]}');
  return json({
    date, mode, total: day.runs.length,
    deaths: day.runs.filter(r => r.d && r.pos).map(r => ({ pos: r.pos, progress: r.p })),
    ghosts: day.runs.filter(r => r.i).sort((a, b) => b.p - a.p).slice(0, 5).map(r => ({ progress: r.p, inputs: r.i })),
  }, 200, { 'cache-control': 'public, max-age=60' });
}

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const url = new URL(req.url);
    try {
      if (req.method === 'POST' && url.pathname === '/run') return await postRun(req, env);
      const m = url.pathname.match(/^\/day\/([^/]+)\/([^/]+)$/);
      if (req.method === 'GET' && m) return await getDay(m[1], m[2], env);
      return json({ error: 'not_found' }, 404);
    } catch (e) { return json({ error: 'server_error' }, 500); }
  },
};
